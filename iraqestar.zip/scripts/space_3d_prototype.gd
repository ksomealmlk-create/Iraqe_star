extends Node3D
## نجوم العراق — نسخة 3D مع المتجر
## الطائرة تُبنى من scripts/ship_builder.gd ، والمتجر يغيّر: الأسلحة (ذراعين + راجمة) ، شكل الطائرة ، لونها ، وشكل الفيلد.
## كل الأسعار والأسماء في الجداول بالأعلى (WEAPONS / SHAPES / COLORS / FIELDS) تقدر تعدّلها بسهولة.

const ShipBuilder = preload("res://scripts/ship_builder.gd")
const SAVE_PATH := "user://nujoom_shop.json"

@export var asteroid_count: int = 90
@export var asteroid_scale: float = 2.0       # حجم الصخور (كبّرناها لأن الطائرة صارت أكبر)
@export var field_radius: float = 45.0
@export var ship_speed: float = 20.0
@export var ship_size: float = 1.0            # 1.0 = الحجم الجديد (≈ 3 أضعاف القديم). غيّره لو تريد أكبر/أصغر
@export var auto_fire: bool = true            # إطلاق تلقائي (مناسب للموبايل)
@export var start_money: int = 0              # رصيد البداية لأول مرة
@export var shop_view_offset: float = -6.0    # يرفع الطائرة لفوق عند فتح المتجر (عدّله إذا تريد)

# ---------------- جداول المتجر ----------------
var WEAPONS: Array = [
	{"name": "الذراع الأولى (يسار)", "desc": "ذراع رشاش يدور ويتتبّع أقرب صخرة ويرمي طلق.", "price": 800},
	{"name": "الذراع الثانية (يمين)", "desc": "ذراع ثانية على الجناح الأيمن، ضعف النار.", "price": 1500},
	{"name": "راجمة صواريخ", "desc": "6 صواريخ موجّهة فوق الطائرة، انفجارها يضرب منطقة.", "price": 3500},
]
var SHAPES: Array = [
	{"name": "دلتا (الأساسية)", "desc": "الشكل الكلاسيكي المتوازن.", "price": 0},
	{"name": "الإبرة", "desc": "نحيفة بأنف طويل وأجنحة أمامية.", "price": 2500},
	{"name": "التيتان", "desc": "عريضة ومدرّعة مع حاويات جانبية.", "price": 6000},
]
var COLORS: Array = [
	{"name": "فضي ثلجي", "price": 0, "base": Color(0.80, 0.82, 0.86), "acc": Color(0.17, 0.18, 0.22), "glow": Color(0.10, 0.60, 1.00)},
	{"name": "علم العراق", "price": 300, "base": Color(0.93, 0.93, 0.93), "acc": Color(0.80, 0.08, 0.10), "glow": Color(0.10, 0.80, 0.30)},
	{"name": "أسود ليلي", "price": 300, "base": Color(0.12, 0.13, 0.16), "acc": Color(0.90, 0.70, 0.10), "glow": Color(1.00, 0.50, 0.10)},
	{"name": "أخضر نيون", "price": 600, "base": Color(0.20, 0.75, 0.45), "acc": Color(0.05, 0.20, 0.15), "glow": Color(0.20, 1.00, 0.60)},
	{"name": "أحمر ناري", "price": 600, "base": Color(0.80, 0.15, 0.10), "acc": Color(0.15, 0.05, 0.05), "glow": Color(1.00, 0.40, 0.10)},
	{"name": "ذهبي ملكي", "price": 1200, "base": Color(0.90, 0.72, 0.20), "acc": Color(0.25, 0.12, 0.04), "glow": Color(1.00, 0.80, 0.20)},
]
var FIELDS: Array = [
	{"name": "الفضاء الأزرق", "desc": "الفيلد الأساسي.", "price": 0,
		"top": Color(0.008, 0.018, 0.055), "horizon": Color(0.035, 0.07, 0.12), "ambient": Color(0.30, 0.38, 0.55),
		"fill": Color(0.05, 0.55, 1.0), "star": Color(0.6, 0.8, 1.0), "rock": Color(0.30, 0.32, 0.36),
		"p1": Color(0.20, 0.33, 0.80), "p1g": Color(0.55, 0.12, 0.70), "p2": Color(0.95, 0.13, 0.055), "p2g": Color(1.0, 0.30, 0.08)},
	{"name": "سديم أحمر", "desc": "سماء حمراء وصخور داكنة.", "price": 1000,
		"top": Color(0.08, 0.01, 0.02), "horizon": Color(0.22, 0.04, 0.05), "ambient": Color(0.55, 0.28, 0.28),
		"fill": Color(1.0, 0.30, 0.15), "star": Color(1.0, 0.75, 0.55), "rock": Color(0.38, 0.26, 0.24),
		"p1": Color(0.75, 0.25, 0.10), "p1g": Color(1.0, 0.45, 0.10), "p2": Color(0.45, 0.10, 0.30), "p2g": Color(0.9, 0.2, 0.5)},
	{"name": "شفق أخضر", "desc": "أجواء خضراء هادئة.", "price": 1000,
		"top": Color(0.00, 0.05, 0.04), "horizon": Color(0.02, 0.16, 0.12), "ambient": Color(0.25, 0.55, 0.45),
		"fill": Color(0.1, 1.0, 0.6), "star": Color(0.7, 1.0, 0.85), "rock": Color(0.25, 0.36, 0.32),
		"p1": Color(0.10, 0.60, 0.40), "p1g": Color(0.2, 1.0, 0.6), "p2": Color(0.15, 0.30, 0.65), "p2g": Color(0.3, 0.6, 1.0)},
	{"name": "ذهب بغداد", "desc": "فيلد ذهبي فاخر.", "price": 2500,
		"top": Color(0.06, 0.04, 0.00), "horizon": Color(0.22, 0.15, 0.03), "ambient": Color(0.65, 0.50, 0.25),
		"fill": Color(1.0, 0.75, 0.2), "star": Color(1.0, 0.92, 0.6), "rock": Color(0.45, 0.38, 0.22),
		"p1": Color(0.85, 0.60, 0.15), "p1g": Color(1.0, 0.8, 0.3), "p2": Color(0.55, 0.30, 0.10), "p2g": Color(1.0, 0.55, 0.2)},
]

# ---------------- أصناف داخلية ----------------
class Rock:
	var node: MeshInstance3D
	var hp: float = 1.0
	var radius: float = 1.0
	var norm: float = 1.0
	var spin: Vector3 = Vector3.ZERO
	var speed: float = 6.0

class Shot:
	var node: Node3D
	var dir: Vector3 = Vector3(0, 0, -1)
	var speed: float = 50.0
	var dmg: float = 1.0
	var life: float = 2.0
	var rocket: bool = false
	var radius: float = 0.3
	var target: Rock = null

# ---------------- الحالة ----------------
var ship: Node3D
var ship_visual: Node3D
var camera: Camera3D
var engine_light: OmniLight3D
var field_root: Node3D
var builder = null
var flames: Array = []
var arm_nodes: Array = [null, null]
var arm_cd: Array = [0.0, 0.0]
var launcher_node: Node3D = null
var nose_z: float = -4.0

var rocks: Array[Rock] = []
var shots: Array[Shot] = []
var rng := RandomNumberGenerator.new()
var time_acc := 0.0
var save_acc := 0.0
var main_cd := 0.0
var launcher_cd := 0.0

var touch_origin := Vector2.ZERO
var touch_vector := Vector2.ZERO
var touch_active := false

var money: int = 0
var owned: Dictionary = {}
var cur_shape := 0
var cur_color := 0
var cur_field := 0
var shop_open := false
var cur_tab := 0

var bullet_mesh: CylinderMesh
var bullet_mat: StandardMaterial3D
var rocket_mesh: CylinderMesh
var rocket_mat: StandardMaterial3D

var ui_font: Font = null
var money_label: Label
var hint_label: Label
var shop_btn: Button
var shop_panel: PanelContainer
var shop_money: Label
var tab_btns: Array = []
var list_box: VBoxContainer

var sfx_pool: Array = []
var sfx_idx := 0
var sfx_cache := {}


func _ready() -> void:
	rng.randomize()
	_make_shared_resources()
	_make_sfx_pool()
	_load_save()
	field_root = Node3D.new()
	add_child(field_root)
	_build_field()
	_create_ship()
	_rebuild_ship()
	_create_ui()
	_refresh_hud()


func _process(delta: float) -> void:
	time_acc += delta
	save_acc += delta
	if save_acc > 6.0:
		save_acc = 0.0
		_save()
	for i in range(flames.size()):
		var f: Node3D = flames[i]
		if is_instance_valid(f):
			f.scale.z = 1.0 + 0.28 * sin(time_acc * 32.0 + i * 1.7)
	_update_rocks(delta)
	if shop_open:
		ship_visual.rotation.y += delta * 0.9
		camera.v_offset = lerpf(camera.v_offset, shop_view_offset, minf(1.0, delta * 6.0))
		_update_shots(delta)
		return
	ship_visual.rotation.y = lerp_angle(ship_visual.rotation.y, 0.0, minf(1.0, delta * 6.0))
	camera.v_offset = lerpf(camera.v_offset, 0.0, minf(1.0, delta * 6.0))
	_move_ship(delta)
	_update_weapons(delta)
	_update_shots(delta)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save()


# =====================================================================
#                               الفيلد
# =====================================================================
func _build_field() -> void:
	for c in field_root.get_children():
		field_root.remove_child(c)
		c.queue_free()
	rocks.clear()
	var th: Dictionary = FIELDS[cur_field]
	_setup_environment(th)
	_create_stars(th)
	_create_planets(th)
	for i in range(asteroid_count):
		_make_rock(th)


func _setup_environment(th: Dictionary) -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = th["top"]
	sm.sky_horizon_color = th["horizon"]
	sm.ground_bottom_color = th["top"]
	sm.ground_horizon_color = th["horizon"]
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = th["ambient"]
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.7
	world.environment = env
	field_root.add_child(world)

	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-32, -28, 0)
	key.light_color = Color(0.85, 0.9, 1.0)
	key.light_energy = 1.4
	field_root.add_child(key)

	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 4, -10)
	fill.light_color = th["fill"]
	fill.light_energy = 3.0
	fill.omni_range = 40.0
	field_root.add_child(fill)


func _create_stars(th: Dictionary) -> void:
	var count := 500
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var sph := SphereMesh.new()
	sph.radius = 0.12
	sph.height = 0.24
	sph.radial_segments = 4
	sph.rings = 2
	mm.mesh = sph
	mm.instance_count = count
	for i in range(count):
		var p := Vector3(rng.randf_range(-130, 130), rng.randf_range(-80, 80), rng.randf_range(-150, 20))
		var s := rng.randf_range(0.5, 1.6)
		mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(s, s, s)), p))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = th["star"]
	mi.material_override = mat
	field_root.add_child(mi)


func _create_planets(th: Dictionary) -> void:
	_planet(Vector3(-40, 14, -95), 12.0, th["p1"], th["p1g"])
	_planet(Vector3(46, 9, -120), 15.0, th["p2"], th["p2g"])


func _planet(pos: Vector3, radius: float, base: Color, glow: Color) -> void:
	var body := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 40
	sphere.rings = 20
	body.mesh = sphere
	body.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = base
	mat.roughness = 0.88
	mat.metallic = 0.08
	mat.emission_enabled = true
	mat.emission = glow
	mat.emission_energy_multiplier = 0.28
	body.material_override = mat
	field_root.add_child(body)
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = glow
	light.light_energy = 1.7
	light.omni_range = radius * 4.0
	field_root.add_child(light)


func _make_rock(th: Dictionary) -> void:
	var r := Rock.new()
	r.norm = rng.randf_range(0.35, 1.65)
	r.radius = r.norm * asteroid_scale
	var mi := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = r.radius
	sphere.height = r.radius * 1.8
	sphere.radial_segments = 8
	sphere.rings = 5
	mi.mesh = sphere
	mi.scale = Vector3(rng.randf_range(0.8, 1.35), rng.randf_range(0.7, 1.2), rng.randf_range(0.8, 1.3))
	var mat := StandardMaterial3D.new()
	var tint: Color = th["rock"]
	var shade := rng.randf_range(0.6, 1.2)
	mat.albedo_color = Color(tint.r * shade, tint.g * shade, tint.b * shade)
	mat.roughness = 1.0
	mat.metallic = 0.12
	mi.material_override = mat
	r.node = mi
	r.spin = Vector3(rng.randf_range(-0.6, 0.6), rng.randf_range(-0.6, 0.6), rng.randf_range(-0.6, 0.6))
	field_root.add_child(mi)
	_place_rock(r, true)
	rocks.append(r)


func _place_rock(r: Rock, initial: bool) -> void:
	var z := rng.randf_range(-110.0, 10.0) if initial else rng.randf_range(-135.0, -105.0)
	r.node.position = Vector3(rng.randf_range(-field_radius, field_radius), rng.randf_range(-16.0, 16.0), z)
	r.node.rotation = Vector3(rng.randf_range(0, TAU), rng.randf_range(0, TAU), rng.randf_range(0, TAU))
	r.hp = 1.0 + r.norm * 2.5
	r.speed = rng.randf_range(4.0, 9.0)


func _update_rocks(delta: float) -> void:
	var sp := ship.position
	for r in rocks:
		r.node.position.z += r.speed * delta
		r.node.rotation += r.spin * delta
		if r.node.position.z > 26.0:
			_place_rock(r, false)
			continue
		if shop_open:
			continue
		var d := r.node.position - sp
		if absf(d.z) < 8.0 and d.length_squared() < pow(r.radius * 0.9 + 3.2 * ship_size, 2.0):
			# اصطدام بالطائرة: تتحطم الصخرة بدون مكافأة
			_explode(r.node.position, r.radius, Color(1.0, 0.55, 0.2))
			_sfx("asteroid_break", -10.0)
			_place_rock(r, false)


# =====================================================================
#                              الطائرة
# =====================================================================
func _create_ship() -> void:
	ship = Node3D.new()
	ship.position = Vector3(0, -1.0, 5.0)
	add_child(ship)
	ship_visual = Node3D.new()
	ship.add_child(ship_visual)

	engine_light = OmniLight3D.new()
	engine_light.position = Vector3(0, 0, 4.6 * ship_size)
	engine_light.light_energy = 2.8
	engine_light.omni_range = 10.0
	ship.add_child(engine_light)

	camera = Camera3D.new()
	camera.fov = 70.0
	camera.far = 400.0
	camera.position = Vector3(0, 8.0, 19.0) * ship_size
	camera.rotation_degrees = Vector3(-17, 0, 0)
	camera.current = true
	ship.add_child(camera)


func _rebuild_ship() -> void:
	for c in ship_visual.get_children():
		ship_visual.remove_child(c)
		c.queue_free()
	arm_nodes = [null, null]
	launcher_node = null
	flames = []
	var col: Dictionary = COLORS[cur_color]
	builder = ShipBuilder.new()
	var info: Dictionary = builder.build(ship_visual, cur_shape, col["base"], col["acc"], col["glow"], ship_size)
	flames = info["flames"]
	nose_z = info["nose_z"]
	engine_light.light_color = col["glow"]
	var arm_pos: Array = info["arm_pos"]
	for i in range(2):
		if owned.has("weapon_%d" % i):
			var arm: Node3D = builder.make_arm()
			arm.position = arm_pos[i]
			arm.scale = Vector3.ONE * ship_size * 1.25
			ship_visual.add_child(arm)
			arm_nodes[i] = arm
	if owned.has("weapon_2"):
		var lau: Node3D = builder.make_launcher()
		lau.position = info["launcher_pos"]
		lau.scale = Vector3.ONE * ship_size * 1.3
		ship_visual.add_child(lau)
		launcher_node = lau


func _move_ship(delta: float) -> void:
	var v := Vector2.ZERO
	v.x = Input.get_axis("ui_left", "ui_right")
	v.y = Input.get_axis("ui_up", "ui_down")
	if Input.is_key_pressed(KEY_A):
		v.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		v.x += 1.0
	if Input.is_key_pressed(KEY_W):
		v.y -= 1.0
	if Input.is_key_pressed(KEY_S):
		v.y += 1.0
	v = v.limit_length(1.0)
	if touch_active:
		v = touch_vector
	ship.position.x = clampf(ship.position.x + v.x * ship_speed * delta, -26.0, 26.0)
	ship.position.y = clampf(ship.position.y - v.y * ship_speed * delta, -12.0, 12.0)
	ship_visual.rotation.z = lerpf(ship_visual.rotation.z, -v.x * 0.22, minf(1.0, delta * 5.0))
	ship_visual.rotation.x = lerpf(ship_visual.rotation.x, v.y * 0.10, minf(1.0, delta * 4.0))


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		# اختبار: زر M يزيد 1000 د.ع (فقط في نسخة التطوير)
		if event.keycode == KEY_M and OS.is_debug_build():
			_add_money(1000)
	if shop_open:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			if shop_btn != null and shop_btn.get_global_rect().has_point(event.position):
				return
			touch_origin = event.position
			touch_active = true
			touch_vector = Vector2.ZERO
		else:
			touch_active = false
			touch_vector = Vector2.ZERO
	elif event is InputEventScreenDrag and touch_active:
		var vs := get_viewport().get_visible_rect().size
		touch_vector = ((event.position - touch_origin) / Vector2(vs.x * 0.20, vs.y * 0.12)).limit_length(1.0)


# =====================================================================
#                          الأسلحة والطلقات
# =====================================================================
func _make_shared_resources() -> void:
	bullet_mesh = CylinderMesh.new()
	bullet_mesh.top_radius = 0.07
	bullet_mesh.bottom_radius = 0.07
	bullet_mesh.height = 0.9
	bullet_mesh.radial_segments = 6
	bullet_mat = StandardMaterial3D.new()
	bullet_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bullet_mat.albedo_color = Color(1.0, 0.9, 0.35)
	rocket_mesh = CylinderMesh.new()
	rocket_mesh.top_radius = 0.1
	rocket_mesh.bottom_radius = 0.14
	rocket_mesh.height = 1.2
	rocket_mesh.radial_segments = 8
	rocket_mat = StandardMaterial3D.new()
	rocket_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rocket_mat.albedo_color = Color(1.0, 0.5, 0.15)


func _update_weapons(delta: float) -> void:
	var firing := auto_fire or Input.is_action_pressed("ui_accept") or Input.is_key_pressed(KEY_SPACE)
	main_cd = maxf(0.0, main_cd - delta)
	launcher_cd = maxf(0.0, launcher_cd - delta)
	# المدفع الأمامي (مجاني)
	if firing and main_cd <= 0.0:
		main_cd = 0.16
		_spawn_shot(ship.position + Vector3(0, 0.2, nose_z - 0.3), Vector3(0, 0, -1), 60.0, 1.0, false)
	# الذراعين
	for i in range(2):
		var arm = arm_nodes[i]
		if arm == null:
			continue
		var pivot: Node3D = arm.get_node("Pivot")
		var muzzle: Node3D = pivot.get_node("Muzzle")
		arm_cd[i] = maxf(0.0, float(arm_cd[i]) - delta)
		var target := _nearest_rock(muzzle.global_position, 80.0)
		var goal := Vector3.ZERO
		if target != null:
			var lp: Vector3 = arm.to_local(target.node.global_position)
			var yaw := clampf(atan2(-lp.x, -lp.z), -0.9, 0.9)
			var pitch := clampf(atan2(lp.y, Vector2(lp.x, lp.z).length()), -0.5, 0.5)
			goal = Vector3(pitch, yaw, 0.0)
		pivot.rotation = pivot.rotation.lerp(goal, minf(1.0, delta * 10.0))
		if firing and float(arm_cd[i]) <= 0.0:
			arm_cd[i] = 0.14 + 0.03 * i
			var dir: Vector3 = -pivot.global_transform.basis.z
			_spawn_shot(muzzle.global_position, dir.normalized(), 50.0, 1.0, false)
	# الراجمة
	if launcher_node != null and firing and launcher_cd <= 0.0:
		launcher_cd = 2.6
		_fire_salvo()


func _fire_salvo() -> void:
	_sfx("weapon_homing_missiles", -4.0)
	for i in range(6):
		if not is_instance_valid(launcher_node) or shop_open:
			return
		var tubes: Node3D = launcher_node.get_node("Tubes")
		var m: Node3D = tubes.get_node("Muzzle%d" % i)
		var dir: Vector3 = -tubes.global_transform.basis.z
		_spawn_shot(m.global_position, dir.normalized(), 26.0, 5.0, true, _random_rock_ahead())
		await get_tree().create_timer(0.08).timeout


func _nearest_rock(from: Vector3, max_range: float) -> Rock:
	var best: Rock = null
	var best_d := max_range * max_range
	for r in rocks:
		var d := r.node.position - from
		if d.z > -1.0:
			continue
		if absf(d.x) > -d.z * 1.3 + 4.0:
			continue
		var dd := d.length_squared()
		if dd < best_d:
			best_d = dd
			best = r
	return best


func _random_rock_ahead() -> Rock:
	var cands: Array[Rock] = []
	var sp := ship.position
	for r in rocks:
		var d := r.node.position - sp
		if d.z < -8.0 and d.z > -90.0 and absf(d.x) < 30.0:
			cands.append(r)
	if cands.is_empty():
		return null
	return cands[rng.randi() % cands.size()]


func _spawn_shot(pos: Vector3, dir: Vector3, speed: float, dmg: float, rocket: bool, target: Rock = null) -> void:
	var holder := Node3D.new()
	var mi := MeshInstance3D.new()
	mi.mesh = rocket_mesh if rocket else bullet_mesh
	mi.material_override = rocket_mat if rocket else bullet_mat
	mi.rotation_degrees.x = 90.0
	holder.add_child(mi)
	add_child(holder)
	holder.position = pos
	holder.basis = Basis.looking_at(dir.normalized(), Vector3.UP)
	var s := Shot.new()
	s.node = holder
	s.dir = dir.normalized()
	s.speed = speed
	s.dmg = dmg
	s.rocket = rocket
	s.life = 3.0 if rocket else 2.2
	s.radius = 0.5 if rocket else 0.3
	s.target = target
	shots.append(s)


func _update_shots(delta: float) -> void:
	var i := shots.size() - 1
	while i >= 0:
		var s: Shot = shots[i]
		var remove := false
		s.life -= delta
		if s.life <= 0.0:
			remove = true
			if s.rocket:
				_rocket_blast(s)
		else:
			if s.rocket:
				if s.target != null:
					var to := (s.target.node.position - s.node.position).normalized()
					s.dir = s.dir.lerp(to, minf(1.0, delta * 3.5)).normalized()
				s.speed = minf(s.speed + 30.0 * delta, 48.0)
				s.node.basis = Basis.looking_at(s.dir, Vector3.UP)
			s.node.position += s.dir * s.speed * delta
			for r in rocks:
				var d := r.node.position - s.node.position
				if absf(d.z) > r.radius + 2.0:
					continue
				var rr := r.radius * 0.9 + s.radius
				if d.length_squared() < rr * rr:
					if s.rocket:
						_rocket_blast(s)
					else:
						_explode(s.node.position, 0.5, Color(1.0, 0.9, 0.4))
						_damage_rock(r, s.dmg)
					remove = true
					break
		if remove:
			s.node.queue_free()
			shots.remove_at(i)
		i -= 1


func _rocket_blast(s: Shot) -> void:
	var pos := s.node.position
	_explode(pos, 5.5, Color(1.0, 0.55, 0.15))
	for r in rocks:
		if r.node.position.distance_to(pos) < 5.5 + r.radius:
			_damage_rock(r, s.dmg)


func _damage_rock(r: Rock, dmg: float) -> void:
	r.hp -= dmg
	if r.hp > 0.0:
		return
	var reward := int(8.0 + r.norm * 14.0)
	_explode(r.node.position, r.radius * 1.2, Color(1.0, 0.7, 0.3))
	_float_text(r.node.position, "+%d" % reward)
	_sfx("asteroid_break", -8.0)
	_add_money(reward)
	_place_rock(r, false)


func _explode(pos: Vector3, radius: float, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var sp := SphereMesh.new()
	sp.radius = 1.0
	sp.height = 2.0
	sp.radial_segments = 12
	sp.rings = 6
	mi.mesh = sp
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(col.r, col.g, col.b, 0.85)
	mi.material_override = m
	mi.position = pos
	mi.scale = Vector3.ONE * radius * 0.3
	add_child(mi)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * radius, 0.3)
	tw.tween_property(m, "albedo_color:a", 0.0, 0.3)
	tw.chain().tween_callback(mi.queue_free)


func _float_text(pos: Vector3, text: String) -> void:
	var l := Label3D.new()
	l.text = text
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.pixel_size = 0.03
	l.font_size = 64
	l.outline_size = 14
	l.modulate = Color(1.0, 0.9, 0.3)
	if ui_font != null:
		l.font = ui_font
	l.position = pos
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", pos.y + 3.0, 0.9)
	tw.tween_property(l, "modulate:a", 0.0, 0.9)
	tw.chain().tween_callback(l.queue_free)


# =====================================================================
#                                المتجر
# =====================================================================
func _items(kind: String) -> Array:
	match kind:
		"weapon":
			return WEAPONS
		"shape":
			return SHAPES
		"color":
			return COLORS
	return FIELDS


func _is_equipped(kind: String, i: int) -> bool:
	match kind:
		"weapon":
			return owned.has("weapon_%d" % i)
		"shape":
			return cur_shape == i
		"color":
			return cur_color == i
	return cur_field == i


func _on_item(kind: String, i: int) -> void:
	var it: Dictionary = _items(kind)[i]
	var key := "%s_%d" % [kind, i]
	if not owned.has(key):
		var price: int = it["price"]
		if money < price:
			return
		money -= price
		owned[key] = true
		_sfx("ui_purchase", -4.0)
	else:
		_sfx("ui_tap", -6.0)
	match kind:
		"shape":
			cur_shape = i
			_rebuild_ship()
		"color":
			cur_color = i
			_rebuild_ship()
		"weapon":
			_rebuild_ship()
		"field":
			if cur_field != i:
				cur_field = i
				_build_field()
	_save()
	_refresh_shop()
	_refresh_hud()


func _set_shop(open: bool) -> void:
	shop_open = open
	shop_panel.visible = open
	shop_btn.visible = not open
	touch_active = false
	touch_vector = Vector2.ZERO
	if open:
		_refresh_shop()
	else:
		_save()


func _set_tab(i: int) -> void:
	cur_tab = i
	for j in range(tab_btns.size()):
		var b: Button = tab_btns[j]
		b.set_pressed_no_signal(j == i)
	_sfx("ui_tap", -8.0)
	_refresh_shop()


func _refresh_shop() -> void:
	shop_money.text = "الرصيد: %s د.ع" % _fmt(money)
	for c in list_box.get_children():
		list_box.remove_child(c)
		c.queue_free()
	var kinds := ["weapon", "shape", "color", "field"]
	var kind: String = kinds[cur_tab]
	var arr: Array = _items(kind)
	for i in range(arr.size()):
		_add_row(kind, i, arr[i])


func _add_row(kind: String, i: int, it: Dictionary) -> void:
	var key := "%s_%d" % [kind, i]
	var is_owned: bool = owned.has(key)
	var is_eq := _is_equipped(kind, i)
	var border := Color(0.2, 0.9, 0.5, 0.9) if is_eq else Color(0.1, 0.4, 0.7, 0.6)
	var row := PanelContainer.new()
	row.add_theme_stylebox_override("panel", _box(Color(0.03, 0.07, 0.14, 0.92), border))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	row.add_child(h)
	if kind == "color":
		var sw := ColorRect.new()
		sw.custom_minimum_size = Vector2(26, 26)
		sw.color = it["base"]
		h.add_child(sw)
		var sw2 := ColorRect.new()
		sw2.custom_minimum_size = Vector2(26, 26)
		sw2.color = it["acc"]
		h.add_child(sw2)
	elif kind == "field":
		var sw3 := ColorRect.new()
		sw3.custom_minimum_size = Vector2(52, 52)
		sw3.color = it["horizon"]
		h.add_child(sw3)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	var n := Label.new()
	n.text = it["name"]
	n.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(n)
	var desc: String = it.get("desc", "")
	if desc != "":
		var d := Label.new()
		d.text = desc
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		d.add_theme_font_size_override("font_size", 22)
		d.modulate = Color(0.7, 0.85, 1.0, 0.85)
		v.add_child(d)
	var b := _button("")
	b.custom_minimum_size = Vector2(230, 76)
	var price: int = it["price"]
	if kind == "weapon" and is_owned:
		b.text = "✔ مملوك"
		b.disabled = true
	elif is_eq:
		b.text = "✔ مفعّل"
		b.disabled = true
	elif is_owned:
		b.text = "تفعيل"
	else:
		b.text = "شراء  " + _fmt(price)
		b.disabled = money < price
	b.pressed.connect(_on_item.bind(kind, i))
	h.add_child(b)
	list_box.add_child(row)


# =====================================================================
#                            الواجهة (UI)
# =====================================================================
func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	return sb


func _button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 76)
	b.add_theme_stylebox_override("normal", _box(Color(0.05, 0.25, 0.45, 0.95), Color(0.2, 0.7, 1.0, 0.9)))
	b.add_theme_stylebox_override("hover", _box(Color(0.08, 0.34, 0.58, 0.95), Color(0.4, 0.85, 1.0, 1.0)))
	b.add_theme_stylebox_override("pressed", _box(Color(0.10, 0.55, 0.40, 0.95), Color(0.4, 1.0, 0.7, 1.0)))
	b.add_theme_stylebox_override("disabled", _box(Color(0.10, 0.12, 0.17, 0.9), Color(0.25, 0.3, 0.4, 0.7)))
	return b


func _create_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var th := Theme.new()
	if ResourceLoader.exists("res://assets/fonts/DejaVuSans-Bold.ttf"):
		ui_font = load("res://assets/fonts/DejaVuSans-Bold.ttf")
		th.default_font = ui_font
	th.default_font_size = 30
	root.theme = th

	# --- الشريط العلوي: الرصيد + زر المتجر ---
	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_theme_constant_override("separation", 16)
	root.add_child(top)
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE, Control.PRESET_MODE_MINSIZE, 20)
	var pm := PanelContainer.new()
	pm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pm.add_theme_stylebox_override("panel", _box(Color(0.015, 0.035, 0.08, 0.8), Color(0.05, 0.72, 1.0, 0.8)))
	money_label = Label.new()
	money_label.add_theme_color_override("font_color", Color(1.0, 0.92, 0.45))
	pm.add_child(money_label)
	top.add_child(pm)
	shop_btn = _button("المتجر")
	shop_btn.custom_minimum_size = Vector2(220, 76)
	shop_btn.pressed.connect(_set_shop.bind(true))
	top.add_child(shop_btn)

	# --- تلميح ---
	hint_label = Label.new()
	hint_label.text = "اسحب بإصبعك للتحرّك — الإطلاق تلقائي — اجمع الفلوس من الصخور واشتري من المتجر"
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.add_theme_font_size_override("font_size", 24)
	hint_label.modulate = Color(0.8, 0.95, 1.0, 0.9)
	hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hint_label)
	hint_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE, Control.PRESET_MODE_MINSIZE, 30)
	var tw := create_tween()
	tw.tween_interval(7.0)
	tw.tween_property(hint_label, "modulate:a", 0.0, 1.0)

	# --- لوحة المتجر (تغطي الجزء السفلي، والطائرة تبقى ظاهرة فوقها وتدور) ---
	shop_panel = PanelContainer.new()
	shop_panel.visible = false
	shop_panel.add_theme_stylebox_override("panel", _box(Color(0.01, 0.025, 0.06, 0.94), Color(0.05, 0.72, 1.0, 0.9)))
	root.add_child(shop_panel)
	shop_panel.anchor_left = 0.0
	shop_panel.anchor_right = 1.0
	shop_panel.anchor_top = 0.40
	shop_panel.anchor_bottom = 1.0
	shop_panel.offset_left = 12
	shop_panel.offset_right = -12
	shop_panel.offset_top = 0
	shop_panel.offset_bottom = -12
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	shop_panel.add_child(vb)

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	vb.add_child(head)
	var title := Label.new()
	title.text = "المتجر"
	title.add_theme_font_size_override("font_size", 38)
	head.add_child(title)
	shop_money = Label.new()
	shop_money.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_money.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	shop_money.add_theme_color_override("font_color", Color(1.0, 0.92, 0.45))
	head.add_child(shop_money)
	var close := _button("إغلاق ✕")
	close.custom_minimum_size = Vector2(190, 70)
	close.pressed.connect(_set_shop.bind(false))
	head.add_child(close)

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	vb.add_child(tabs)
	var names := ["الأسلحة", "الطائرة", "اللون", "الفيلد"]
	for i in range(names.size()):
		var tb := _button(names[i])
		tb.toggle_mode = true
		tb.custom_minimum_size = Vector2(0, 70)
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.set_pressed_no_signal(i == cur_tab)
		tb.pressed.connect(_set_tab.bind(i))
		tabs.add_child(tb)
		tab_btns.append(tb)

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 10)
	sc.add_child(list_box)


func _refresh_hud() -> void:
	if money_label != null:
		money_label.text = "الرصيد: %s د.ع" % _fmt(money)
	if shop_open and shop_money != null:
		_refresh_shop()


func _add_money(n: int) -> void:
	money += n
	if money_label != null:
		money_label.text = "الرصيد: %s د.ع" % _fmt(money)


func _fmt(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return out


# =====================================================================
#                      الحفظ والصوت
# =====================================================================
func _save() -> void:
	var d := {
		"money": money,
		"owned": owned.keys(),
		"shape": cur_shape,
		"color": cur_color,
		"field": cur_field,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))


func _load_save() -> void:
	owned = {"shape_0": true, "color_0": true, "field_0": true}
	money = start_money
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var data = JSON.parse_string(f.get_as_text())
	if typeof(data) != TYPE_DICTIONARY:
		return
	money = int(data.get("money", money))
	for k in data.get("owned", []):
		owned[str(k)] = true
	cur_shape = clampi(int(data.get("shape", 0)), 0, SHAPES.size() - 1)
	cur_color = clampi(int(data.get("color", 0)), 0, COLORS.size() - 1)
	cur_field = clampi(int(data.get("field", 0)), 0, FIELDS.size() - 1)


func _make_sfx_pool() -> void:
	for i in range(8):
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_pool.append(p)


func _sfx(sfx_name: String, vol: float = -6.0) -> void:
	var path := "res://assets/audio/sfx/sfx_%s.ogg" % sfx_name
	if not sfx_cache.has(path):
		if ResourceLoader.exists(path):
			sfx_cache[path] = load(path)
		else:
			sfx_cache[path] = null
	var st = sfx_cache[path]
	if st == null:
		return
	var p: AudioStreamPlayer = sfx_pool[sfx_idx]
	sfx_idx = (sfx_idx + 1) % sfx_pool.size()
	p.stream = st
	p.volume_db = vol
	p.play()
