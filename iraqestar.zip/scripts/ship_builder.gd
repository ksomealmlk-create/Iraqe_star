extends RefCounted
## بنّاء مجسم الطائرة بالكود.
## النقاط مأخوذة من الصورة المرجعية (32865.png) وتُسحب (Extrude) لتصير مجسم ثلاثي الأبعاد.
## لا يحتاج Blender ولا ملفات خارجية، وتقدر تبدّل ألوانه وشكله من المتجر.

# مركز الطائرة داخل الصورة (بالبكسل)
const IMG_CX := 685.0
const IMG_CY := 627.0
# حجم الطائرة: كل بكسل = كم وحدة في اللعبة.
# 0.0082 يعني طول الطائرة ≈ 8 وحدات وعرضها ≈ 7.3 (الطائرة القديمة كانت 2.4 × 3.9)
const UNIT_PER_PX := 0.0082

# ---- نقاط المجسم (من الصورة) ----
# "half" = النصف العلوي فقط، يُعكس تلقائياً ليكتمل الجسم. تبدأ من الأنف وتنتهي بالمؤخرة على محور المنتصف.
const WING_HALF := [[1175,627],[1105,595],[950,552],[822,523],[695,470],[378,181],[297,185],[300,212],[395,408],[445,462],[300,482],[285,520],[285,627]]
const HULL_HALF := [[1165,627],[1060,590],[900,553],[800,535],[650,525],[545,482],[300,482],[285,520],[285,627]]
const DORSAL_HALF := [[700,627],[700,590],[665,562],[430,556],[395,598],[395,627]]
const NOSE_HALF := [[1175,627],[1105,598],[1105,627]]
# قطع كاملة (وسط الطائرة)
const COCKPIT := [[830,600],[900,572],[1035,595],[1062,627],[1035,659],[900,682],[830,654]]
const CANOPY_SHINE := [[885,602],[1000,607],[1030,627],[1000,647],[885,652]]
const DARK_PANEL := [[430,610],[568,610],[568,644],[430,644]]
const SQUARE_A := [[383,617],[405,617],[405,637],[383,637]]
const SQUARE_B := [[697,613],[725,613],[725,641],[697,641]]
# قطع تُرسم يمين ويسار (مرآة)
const INTAKE := [[648,482],[708,470],[742,520],[660,530]]
const SIDE_ACC := [[750,585],[805,563],[815,576],[765,600]]
const WING_TIP := [[378,181],[297,185],[300,212],[392,208]]
const WING_BAR := [[368,222],[400,212],[462,392],[430,405]]
const WING_SLIT := [[520,322],[535,318],[650,440],[625,446]]
const FIN := [[225,386],[290,383],[447,466],[385,474],[300,470],[262,435]]
const FIN_TIP := [[225,386],[290,383],[298,404],[236,408]]
const CANARD := [[900,545],[1010,420],[1030,432],[975,560]]

var span_mul := 1.0
var len_mul := 1.0
var engine_scale := 1.0
var base_col := Color(0.8, 0.82, 0.86)
var acc_col := Color(0.17, 0.18, 0.22)
var glow_col := Color(0.1, 0.6, 1.0)

var _root: Node3D
var _u := UNIT_PER_PX
var _flames: Array = []
var _mats := {}


# ======================= الواجهة الرئيسية =======================
# shape: 0 دلتا (الأساسية) | 1 الإبرة (نحيفة وسريعة) | 2 التيتان (عريضة ومدرعة)
# يرجع Dictionary فيه: flames, arm_pos (مكان الذراعين), launcher_pos (مكان الراجمة), nose_z
func build(root: Node3D, shape: int, base: Color, acc: Color, glow: Color, size_mul: float = 1.0) -> Dictionary:
	_root = root
	_flames = []
	_mats = {}
	_u = UNIT_PER_PX * size_mul
	base_col = base
	acc_col = acc
	glow_col = glow
	match shape:
		1:
			span_mul = 0.78
			len_mul = 1.08
			engine_scale = 0.9
		2:
			span_mul = 1.28
			len_mul = 0.96
			engine_scale = 1.25
		_:
			span_mul = 1.0
			len_mul = 1.0
			engine_scale = 1.0

	var m_base := _mat(base_col, 0.55, 0.38)
	var m_acc := _mat(acc_col, 0.5, 0.45)
	var m_glass := _mat(Color(0.07, 0.08, 0.12), 0.9, 0.12)
	var m_shine := _mat(Color(0.35, 0.5, 0.7), 0.3, 0.2, 0.6)
	var m_engine := _mat(Color(0.10, 0.10, 0.13), 0.8, 0.3)

	# 1) الأجنحة + القاعدة
	_layer(_poly_half(WING_HALF, span_mul), -0.06, 0.06, m_base, 0.97)
	# 2) الذيل (الزعانف الخلفية)
	_pair(FIN, 0.0, 0.12, m_base, 0.95, span_mul)
	_pair(FIN_TIP, 0.01, 0.125, m_acc, 1.0, span_mul)
	# 3) الهيكل الرئيسي
	_layer(_poly_half(HULL_HALF), -0.20, 0.20, m_base, 0.93)
	_layer(_poly_half(DORSAL_HALF), 0.18, 0.36, m_base, 0.90)
	_layer(_poly_half(NOSE_HALF), -0.10, 0.17, m_acc, 0.85)
	# 4) المقصورة (الكابينة)
	_layer(_poly(COCKPIT), 0.18, 0.42, m_glass, 0.75)
	_layer(_poly(CANOPY_SHINE), 0.42, 0.435, m_shine, 1.0)
	# 5) تفاصيل داكنة على الجسم
	_layer(_poly(DARK_PANEL), 0.35, 0.375, m_acc)
	_layer(_poly(SQUARE_A), 0.35, 0.375, m_acc)
	_layer(_poly(SQUARE_B), 0.17, 0.215, m_acc)
	_pair(INTAKE, 0.05, 0.22, m_acc)
	_pair(SIDE_ACC, 0.19, 0.225, m_acc)
	# 6) تفاصيل الأجنحة
	_pair(WING_TIP, 0.05, 0.085, m_acc, 1.0, span_mul)
	_pair(WING_BAR, 0.05, 0.08, m_acc, 1.0, span_mul)
	_pair(WING_SLIT, 0.05, 0.075, m_acc, 1.0, span_mul)

	# 7) المحركات (اثنين) + الشعلة
	for side in [-1.0, 1.0]:
		var c := _v([262.0, IMG_CY + side * 82.0])
		var r := 55.0 * _u * engine_scale
		var length := 140.0 * _u * len_mul
		_cyl(r, r, length, Vector3(c.x, 0.04, c.y), m_engine, true)
		_cyl(r * 1.07, r * 1.07, 0.16, Vector3(c.x, 0.04, c.y + length * 0.5 - 0.05), m_acc, true)
		_cyl(r * 0.72, r * 0.72, 0.05, Vector3(c.x, 0.04, c.y + length * 0.5 + 0.02), _mat(glow_col, 0.0, 0.5, 3.0), true)
		_add_flame(Vector3(c.x, 0.04, c.y + length * 0.5), r * 0.7)
	# عارضة داكنة بين المحركين
	var bc := _v([307.0, IMG_CY])
	_box(Vector3(0.36 * span_mul, 0.30, 0.62 * len_mul), Vector3(0.0, 0.02, bc.y), m_engine)

	# 8) إضافات خاصة بكل شكل
	var nose_z := _v([1175.0, IMG_CY]).y
	if shape == 1:
		# إبرة طويلة في الأنف + أجنحة أمامية صغيرة
		var needle := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.0
		cm.bottom_radius = 0.22
		cm.height = 2.2
		cm.radial_segments = 12
		needle.mesh = cm
		needle.material_override = m_base
		needle.rotation_degrees.x = -90.0
		needle.position = Vector3(0, 0.04, nose_z - 0.85)
		_root.add_child(needle)
		nose_z -= 1.95
		_pair(CANARD, -0.04, 0.05, m_acc, 1.0, span_mul)
	elif shape == 2:
		# حاويات مدرعة على الجانبين
		for side2 in [-1.0, 1.0]:
			_box(Vector3(0.55, 0.38, 2.5), Vector3(side2 * 1.5, 0.02, 0.4), m_acc)
			_box(Vector3(0.30, 0.10, 1.9), Vector3(side2 * 1.5, 0.23, 0.4), m_base)

	# أماكن التركيب (الذراع الأولى يسار، الثانية يمين)
	var arm_l := Vector3(_v([520.0, 380.0], span_mul).x, 0.07, _v([520.0, 380.0], span_mul).y)
	var arm_r := Vector3(-arm_l.x, 0.07, arm_l.z)
	var dorsal := _v([560.0, IMG_CY])
	return {
		"flames": _flames,
		"arm_pos": [arm_l, arm_r],
		"launcher_pos": Vector3(0.0, 0.36, dorsal.y),
		"nose_z": nose_z,
	}


# ذراع رشاش (يدور ويتتبّع الهدف). الـ Pivot هو الجزء الدوّار، والـ Muzzle مكان خروج الطلقة.
func make_arm() -> Node3D:
	var root := Node3D.new()
	root.name = "Arm"
	var m_base := _mat(base_col, 0.55, 0.38)
	var m_acc := _mat(acc_col, 0.5, 0.45)
	var m_gun := _mat(Color(0.12, 0.12, 0.15), 0.85, 0.3)
	var m_glow := _mat(glow_col, 0.0, 0.5, 3.0)
	_cyl_in(root, 0.22, 0.26, 0.18, Vector3(0, 0.09, 0), m_acc, false)
	var pivot := Node3D.new()
	pivot.name = "Pivot"
	pivot.position = Vector3(0, 0.34, 0)
	root.add_child(pivot)
	var ball := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.4
	ball.mesh = sm
	ball.material_override = m_base
	pivot.add_child(ball)
	_box_in(pivot, Vector3(0.34, 0.24, 0.55), Vector3(0, 0, -0.2), m_base)
	for sx in [-0.09, 0.09]:
		_cyl_in(pivot, 0.05, 0.05, 1.05, Vector3(sx, 0, -0.78), m_gun, true)
		_cyl_in(pivot, 0.07, 0.07, 0.06, Vector3(sx, 0, -1.28), m_glow, true)
	var muzzle := Marker3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0, 0, -1.35)
	pivot.add_child(muzzle)
	return root


# راجمة صواريخ فوق الطائرة: 6 أنابيب (Muzzle0 .. Muzzle5) داخل العقدة Tubes
func make_launcher() -> Node3D:
	var root := Node3D.new()
	root.name = "Launcher"
	var m_base := _mat(base_col, 0.55, 0.38)
	var m_acc := _mat(acc_col, 0.5, 0.45)
	var m_gun := _mat(Color(0.12, 0.12, 0.15), 0.85, 0.3)
	var m_glow := _mat(Color(1.0, 0.45, 0.1), 0.0, 0.5, 3.0)
	_box_in(root, Vector3(1.05, 0.16, 1.35), Vector3(0, 0.08, 0), m_acc)
	var tubes := Node3D.new()
	tubes.name = "Tubes"
	tubes.position = Vector3(0, 0.42, 0.05)
	tubes.rotation_degrees.x = 8.0
	root.add_child(tubes)
	_box_in(tubes, Vector3(0.98, 0.62, 1.05), Vector3(0, 0, 0.12), m_base)
	var n := 0
	for row in range(2):
		for col in range(3):
			var x := (col - 1) * 0.29
			var y := (row - 0.5) * 0.27
			_cyl_in(tubes, 0.115, 0.115, 1.3, Vector3(x, y, -0.05), m_gun, true)
			_cyl_in(tubes, 0.085, 0.085, 0.04, Vector3(x, y, -0.71), m_glow, true)
			var mk := Marker3D.new()
			mk.name = "Muzzle%d" % n
			mk.position = Vector3(x, y, -0.75)
			tubes.add_child(mk)
			n += 1
	return root


# ======================= أدوات داخلية =======================
func _v(p: Array, span: float = 1.0) -> Vector2:
	# (x يمين/يسار ، z للأمام بالسالب) من إحداثيات الصورة
	return Vector2((p[1] - IMG_CY) * _u * span, -(p[0] - IMG_CX) * _u * len_mul)


func _poly(pts: Array, span: float = 1.0, mirror: bool = false) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in pts:
		var py: float = p[1]
		if mirror:
			py = 2.0 * IMG_CY - py
		out.append(_v([p[0], py], span))
	return out


func _poly_half(half: Array, span: float = 1.0) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in half:
		out.append(_v(p, span))
	for i in range(half.size() - 1, -1, -1):
		var p: Array = half[i]
		var py: float = p[1]
		if absf(py - IMG_CY) < 0.5:
			continue
		out.append(_v([p[0], 2.0 * IMG_CY - py], span))
	return out


func _mat(col: Color, metal: float = 0.55, rough: float = 0.38, emit: float = 0.0) -> StandardMaterial3D:
	var key := "%s_%s_%s_%s" % [col.to_html(), metal, rough, emit]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.metallic = metal
	m.roughness = rough
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = emit
	_mats[key] = m
	return m


func _pair(pts: Array, y0: float, y1: float, mat: Material, top_scale: float = 1.0, span: float = 1.0) -> void:
	_layer(_poly(pts, span, false), y0, y1, mat, top_scale)
	_layer(_poly(pts, span, true), y0, y1, mat, top_scale)


func _layer(poly: PackedVector2Array, y0: float, y1: float, mat: Material, top_scale: float = 1.0) -> void:
	var mi := _prism(poly, y0, y1, mat, top_scale)
	if mi != null:
		_root.add_child(mi)


func _prism(poly: PackedVector2Array, y0: float, y1: float, mat: Material, top_scale: float = 1.0) -> MeshInstance3D:
	var idx := Geometry2D.triangulate_polygon(poly)
	if idx.is_empty():
		return null
	var cen := Vector2.ZERO
	for p in poly:
		cen += p
	cen /= float(poly.size())
	var top := PackedVector2Array()
	for p in poly:
		top.append(cen + (p - cen) * top_scale)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(0, idx.size(), 3):
		var a: int = idx[i]
		var b: int = idx[i + 1]
		var c: int = idx[i + 2]
		_tri(st, Vector3(top[a].x, y1, top[a].y), Vector3(top[b].x, y1, top[b].y), Vector3(top[c].x, y1, top[c].y), Vector3.UP)
		_tri(st, Vector3(poly[a].x, y0, poly[a].y), Vector3(poly[b].x, y0, poly[b].y), Vector3(poly[c].x, y0, poly[c].y), Vector3.DOWN)
	var n := poly.size()
	var area := 0.0
	for i in range(n):
		var p := poly[i]
		var q := poly[(i + 1) % n]
		area += p.x * q.y - q.x * p.y
	for i in range(n):
		var j := (i + 1) % n
		var d := poly[j] - poly[i]
		var o := Vector2(d.y, -d.x) if area > 0.0 else Vector2(-d.y, d.x)
		var hint := Vector3(o.x, 0.0, o.y)
		var a3 := Vector3(poly[i].x, y0, poly[i].y)
		var b3 := Vector3(poly[j].x, y0, poly[j].y)
		var c3 := Vector3(top[j].x, y1, top[j].y)
		var d3 := Vector3(top[i].x, y1, top[i].y)
		_tri(st, a3, b3, c3, hint)
		_tri(st, a3, c3, d3, hint)
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = mat
	return mi


# مثلث بتدوير صحيح (Godot يعتبر الوجه الأمامي باتجاه عقارب الساعة)
func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, hint: Vector3) -> void:
	var g := (b - a).cross(c - a)
	if g.length_squared() < 0.0000000001:
		return
	if g.dot(hint) > 0.0:
		var t := b
		b = c
		c = t
		g = -g
	var nrm := -g.normalized()
	for v in [a, b, c]:
		st.set_normal(nrm)
		st.add_vertex(v)


func _cyl(r_top: float, r_bot: float, h: float, pos: Vector3, mat: Material, along_z: bool) -> void:
	_cyl_in(_root, r_top, r_bot, h, pos, mat, along_z)


func _cyl_in(parent: Node3D, r_top: float, r_bot: float, h: float, pos: Vector3, mat: Material, along_z: bool) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r_top
	cm.bottom_radius = r_bot
	cm.height = h
	cm.radial_segments = 20
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	if along_z:
		mi.rotation_degrees.x = 90.0
	parent.add_child(mi)


func _box(size: Vector3, pos: Vector3, mat: Material) -> void:
	_box_in(_root, size, pos, mat)


func _box_in(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)


func _add_flame(pos: Vector3, radius: float) -> void:
	var holder := Node3D.new()
	holder.position = pos
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = radius
	cm.height = 1.8
	cm.radial_segments = 12
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(glow_col.r, glow_col.g, glow_col.b, 0.55)
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	mi.rotation_degrees.x = 90.0
	mi.position = Vector3(0, 0, 0.9)
	holder.add_child(mi)
	_root.add_child(holder)
	_flames.append(holder)
