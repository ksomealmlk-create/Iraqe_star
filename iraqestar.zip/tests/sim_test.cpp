// Headless checks for the sim: solo regression, co-op, pvp and the network snapshot round trip.
#include "../src/sim/run.hpp"
#include <cstdio>
using namespace nj;

static V2 botMove(Run &r, int pi, bool chaseFoe) {
	const Ship &sh = r.pl[pi].ship;
	V2 mv;
	float best = 1e9f;
	V2 away;
	for (auto &a : r.asteroids) { float d = dist(a.p, sh.p); if (d < best) { best = d; away = sh.p - a.p; } }
	for (auto &e : r.enemies) { float d = dist(e.p, sh.p) * 0.7f; if (d < best) { best = d; away = sh.p - e.p; } }
	for (auto &b : r.ebullets) { float d = dist(b.p, sh.p) * 0.8f; if (d < best) { best = d; away = sh.p - b.p; } }
	if (best < 260) mv = away.norm();
	else mv = V2::fromAngle(r.t * 0.3f + (float)pi * 3.0f) * 0.4f;
	for (auto &p : r.pickups) if (dist(p.p, sh.p) < 500 && best > 200) { mv = (p.p - sh.p).norm(); break; }
	if (chaseFoe && r.np == 2 && !r.pl[1 - pi].dead && best > 200) mv = (r.pl[1 - pi].ship.p - sh.p).norm() * 0.8f;
	return mv;
}

static bool finite(V2 v) { return v.x == v.x && v.y == v.y && std::fabs(v.x) < 1e7f && std::fabs(v.y) < 1e7f; }

static int soloTest() {
	double total = 0;
	for (int seed = 1; seed <= 4; seed++) {
		Profile prof; prof.pilot = seed % N_PILOT;
		Run r(&prof, prof.pilot, seed);
		r.setView(1080, 2000);
		float dt = 1.0f / 60;
		while (!r.over && r.t < 600) {
			r.setMove(botMove(r, 0, false));
			r.update(dt);
			if (r.pl[0].choosing) r.choose(0);
			r.sfx.clear(); r.toasts.clear();
			if (!finite(r.pl[0].ship.p)) { printf("solo NaN\n"); return 1; }
		}
		printf("solo seed %d: t=%.0fs kills=%d yen=%d weapons=%zu died=%d\n", seed, r.t, r.pl[0].kills, r.pl[0].yenEarned, r.pl[0].weapons.size(), (int)r.died);
		if (!r.over) r.retreat();
		total += r.t;
	}
	printf("solo avg %.0fs\n", total / 4);
	return 0;
}

static int multiTest(GameMode mode, int seed, bool roundTrip) {
	Profile p0; p0.pilot = 2;
	int store1[N_STORE] = {1, 1, 0, 2, 0, 0, 0, 0};
	Run host(&p0, 2, seed, mode, 5, store1);
	host.setView(1150, 2800);
	Profile dummy;
	Run guest(nullptr, 2, seed, mode, 5, nullptr);
	guest.remote = true;
	float dt = 1.0f / 60;
	size_t maxBytes = 0, totBytes = 0, packets = 0;
	float maxDx = 0, maxDy = 0;
	int frame = 0;
	std::vector<uint8_t> buf;
	while (!host.over && host.t < 420) {
		for (int i = 0; i < 2; i++) host.setMove(i, botMove(host, i, mode == GM_PVP));
		host.update(dt);
		for (int i = 0; i < 2; i++) if (host.pl[i].choosing) host.choose(i, 0);
		host.sfx.clear(); host.toasts.clear();
		for (int i = 0; i < 2; i++) if (!finite(host.pl[i].ship.p)) { printf("mp NaN\n"); return 1; }
		if (!host.pl[0].dead && !host.pl[1].dead) {
			maxDx = std::max(maxDx, std::fabs(host.pl[0].ship.p.x - host.pl[1].ship.p.x));
			maxDy = std::max(maxDy, std::fabs(host.pl[0].ship.p.y - host.pl[1].ship.p.y));
		}
		if (roundTrip && ++frame % 3 == 0) {
			host.writeSnapshot(buf);
			maxBytes = std::max(maxBytes, buf.size());
			totBytes += buf.size();
			packets++;
			if (!guest.readSnapshot(buf.data(), buf.size())) { printf("snapshot rejected at t=%.1f (%zu bytes)\n", host.t, buf.size()); return 1; }
			if (guest.asteroids.size() != host.asteroids.size() || guest.enemies.size() != host.enemies.size() || guest.shots.size() != std::min<size_t>(host.shots.size(), 400)) {
				printf("entity count mismatch\n"); return 1;
			}
			for (int i = 0; i < 2; i++)
				if (dist(guest.pl[i].ship.p, host.pl[i].ship.p) > 0.01f || guest.pl[i].weapons.size() != std::min<size_t>(host.pl[i].weapons.size(), 8) ||
					guest.pl[i].dead != host.pl[i].dead || guest.pl[i].kills != host.pl[i].kills) { printf("player mismatch\n"); return 1; }
			for (size_t k = 0; k < host.asteroids.size(); k++)
				if (dist(guest.asteroids[k].p, host.asteroids[k].p) > 0.6f) { printf("asteroid pos mismatch %.2f\n", dist(guest.asteroids[k].p, host.asteroids[k].p)); return 1; }
			guest.extrapolate(dt * 2);
			guest.sfx.clear();
			if (guest.pl[0].choosing && guest.pl[0].options.empty()) { printf("choosing without options\n"); return 1; }
		}
	}
	printf("%s seed %d: t=%.0fs over=%d winner=%d | p0 kills=%d hp=%.0f dead=%d | p1 kills=%d hp=%.0f dead=%d | maxSep=(%.0f,%.0f)",
		mode == GM_PVP ? "pvp " : "coop", seed, host.t, (int)host.over, host.winner, host.pl[0].kills, host.pl[0].ship.hp, (int)host.pl[0].dead,
		host.pl[1].kills, host.pl[1].ship.hp, (int)host.pl[1].dead, maxDx, maxDy);
	if (roundTrip && packets) printf(" | snapshot avg=%zuB max=%zuB (%.0f KB/s @20Hz)", totBytes / packets, maxBytes, (double)totBytes / packets * 20 / 1024);
	printf("\n");
	if (maxDx > MP_TETHER_X + 1 || maxDy > MP_TETHER_Y + 1) { printf("tether violated\n"); return 1; }
	return 0;
}

int main() {
	if (soloTest()) return 1;
	for (int s = 1; s <= 3; s++) if (multiTest(GM_COOP, s, true)) return 1;
	for (int s = 1; s <= 3; s++) if (multiTest(GM_PVP, s, true)) return 1;
	printf("ALL OK\n");
	return 0;
}
