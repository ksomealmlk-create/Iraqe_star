// اختبار المتجر الجديد: شراء القطع بالترتيب، صورة الطائرة، المدافع ترمي للأمام، تسريع المحرك.
#include "../src/sim/run.hpp"
#include <cstdio>
using namespace nj;

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); return 1; } } while (0)

int main() {
	Profile p;
	p.yen = 1000000000LL;
	// القطعة 1 مقفولة قبل 0
	CHECK(!p.canBuy(N_STAT + 1));
	CHECK(p.canBuy(N_STAT + 0));
	CHECK(p.shipImage() == 0);
	for (int i = 0; i < N_PART; i++) {
		CHECK(p.canBuy(N_STAT + i));
		CHECK(p.buy(N_STAT + i));
		CHECK(!p.buy(N_STAT + i));            // ما تنشترى مرتين
		CHECK(p.storeCost(N_STAT + i) == -1);
	}
	CHECK(p.shipImage() == 6);
	for (int g = 0; g < N_GUN; g++) CHECK(gunOwned(p.storeLevel, g) && gunRate(p.storeLevel, g) > 1.2f);
	// حفظ/تحميل
	Profile q; q.deserialize(p.serialize());
	for (int i = 0; i < N_STORE; i++) CHECK(q.storeLevel[i] == p.storeLevel[i]);
	// الصور حسب المرحلة
	Profile r; r.yen = 1e9;
	int want[N_PART] = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6};
	for (int i = 0; i < N_PART; i++) { CHECK(r.buy(N_STAT + i)); CHECK(r.shipImage() == want[i]); }

	// المدافع ترمي للأمام (اتجاه مقدمة الطائرة) حتى بدون أعداء
	Run run(&p, 0, 7);
	run.setView(1080, 2000);
	run.asteroids.clear();
	for (int f = 0; f < 120; f++) { run.update(1.0f / 60); if (run.pl[0].choosing) run.choose(0); }
	int guns = 0;
	for (const auto &s : run.shots) {
		if (s.wid != -1) continue;
		guns++;
		V2 d = s.v.norm(), fwd = V2::fromAngle(run.pl[0].ship.ang);
		CHECK(std::fabs(d.dot(fwd) - 1.0f) < 1e-3f);
	}
	printf("gun shots alive after 2s: %d\n", guns);
	CHECK(guns >= 5);
	// المحرك: +18% سرعة
	CHECK(std::fabs(engineSpeedBonus(p.storeLevel) - 0.18f) < 1e-4f);
	// الأسلحة العادية للأمام: نبض بدون هدف يطلق
	Run r2(nullptr, 0, 3);
	r2.setView(1080, 2000);
	r2.asteroids.clear(); r2.enemies.clear();
	bool fired = false;
	for (int f = 0; f < 90 && !fired; f++) {
		r2.update(1.0f / 60);
		for (const auto &s : r2.shots) if (s.wid == W_PULSE) { fired = true; CHECK(s.v.y < -100.0f && std::fabs(s.v.x) < 1.0f); }
	}
	CHECK(fired);
	printf("STORE OK\n");
	return 0;
}
