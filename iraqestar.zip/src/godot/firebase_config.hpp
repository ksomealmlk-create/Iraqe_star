#pragma once
// Firebase (مشروع iraqe-star): إعدادات اللعبة عن بعد من Firestore > config > game
#define FB_API_KEY "AIzaSyA1-sgUsfQ2pYZ9ZTGcq7FQxd5jvSek6h4"
#define FB_PROJECT_ID "iraqe-star"
