#pragma once

#include <algorithm>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include <godot_cpp/classes/audio_stream.hpp>
#include <godot_cpp/classes/audio_stream_player.hpp>
#include <godot_cpp/classes/font.hpp>
#include <godot_cpp/classes/input_event.hpp>
#include <godot_cpp/classes/node2d.hpp>
#include <godot_cpp/classes/texture2d.hpp>
#include <godot_cpp/classes/web_socket_peer.hpp>
#include <godot_cpp/classes/json.hpp>
#include <godot_cpp/variant/array.hpp>
#include <godot_cpp/variant/dictionary.hpp>
#include <godot_cpp/variant/packed_byte_array.hpp>
#include <godot_cpp/variant/color.hpp>
#include <godot_cpp/variant/rect2.hpp>
#include <godot_cpp/variant/vector2.hpp>

#include "../sim/run.hpp"

namespace godot {

class NujoomGame : public Node2D {
	GDCLASS(NujoomGame, Node2D)

public:
	enum Screen { SC_MENU, SC_CREW, SC_STORE, SC_CASINO, SC_ACH, SC_PLAY, SC_OVER, SC_LOBBY, SC_LOOK, SC_SETTINGS };
	enum BtnId {
		B_LAUNCH = 1, B_CREW, B_STORE, B_CASINO, B_ACH, B_BACK, B_PAUSE, B_RESUME, B_RETREAT, B_OVER_OK, B_SPIN,
		B_ONLINE, B_NET_CREATE, B_NET_JOIN, B_NET_DEL, B_NET_GO, B_NET_START, B_NET_COOP, B_NET_PVP, B_LOOK,
		B_CHOOSE = 100, B_STORE_TILE = 200, B_CREW_TILE = 300, B_NET_DIGIT = 400, B_LOOK_COLOR = 500, B_LOOK_FIELD = 520, B_STORE_TAB = 540, B_STORE_RESET = 545, B_PLANE_TILE = 560, B_PLANE_ACT = 580, B_PLANE_OFF = 581, B_DIFF = 600, B_SET_SFX = 610, B_SET_MUSIC = 611, B_SETTINGS = 620
	};
	struct Btn {
		int id;
		Rect2 r;
	};
	struct Toast {
		std::string s;
		float t;
	};

private:
	nj::Profile prof;
	std::unique_ptr<nj::Run> run;
	Screen screen = SC_MENU;
	float W = 960, H = 2142, u = 1.0f, clock = 0;
	bool paused = false;
	std::vector<Btn> btns;
	int pressBtn = -1;
	int joyId = -1;
	Vector2 joyCenter, joyPos, joyVec;
	std::vector<Toast> toasts;
	int crewFocus = 0;
	std::string storeMsg;
	float storeMsgT = 0;
	// المتجر ثلاثي الأبعاد: تبويب، والطائرة المعروضة (مع انتقال سلس بين المراحل)
	int storeTab = 0;
	int planeFocus = 0;   // الطائرة المعروضة تفاصيلها بقسم الطائرات
	int storeImg = -1, storePrevImg = 0;
	float storeFade = 1.0f, storeSpark = 0.0f;
	int storeSparkPart = -1;

	// casino
	float spinT = 0;
	int reels[3] = {0, 1, 2};
	int finalReels[3] = {0, 1, 2};
	int spinPayout = 0;
	bool spinning = false, spinResultShown = true;
	std::string casinoMsg;

	// online (Cloudflare Worker + WebSocket). The host (netYou == 0) runs the whole game with both ships;
	// the guest sends its stick and draws the snapshots it receives.
	enum NetState { NS_IDLE, NS_JOIN_INPUT, NS_CONNECTING, NS_ROOM };
	Ref<WebSocketPeer> ws;
	NetState netState = NS_IDLE;
	std::string netCode, netInput, netMsg;
	int netYou = -1, netPlayers = 0;
	bool netOpen = false, duel = false, lastDuel = false;
	nj::GameMode netMode = nj::GM_COOP;
	float netConnT = 0, snapT = 0, inSendT = 0, helloT = 0, peerMoveT = 0, chooseHideT = 0;
	bool peerHello = false, peerLeft = false;
	int peerPilot = 0, hostPilot = 0;
	int peerPlane = -1, peerColor = 0, hostPlane = -1, hostColor = 0;   // طيارة الخصم (شكلها ولونها)
	int hostStore[nj::N_STORE] = {};
	int peerStore[nj::N_STORE] = {};
	nj::V2 peerMove;
	std::vector<uint8_t> snapBuf;

	// last run summary
	struct PSum {
		int kills = 0, yen = 0;
		bool dead = false, quit = false;
	};
	PSum lastSum[2];
	int lastNp = 1, lastMe = 0, lastWinner = -1;
	nj::GameMode lastMode = nj::GM_SOLO;
	bool lastDied = false;
	float lastTime = 0;
	int lastKills = 0, lastYen = 0, lastStreak = 0, lastBoss = 0;

	// resources
	Ref<Font> fontLat, fontAr;
	std::map<std::string, Ref<Texture2D>> texCache;
	std::map<std::string, Ref<AudioStream>> sndCache;
	std::vector<AudioStreamPlayer *> sfxPlayers;
	AudioStreamPlayer *music = nullptr;
	std::string musicName;
	int sfxNext = 0;
	double sfxLast[64] = {};
	std::vector<Vector2> stars[3];

	// helpers
	static String S(const std::string &s) { return String::utf8(s.c_str()); }
	static Color Cc(uint32_t argb, float am = 1.0f);
	Ref<Texture2D> tex(const std::string &path);
	Ref<AudioStream> snd(const std::string &path);
	Ref<Font> loadFont(const char *path);
	void playSfx(const std::string &name, double minGap = 0.05);
	void playSfxId(int id);
	void playMusic(const std::string &name);
	void loadProfile();
	void saveProfile();
	void goTo(Screen s);
	void startRun(bool asDuel = false, uint64_t seed = 0);
	void endRun();
	void onButton(int id);
	int btnAt(Vector2 p) const;
	void addToast(const std::string &s);

	int me() const { return (duel && netYou == 1) ? 1 : 0; }
	void netSendBin(const std::vector<uint8_t> &v);
	void sendHello();
	void netConnect(const std::string &code);
	void netClose();
	void netPoll(float dt);
	void netHandle(const String &msg);
	void netSend(const Dictionary &d);

	// drawing helpers
	void text(const std::string &s, float x, float y, float size, Color c, int align = 1, bool shadow = true);
	void button(int id, Rect2 r, const std::string &label, Color col, float fs = 34.0f);
	void panel(Rect2 r, Color fill, Color line);
	void bar(Rect2 r, float frac, Color fill, Color back);
	void icon(const std::string &path, Rect2 r, Color mod = Color(1, 1, 1, 1));
	void polyFill(const std::vector<Vector2> &pts, Color fill, Color line, float lw);
	void glow(Vector2 c, float r, Color col);
	void drawBackground(Vector2 cam, float scale);
	void drawHeader(const std::string &title);

	void drawMenu();
	void drawCrew();
	void drawStore();
	void drawStoreParts(Rect2 area);
	void drawStorePlanes(Rect2 area);
	void drawSettings();
	void drawGear(Vector2 c, float r, Color col);
	void drawStoreStats(Rect2 area);
	void drawShipShowcase(Rect2 a);
	Rect2 card3d(int id, Rect2 r, Color fill, Color edge);
	void textFit(const std::string &s, float x, float y, float size, float maxW, Color c, int align = 1);
	Ref<Texture2D> shipTexFor(int img, float *k);
	void drawCasino();
	void drawAch();
	void drawLook();
	void drawOver();
	void drawLobby();
	void drawWorld();
	void drawHud();
	void drawChoose();
	void drawPause();
	void drawToasts();

	void startSpin();
	std::string weaponIcon(int id) const { return std::string("res://assets/icons/weapons/icon_weapon_") + nj::WEAPONS[id].key + ".png"; }
	std::string passiveIcon(int id) const { return std::string("res://assets/icons/passives/icon_passive_") + nj::PASSIVES[id].key + ".png"; }

protected:
	static void _bind_methods() {}
	void _notification(int p_what);

public:
	void _ready() override;
	void _process(double delta) override;
	void _draw() override;
	void _input(const Ref<InputEvent> &event) override;
};

} // namespace godot
