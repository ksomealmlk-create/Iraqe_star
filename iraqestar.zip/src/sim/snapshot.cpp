// نجوم العراق - network snapshots (host -> guest) for the shared-screen online mode.
// The host runs the whole simulation; the guest only receives these packets and draws them.
#include "run.hpp"

#include <cstring>

namespace nj {

namespace {

const float AST_R[3] = {15, 30, 50};
const uint8_t MAGIC = 0xA7;
const uint8_t VERSION = 1;

struct Wr {
	std::vector<uint8_t> &b;
	explicit Wr(std::vector<uint8_t> &out) : b(out) {}
	void u8(unsigned v) { b.push_back((uint8_t)(v & 255)); }
	void u16(unsigned v) { u8(v); u8(v >> 8); }
	void u32(uint32_t v) { for (int i = 0; i < 4; i++) u8(v >> (8 * i)); }
	void i16(int v) { u16((uint16_t)(int16_t)v); }
	void f32(float f) { uint32_t u; std::memcpy(&u, &f, 4); u32(u); }
	void frac(float f) { u8((unsigned)clampf(f * 255.0f + 0.5f, 0.0f, 255.0f)); }
	void ang(float a) {
		float k = std::fmod(a, TAU);
		if (k < 0) k += TAU;
		u8((unsigned)(k / TAU * 256.0f) & 255);
	}
	void rel(V2 p, V2 c) {
		i16((int)clampf(std::round((p.x - c.x) * 2.0f), -32767.0f, 32767.0f));
		i16((int)clampf(std::round((p.y - c.y) * 2.0f), -32767.0f, 32767.0f));
	}
	void vel(V2 v) {
		i16((int)clampf(std::round(v.x * 8.0f), -32767.0f, 32767.0f));
		i16((int)clampf(std::round(v.y * 8.0f), -32767.0f, 32767.0f));
	}
};

struct Rd {
	const uint8_t *p;
	size_t n, i = 0;
	bool ok = true;
	Rd(const uint8_t *d, size_t len) : p(d), n(len) {}
	unsigned u8() { if (i + 1 > n) { ok = false; return 0; } return p[i++]; }
	unsigned u16() { unsigned a = u8(); unsigned b = u8(); return a | (b << 8); }
	uint32_t u32() { uint32_t v = 0; for (int k = 0; k < 4; k++) v |= (uint32_t)u8() << (8 * k); return v; }
	int i16() { return (int)(int16_t)(uint16_t)u16(); }
	float f32() { uint32_t u = u32(); float f; std::memcpy(&f, &u, 4); return f; }
	float frac() { return (float)u8() / 255.0f; }
	float ang() { return (float)u8() * TAU / 256.0f; }
	V2 rel(V2 c) { float x = (float)i16() * 0.5f; float y = (float)i16() * 0.5f; return V2(c.x + x, c.y + y); }
	V2 vel() { float x = (float)i16() / 8.0f; float y = (float)i16() / 8.0f; return V2(x, y); }
	bool count(size_t &out, size_t cap) { out = u16(); if (out > cap) { ok = false; out = 0; } return ok; }
};

} // namespace

// ------------------------------------------------------------------ write
void Run::writeSnapshot(std::vector<uint8_t> &out) {
	out.clear();
	Wr w(out);
	V2 c = camCenter;
	w.u8(MAGIC);
	w.u8(VERSION);
	w.u8((over ? 1 : 0) | (died ? 2 : 0) | (boss.active ? 4 : 0));
	w.u8((unsigned)(winner + 1));
	w.u32(++snapSeq);
	w.f32(t);
	w.f32(c.x);
	w.f32(c.y);
	w.u8(np);
	w.u8(mode);
	w.frac(bossAnnounce / 4.0f);
	w.u16(bossKills);

	for (int i = 0; i < np; i++) {
		const Player &p = pl[i];
		w.u8((p.dead ? 1 : 0) | (p.choosing ? 2 : 0) | (p.beamOn ? 4 : 0) | (p.quit ? 8 : 0) | (p.revived ? 16 : 0));
		w.u8(p.pilot);
		w.f32(p.ship.p.x);
		w.f32(p.ship.p.y);
		w.vel(p.ship.v);
		w.ang(p.ship.ang);
		w.f32(p.ship.hp);
		w.f32(p.ship.maxHp);
		w.f32(p.ship.sh);
		w.f32(p.ship.maxSh);
		w.u8((unsigned)clampf(p.ship.invuln * 100.0f, 0, 255));
		w.frac(p.ship.moveFrac);
		w.frac(p.hitFlash / 0.25f);
		w.u16(p.kills);
		w.u16(p.bestStreak);
		w.u32((uint32_t)p.yenEarned);
		w.u16(p.upgradesTaken);
		w.u16((unsigned)clampf(p.cryoVis, 0, 65000));
		for (int k = 0; k < P_COUNT; k++) w.u8(p.pas[k]);
		w.u8((unsigned)std::min<size_t>(p.weapons.size(), 8));
		for (size_t k = 0; k < p.weapons.size() && k < 8; k++) {
			w.u8(p.weapons[k].id);
			w.u8(p.weapons[k].lvl);
			w.f32(p.weapons[k].ang);
		}
		if (p.choosing) {
			w.u8((unsigned)std::min<size_t>(p.options.size(), 6));
			for (size_t k = 0; k < p.options.size() && k < 6; k++) {
				w.u8(p.options[k].kind);
				w.u8(p.options[k].a);
			}
		}
		if (p.beamOn) {
			w.f32(p.beamA.x); w.f32(p.beamA.y);
			w.f32(p.beamB.x); w.f32(p.beamB.y);
			w.u8((unsigned)clampf(p.beamW, 0, 255));
		}
	}

	size_t n;
	n = std::min<size_t>(asteroids.size(), 160);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const Asteroid &a = asteroids[i];
		w.rel(a.p, c);
		w.vel(a.v);
		w.ang(a.rot);
		w.u8((unsigned)(int)clampf(std::round(a.rv * 50.0f), -127, 127) & 255);
		w.u8((a.size & 3) | ((a.type & 7) << 2) | (a.flash > 0 ? 32 : 0) | (a.slowT > 0 ? 64 : 0));
		w.frac(a.maxhp > 0 ? a.hp / a.maxhp : 0);
		w.u32(a.seed);
	}

	n = std::min<size_t>(enemies.size(), 60);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const Enemy &e = enemies[i];
		w.rel(e.p, c);
		w.vel(e.v);
		w.u8(e.type);
		w.frac(e.maxhp > 0 ? e.hp / e.maxhp : 0);
		w.ang(e.ang);
		w.frac(e.alpha);
		w.u8((e.flash > 0 ? 1 : 0) | (e.slowT > 0 ? 2 : 0));
	}

	if (boss.active) {
		w.f32(boss.p.x); w.f32(boss.p.y);
		V2 bv = boss.dashing > 0 ? boss.dashDir * 950.0f : boss.v;
		w.vel(bv);
		w.f32(boss.hp);
		w.f32(boss.maxhp);
		w.u8(boss.flash > 0 ? 1 : 0);
		w.u8(boss.telegraph > 0 ? 1 : 0);
		w.u8(boss.phase);
		w.u8(boss.index);
	}

	n = std::min<size_t>(ebullets.size(), 600);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const EBullet &b = ebullets[i];
		w.rel(b.p, c);
		w.vel(b.v);
		w.u8((unsigned)clampf(b.r * 4.0f, 0, 255));
		w.u8(b.kind);
		w.u32(b.col);
	}

	n = std::min<size_t>(shots.size(), 400);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const Shot &s = shots[i];
		w.rel(s.p, c);
		w.vel(s.v);
		w.u8(s.kind);
		w.u8((unsigned)clampf(s.r * 4.0f, 0, 255));
		w.u32(s.col);
	}

	n = std::min<size_t>(pickups.size(), 200);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const Pickup &k = pickups[i];
		w.rel(k.p, c);
		w.u8(k.kind);
		w.u8((unsigned)clampf(k.life * 8.0f, 0, 255));
	}

	n = std::min<size_t>(mines.size(), 60);
	w.u8(n);
	for (size_t i = 0; i < n; i++) {
		const Mine &m = mines[i];
		w.rel(m.p, c);
		w.u16((unsigned)clampf(m.t * 100.0f, 0, 65000));
		w.u8((m.t > m.arm ? 1 : 0) | (m.jackpot ? 2 : 0));
	}

	n = std::min<size_t>(zones.size(), 200);
	w.u16(n);
	for (size_t i = 0; i < n; i++) {
		const Zone &z = zones[i];
		w.rel(z.p, c);
		w.u8((unsigned)clampf(z.r, 0, 255));
		w.u8((z.kind & 15) | (z.hostile ? 16 : 0));
		w.frac(z.maxLife > 0 ? clampf(z.life / z.maxLife, 0, 1) : 0);
		w.u32(z.col);
		w.ang(z.ang);
	}

	n = std::min<size_t>(fxOut.size(), 90);
	w.u8(n);
	for (size_t i = 0; i < n; i++) {
		const Fx &f = fxOut[i];
		w.u8(f.kind);
		w.rel(f.a, c);
		if (f.kind == FX_LINE) w.rel(f.b, c);
		w.vel(f.v);
		w.u8((unsigned)clampf(f.life * 50.0f, 1, 255));
		w.u16((unsigned)clampf(f.size, 0, 65000));
		w.u32(f.col);
		if (f.kind == FX_TEXT) {
			size_t len = std::min<size_t>(f.txt.size(), 12);
			w.u8(len);
			for (size_t k = 0; k < len; k++) w.u8((uint8_t)f.txt[k]);
		}
	}
	fxOut.clear();

	n = std::min<size_t>(sfxOut.size(), 24);
	w.u8(n);
	for (size_t i = 0; i < n; i++) w.u8(sfxOut[i]);
	sfxOut.clear();
}

// ------------------------------------------------------------------ read
bool Run::readSnapshot(const uint8_t *data, size_t len) {
	Rd r(data, len);
	if (r.u8() != MAGIC || r.u8() != VERSION) return false;
	unsigned flags = r.u8();
	int win = (int)r.u8() - 1;
	uint32_t seq = r.u32();
	if (seq != 0 && seq <= snapSeq && snapSeq - seq < 100000) return false;   // stale / duplicate
	float nt = r.f32();
	V2 c;
	c.x = r.f32();
	c.y = r.f32();
	int hnp = (int)r.u8();
	int hmode = (int)r.u8();
	float announce = r.frac() * 4.0f;
	int bk = (int)r.u16();
	if (!r.ok || hnp != np || hmode != (int)mode) return false;

	Player np_[2];
	for (int i = 0; i < np; i++) {
		Player &p = np_[i];
		p = pl[i];   // keeps prof pointer / store levels
		unsigned pf = r.u8();
		p.dead = pf & 1;
		p.choosing = pf & 2;
		p.beamOn = pf & 4;
		p.quit = pf & 8;
		p.revived = pf & 16;
		p.pilot = (int)r.u8();
		if (p.pilot >= N_PILOT) p.pilot = 0;
		p.ship.p.x = r.f32();
		p.ship.p.y = r.f32();
		p.ship.v = r.vel();
		p.ship.ang = r.ang();
		p.ship.hp = r.f32();
		p.ship.maxHp = r.f32();
		p.ship.sh = r.f32();
		p.ship.maxSh = r.f32();
		p.ship.invuln = (float)r.u8() / 100.0f;
		p.ship.moveFrac = r.frac();
		p.hitFlash = r.frac() * 0.25f;
		p.kills = (int)r.u16();
		p.bestStreak = (int)r.u16();
		p.yenEarned = (int)r.u32();
		p.upgradesTaken = (int)r.u16();
		p.cryoVis = (float)r.u16();
		for (int k = 0; k < P_COUNT; k++) p.pas[k] = (int)r.u8();
		size_t nw = r.u8();
		if (nw > 8) return false;
		p.weapons.clear();
		for (size_t k = 0; k < nw; k++) {
			WeaponInst wi;
			wi.id = (int)r.u8();
			wi.lvl = (int)r.u8();
			wi.ang = r.f32();
			if (wi.id < 0 || wi.id >= W_COUNT) return false;
			p.weapons.push_back(wi);
		}
		p.options.clear();
		if (p.choosing) {
			size_t no = r.u8();
			if (no > 6) return false;
			for (size_t k = 0; k < no; k++) {
				Option o;
				o.kind = (int)r.u8();
				o.a = (int)r.u8();
				p.options.push_back(o);
			}
		}
		if (p.beamOn) {
			p.beamA.x = r.f32(); p.beamA.y = r.f32();
			p.beamB.x = r.f32(); p.beamB.y = r.f32();
			p.beamW = (float)r.u8();
		}
	}

	size_t n;
	std::vector<Asteroid> na;
	if (!r.count(n, 160)) return false;
	for (size_t i = 0; i < n; i++) {
		Asteroid a;
		a.p = r.rel(c);
		a.v = r.vel();
		a.rot = r.ang();
		a.rv = (float)(int)(int8_t)r.u8() / 50.0f;
		unsigned f = r.u8();
		a.size = f & 3;
		if (a.size > 2) a.size = 2;
		a.type = (f >> 2) & 7;
		if (a.type > 5) a.type = 5;
		a.flash = (f & 32) ? 0.1f : 0;
		a.slowT = (f & 64) ? 0.3f : 0;
		a.r = AST_R[a.size];
		a.maxhp = 255.0f;
		a.hp = r.frac() * 255.0f;
		a.seed = r.u32();
		na.push_back(a);
	}

	std::vector<Enemy> ne;
	if (!r.count(n, 60)) return false;
	for (size_t i = 0; i < n; i++) {
		Enemy e;
		e.p = r.rel(c);
		e.v = r.vel();
		e.type = (int)r.u8();
		if (e.type >= N_ENEMY) return false;
		e.maxhp = 255.0f;
		e.hp = r.frac() * 255.0f;
		e.ang = r.ang();
		e.alpha = r.frac();
		unsigned f = r.u8();
		e.flash = (f & 1) ? 0.1f : 0;
		e.slowT = (f & 2) ? 0.3f : 0;
		e.r = ENEMIES[e.type].radius * ENEMY_SIZE_MULT;
		ne.push_back(e);
	}

	Boss nb;
	if (flags & 4) {
		nb.active = true;
		nb.p.x = r.f32(); nb.p.y = r.f32();
		nb.v = r.vel();
		nb.hp = r.f32();
		nb.maxhp = r.f32();
		nb.flash = r.u8() ? 0.08f : 0;
		nb.telegraph = r.u8() ? 0.5f : 0;
		nb.phase = (int)r.u8();
		nb.index = (int)r.u8();
	}

	std::vector<EBullet> nbul;
	if (!r.count(n, 600)) return false;
	for (size_t i = 0; i < n; i++) {
		EBullet b;
		b.p = r.rel(c);
		b.v = r.vel();
		b.r = (float)r.u8() / 4.0f;
		b.kind = (int)r.u8();
		b.col = r.u32();
		b.life = 1.0f;
		nbul.push_back(b);
	}

	std::vector<Shot> nsh;
	if (!r.count(n, 400)) return false;
	for (size_t i = 0; i < n; i++) {
		Shot s;
		s.p = r.rel(c);
		s.v = r.vel();
		s.kind = (int)r.u8();
		s.r = (float)r.u8() / 4.0f;
		s.col = r.u32();
		s.life = 1.0f;
		nsh.push_back(s);
	}

	std::vector<Pickup> npk;
	if (!r.count(n, 200)) return false;
	for (size_t i = 0; i < n; i++) {
		Pickup k;
		k.p = r.rel(c);
		k.kind = (int)r.u8();
		k.life = (float)r.u8() / 8.0f;
		npk.push_back(k);
	}

	std::vector<Mine> nm;
	n = r.u8();
	if (n > 60) return false;
	for (size_t i = 0; i < n; i++) {
		Mine m;
		m.p = r.rel(c);
		m.t = (float)r.u16() / 100.0f;
		unsigned f = r.u8();
		m.arm = (f & 1) ? 0.0f : 1e9f;   // armed flag is all the renderer needs (t > arm)
		m.jackpot = (f & 2) != 0;
		nm.push_back(m);
	}

	std::vector<Zone> nz;
	if (!r.count(n, 200)) return false;
	for (size_t i = 0; i < n; i++) {
		Zone z;
		z.p = r.rel(c);
		z.r = (float)r.u8();
		unsigned kf = r.u8();
		z.kind = (int)(kf & 15);
		z.hostile = (kf & 16) != 0;
		z.maxLife = 1.0f;
		z.life = r.frac();
		z.col = r.u32();
		z.ang = r.ang();
		nz.push_back(z);
	}

	std::vector<Fx> nfx;
	n = r.u8();
	if (n > 90) return false;
	for (size_t i = 0; i < n; i++) {
		Fx f;
		f.kind = (int)r.u8();
		f.a = r.rel(c);
		if (f.kind == FX_LINE) f.b = r.rel(c);
		f.v = r.vel();
		f.life = (float)r.u8() / 50.0f;
		f.size = (float)r.u16();
		f.col = r.u32();
		if (f.kind == FX_TEXT) {
			size_t tl = r.u8();
			if (tl > 12) return false;
			for (size_t k = 0; k < tl; k++) f.txt.push_back((char)r.u8());
		}
		nfx.push_back(f);
	}

	std::vector<int> nsfx;
	n = r.u8();
	if (n > 24) return false;
	for (size_t i = 0; i < n; i++) nsfx.push_back((int)r.u8());
	if (!r.ok) return false;

	// ---- commit
	snapSeq = seq;
	over = flags & 1;
	died = flags & 2;
	winner = win;
	t = nt;
	camCenter = c;
	bossAnnounce = announce;
	bossKills = bk;
	for (int i = 0; i < np; i++) pl[i] = np_[i];
	asteroids.swap(na);
	enemies.swap(ne);
	boss = nb;
	ebullets.swap(nbul);
	shots.swap(nsh);
	pickups.swap(npk);
	mines.swap(nm);
	zones.swap(nz);
	for (auto &f : nfx) if (fx.size() < 420) fx.push_back(f);
	for (int id : nsfx) if (sfx.size() < 48) sfx.push_back(id);
	return true;
}

// ------------------------------------------------------------------ guest-side smoothing between snapshots
void Run::extrapolate(float dt) {
	if (dt > 0.1f) dt = 0.1f;
	if (dt <= 0 || over) return;
	t += dt;
	if (bossAnnounce > 0) bossAnnounce -= dt;
	for (int i = 0; i < np; i++) {
		Player &p = pl[i];
		if (!p.dead) {
			p.ship.p += p.ship.v * dt;
			if (p.ship.invuln > 0) p.ship.invuln -= dt;
		}
		if (p.hitFlash > 0) p.hitFlash -= dt;
		for (auto &w : p.weapons) {
			if (w.id == W_SAW) w.ang += 3.4f * dt;
			else if (w.id == W_ORBIT) w.ang += 2.2f * dt;
			else if (w.id == W_FROST) w.ang += 2.6f * dt;
		}
	}
	for (auto &a : asteroids) { a.p += a.v * dt; a.rot += a.rv * dt; }
	for (auto &e : enemies) e.p += e.v * dt;
	if (boss.active) boss.p += boss.v * dt;
	for (auto &b : ebullets) b.p += b.v * dt;
	for (auto &s : shots) s.p += s.v * dt;
	for (auto &m : mines) m.t += dt;
	for (auto &z : zones) if (z.kind == ZK_BLADE) z.ang += 14.0f * dt;
	for (auto &k : pickups) k.life -= dt;
	updateFx(dt);
	updateCamera(dt, false);
}

} // namespace nj
