#include "profile.hpp"

#include <cstdio>
#include <cstdlib>
#include <sstream>

namespace nj {

static std::string joinInts(const int *a, int n) {
	std::string s;
	for (int i = 0; i < n; i++) {
		if (i) s += ",";
		s += std::to_string(a[i]);
	}
	return s;
}
template <typename T>
static std::string joinBools(const T *a, int n) {
	std::string s;
	for (int i = 0; i < n; i++) s += a[i] ? '1' : '0';
	return s;
}
static void parseInts(const std::string &v, int *a, int n) {
	std::stringstream ss(v);
	std::string tok;
	int i = 0;
	while (std::getline(ss, tok, ',') && i < n) a[i++] = std::atoi(tok.c_str());
}
static void parseBools(const std::string &v, bool *a, int n) {
	for (int i = 0; i < n && i < (int)v.size(); i++) a[i] = v[i] == '1';
}

std::string Profile::serialize() const {
	std::string s;
	auto kv = [&](const char *k, const std::string &v) { s += k; s += "="; s += v; s += "\n"; };
	kv("yen", std::to_string(yen));
	kv("totalYenEarned", std::to_string(totalYenEarned));
	kv("totalKills", std::to_string(totalKills));
	kv("bestStreak", std::to_string(bestStreak));
	kv("bestSurvival", std::to_string(bestSurvival));
	kv("totalDeaths", std::to_string(totalDeaths));
	kv("totalDamageTaken", std::to_string(totalDamageTaken));
	kv("maxKillsRun", std::to_string(maxKillsRun));
	kv("bestFlight", std::to_string(bestFlight));
	kv("casinoSpins", std::to_string(casinoSpins));
	kv("jackpotWon", jackpotWon ? "1" : "0");
	kv("pilot", std::to_string(pilot));
	kv("introDone", introDone ? "1" : "0");
	kv("store", joinInts(storeLevel, N_STORE));
	kv("weaponSeen", joinBools(weaponSeen, W_COUNT));
	kv("pilotUnlocked", joinBools(pilotUnlocked, N_PILOT));
	kv("ach", joinBools(ach, N_ACH));
	kv("shipColor", std::to_string(shipColor));
	kv("fieldTheme", std::to_string(fieldTheme));
	kv("colorOwned", joinBools(colorOwned, N_SHIP_COLOR));
	kv("fieldOwned", joinBools(fieldOwned, N_FIELD));
	kv("difficulty", std::to_string(difficulty));
	kv("sfxOn", sfxOn ? "1" : "0");
	kv("musicOn", musicOn ? "1" : "0");
	kv("plane", std::to_string(plane));
	kv("planeOwned", joinBools(planeOwned, N_PLANE));
	return s;
}

void Profile::deserialize(const std::string &data) {
	std::stringstream ss(data);
	std::string line;
	while (std::getline(ss, line)) {
		size_t eq = line.find('=');
		if (eq == std::string::npos) continue;
		std::string k = line.substr(0, eq), v = line.substr(eq + 1);
		while (!v.empty() && (v.back() == '\r' || v.back() == ' ')) v.pop_back();
		if (k == "yen") yen = std::atoll(v.c_str());
		else if (k == "totalYenEarned") totalYenEarned = std::atoll(v.c_str());
		else if (k == "totalKills") totalKills = std::atoi(v.c_str());
		else if (k == "bestStreak") bestStreak = std::atoi(v.c_str());
		else if (k == "bestSurvival") bestSurvival = std::atoi(v.c_str());
		else if (k == "totalDeaths") totalDeaths = std::atoi(v.c_str());
		else if (k == "totalDamageTaken") totalDamageTaken = std::atoi(v.c_str());
		else if (k == "maxKillsRun") maxKillsRun = std::atoi(v.c_str());
		else if (k == "bestFlight") bestFlight = std::atoi(v.c_str());
		else if (k == "casinoSpins") casinoSpins = std::atoi(v.c_str());
		else if (k == "jackpotWon") jackpotWon = v == "1";
		else if (k == "pilot") pilot = std::atoi(v.c_str());
		else if (k == "introDone") introDone = v == "1";
		else if (k == "store") parseInts(v, storeLevel, N_STORE);
		else if (k == "weaponSeen") parseBools(v, weaponSeen, W_COUNT);
		else if (k == "pilotUnlocked") parseBools(v, pilotUnlocked, N_PILOT);
		else if (k == "ach") parseBools(v, ach, N_ACH);
		else if (k == "shipColor") shipColor = std::atoi(v.c_str());
		else if (k == "fieldTheme") fieldTheme = std::atoi(v.c_str());
		else if (k == "colorOwned") parseBools(v, colorOwned, N_SHIP_COLOR);
		else if (k == "fieldOwned") parseBools(v, fieldOwned, N_FIELD);
		else if (k == "difficulty") difficulty = std::atoi(v.c_str());
		else if (k == "sfxOn") sfxOn = v == "1";
		else if (k == "musicOn") musicOn = v == "1";
		else if (k == "plane") plane = std::atoi(v.c_str());
		else if (k == "planeOwned") parseBools(v, planeOwned, N_PLANE);
	}
	pilotUnlocked[0] = true;
	colorOwned[0] = true;
	fieldOwned[0] = true;
	if (shipColor < 0 || shipColor >= N_SHIP_COLOR || !colorOwned[shipColor]) shipColor = 0;
	if (fieldTheme < 0 || fieldTheme >= N_FIELD || !fieldOwned[fieldTheme]) fieldTheme = 0;
	if (pilot < 0 || pilot >= N_PILOT || !pilotUnlocked[pilot]) pilot = 0;
	if (plane < 0 || plane >= N_PLANE || !planeOwned[plane]) plane = -1;
	if (difficulty < 0 || difficulty > 2) difficulty = 1;
	for (int i = 0; i < N_STORE; i++) storeLevel[i] = std::max(0, std::min(i < N_STAT ? 5 : 1, storeLevel[i]));
}

int Profile::weaponsDiscovered() const {
	int n = 0;
	for (int i = 0; i < W_BASE_COUNT; i++) n += weaponSeen[i] ? 1 : 0;
	return n;
}
int Profile::evolutionsDiscovered() const {
	int n = 0;
	for (int i = W_BASE_COUNT; i < W_COUNT; i++) n += weaponSeen[i] ? 1 : 0;
	return n;
}

int Profile::storeCost(int tile) const {
	if (tile < 0 || tile >= N_STORE) return -1;
	if (tile >= N_STAT) return storeLevel[tile] > 0 ? -1 : PARTS[tile - N_STAT].price;   // قطعة: تنشترى مرة وحدة
	int lv = storeLevel[tile];
	return (lv >= 0 && lv < 5) ? UPGRADE_COSTS[lv] : -1;
}
bool Profile::canBuy(int tile) const {
	int c = storeCost(tile);
	if (tile >= N_STAT && !partUnlocked(tile - N_STAT)) return false;   // لازم تشتري اللي قبلها
	return c > 0 && yen >= c;
}
bool Profile::buy(int tile) {
	if (!canBuy(tile)) return false;
	yen -= storeCost(tile);
	storeLevel[tile]++;
	return true;
}

bool Profile::buyColor(int i) {
	if (i < 0 || i >= N_SHIP_COLOR || colorOwned[i]) return false;
	if (yen < SHIP_COLORS[i].price) return false;
	yen -= SHIP_COLORS[i].price;
	colorOwned[i] = true;
	return true;
}
bool Profile::buyPlane(int i) {
	if (i < 0 || i >= N_PLANE || planeOwned[i]) return false;
	if (yen < PLANES[i].price) return false;
	yen -= PLANES[i].price;
	planeOwned[i] = true;
	return true;
}
bool Profile::buyField(int i) {
	if (i < 0 || i >= N_FIELD || fieldOwned[i]) return false;
	if (yen < FIELD_THEMES[i].price) return false;
	yen -= FIELD_THEMES[i].price;
	fieldOwned[i] = true;
	return true;
}

bool Profile::meetsUnlock(int i) const {
	const PilotDef &p = PILOTS[i];
	switch (p.unlock) {
		case U_FREE: return true;
		case U_YEN: return totalYenEarned >= p.thr;
		case U_DAMAGE: return totalDamageTaken >= p.thr;
		case U_SURVIVE: return bestSurvival >= p.thr;
		case U_STREAK: return bestStreak >= p.thr;
		case U_DEATHS: return totalDeaths >= p.thr;
		case U_KILLS_RUN: return maxKillsRun >= p.thr;
		case U_WEAPONS: return weaponsDiscovered() >= p.thr;
		case U_EVOS: return evolutionsDiscovered() >= p.thr;
		case U_KILLS: return totalKills >= p.thr;
		case U_JACKPOT: return jackpotWon;
		case U_FLIGHT: return bestFlight >= p.thr;
		case U_ALL: {
			for (int k = 0; k < N_PILOT; k++)
				if (k != i && !pilotUnlocked[k]) return false;
			return true;
		}
	}
	return false;
}

std::vector<int> Profile::refreshPilots() {
	std::vector<int> fresh;
	for (int pass = 0; pass < 2; pass++) // second pass lets ALL_OTHERS resolve
		for (int i = 0; i < N_PILOT; i++) {
			if (!pilotUnlocked[i] && meetsUnlock(i)) {
				pilotUnlocked[i] = true;
				fresh.push_back(i);
			}
		}
	return fresh;
}

std::string Profile::pilotHintAr(int i) const {
	const PilotDef &p = PILOTS[i];
	std::string n = std::to_string(p.thr);
	switch (p.unlock) {
		case U_FREE: return "مفتوح";
		case U_YEN: return "اكسب " + n + " د.ع إجمالاً";
		case U_DAMAGE: return "تلقَّ " + n + " ضرر إجمالاً";
		case U_SURVIVE: return "ابقَ حياً " + std::to_string(p.thr / 60) + " دقائق";
		case U_STREAK: return "سلسلة قتل " + n;
		case U_DEATHS: return "اخسر " + n + " مرة";
		case U_KILLS_RUN: return "اقتل " + n + " أعداء في جولة";
		case U_WEAPONS: return "اكتشف " + n + " أسلحة";
		case U_EVOS: return "اكتشف " + n + " تطويرات";
		case U_KILLS: return "اقتل " + n + " عدو إجمالاً";
		case U_JACKPOT: return "اربح الجائزة الكبرى";
		case U_FLIGHT: return "حلّق " + n + " ثانية بلا ضرر";
		case U_ALL: return "افتح كل الطاقم";
	}
	return "";
}

std::vector<int> Profile::checkAchievements() {
	std::vector<int> fresh;
	bool earned[N_ACH] = {
		totalKills >= 1, totalKills >= 100, totalKills >= 1000, bestStreak >= 20,
		bestSurvival >= 120, totalDeaths >= 1, weaponsDiscovered() >= 5, casinoSpins >= 10,
	};
	for (int i = 0; i < N_ACH; i++)
		if (earned[i] && !ach[i]) {
			ach[i] = true;
			fresh.push_back(i);
		}
	return fresh;
}

std::string formatYen(long long a) {
	char buf[48];
	if (a >= 1000000000) {
		if (a % 1000000000 == 0) std::snprintf(buf, sizeof buf, "%lldB", a / 1000000000);
		else std::snprintf(buf, sizeof buf, "%.1fB", a / 1000000000.0);
	} else if (a >= 1000000) {
		if (a % 1000000 == 0) std::snprintf(buf, sizeof buf, "%lldM", a / 1000000);
		else std::snprintf(buf, sizeof buf, "%.1fM", a / 1000000.0);
	} else if (a >= 10000) {
		if (a % 1000 == 0) std::snprintf(buf, sizeof buf, "%lldK", a / 1000);
		else std::snprintf(buf, sizeof buf, "%.1fK", a / 1000.0);
	} else {
		std::snprintf(buf, sizeof buf, "%lld", a);
	}
	return std::string(buf) + " د.ع";
}

} // namespace nj
