#pragma once
#include "core.hpp"
#include "profile.hpp"

namespace nj {

struct Asteroid {
	V2 p, v;
	float rot = 0, rv = 0, r = 0, hp = 0, maxhp = 0, flash = 0, slowT = 0, slowAmt = 0, trailT = 0;
	int size = 0;  // 0 small 1 medium 2 large
	int type = 0;  // 0 rock 1 ice 2 metal 3 volatile 4 magnetic 5 toxic trail
	uint32_t seed = 0;
	int uid = 0;
};

struct Enemy {
	V2 p, v;
	int by = 0;   // last player who hit it (kill credit)
	int type = 0;
	float hp = 0, maxhp = 0, r = 0, fire = 0, ang = 0, t = 0, aux = 0, flash = 0, slowT = 0, slowAmt = 0, alpha = 1;
	int dir = 1;
	int uid = 0;
};

struct Boss {
	bool active = false;
	V2 p, v, dashDir;
	float hp = 0, maxhp = 0, r = 95, t = 0, fireA = 0, fireB = 0, fireC = 0, dashT = 0, dashing = 0, flash = 0, spiral = 0, telegraph = 0;
	int uid = 0, index = 0, phase = 0, by = 0;
};

struct EBullet {
	V2 p, v;
	float dmg = 0, r = 6, life = 3, expR = 0;
	uint32_t col = 0xFFFF6644;
	int kind = 0; // 0 normal 1 explosive 2 big bomb
};

struct Shot {
	V2 p, v;
	float dmg = 0, r = 5, life = 1, homing = 0, expR = 0, expDmg = 0, heal = 0, trailT = 0, aux = 0;
	int pierce = 0, wid = 0, tgt = -1, bomblets = 0, kind = 0, nhit = 0, owner = 0;
	bool split = false;
	uint32_t col = 0xFFFFFF00;
	int hit[8] = {-1, -1, -1, -1, -1, -1, -1, -1};
};

enum PickupKind { PK_COIN, PK_UPGRADE, PK_HEAL, PK_SHIELD };
struct Pickup {
	V2 p, v;
	int kind = 0;
	float val = 0, life = 22, t = 0;
};

struct Mine {
	V2 p;
	float arm = 0.6f, life = 14, dmg = 0, expR = 0, t = 0;
	int wid = 0, owner = 0;
	bool jackpot = false;
};

struct Boom {
	V2 p;
	float t = 0, r = 0, dmg = 0;
	int wid = 0, owner = 0;
	uint32_t col = 0xFFFFAA44;
};

enum ZoneKind { ZK_BLADE, ZK_GAS, ZK_CORE };
struct Zone {
	V2 p, v;
	float r = 30, life = 1, maxLife = 1, dps = 0, tick = 0.1f, tickT = 0, homing = 0;
	int kind = 0, wid = 0, owner = 0;
	bool hostile = false;
	uint32_t col = 0xFFFFFFFF;
	float ang = 0;
};

enum FxKind { FX_RING, FX_LINE, FX_SPARK, FX_TEXT, FX_FLASH };
struct Fx {
	int kind = 0;
	V2 a, b, v;
	float t = 0, life = 0.5f, size = 10;
	uint32_t col = 0xFFFFFFFF;
	std::string txt;
};

struct WeaponInst {
	int id = 0, lvl = 1;
	float cd = 0, ang = 0, tick = 0, aux = 0;
};

struct Ship {
	V2 p, v;
	float hp = 50, maxHp = 50, sh = 50, maxSh = 50, r = 22, invuln = 0, shDelay = 0, ang = -PI / 2, moveFrac = 0;
};

enum OptionKind { OK_NEW_WEAPON, OK_LEVEL, OK_NEW_PASSIVE, OK_STACK, OK_EVOLVE, OK_HEAL };
struct Option {
	int kind = 0;
	int a = 0; // weapon id / passive id / weapon slot index
};

struct Tgt {
	int kind; // 0 asteroid 1 enemy 2 boss
	int idx;
	V2 p;
	float r;
	int uid;
};

struct Orbital {
	V2 p;
	float r;
	int wid;
	float ang;
};

enum GameMode { GM_SOLO = 0, GM_COOP = 1, GM_PVP = 2 };

// One pilot's ship + loadout. Run owns up to 2 of these (solo / co-op / pvp).
struct Player {
	int pilot = 0;
	Profile *prof = nullptr;   // stats sink (host: real profile, guest: scratch)
	int store[N_STORE] = {};   // this player's store upgrade levels (+ قطع الطائرة)
	float gunCd[N_GUN] = {};  // مؤقت إطلاق كل مدفع مركّب
	Ship ship;
	std::vector<WeaponInst> weapons;
	int pas[P_COUNT] = {};
	V2 moveIn;
	bool choosing = false;
	std::vector<Option> options;
	bool dead = false, revived = false, quit = false;
	float revengeT = 0, cryoVis = 0, vampAcc = 0, wingCd = 0, droneCd = 0, stillT = 0, flightT = 0, hitFlash = 0, chooseT = 0;
	int kills = 0, streak = 0, bestStreak = 0, yenEarned = 0, upgradesTaken = 0;
	bool beamOn = false;
	V2 beamA, beamB;
	float beamW = 28;
	float storeValue(int tile) const { return STORE[tile].perLevel * (float)store[tile]; }
};

// Logical view used by both phones in multiplayer so both see the same area.
constexpr float MP_VIEW_W = 1150.0f;
constexpr float MP_VIEW_H = 2250.0f;
constexpr float MP_TETHER_X = 0.80f * MP_VIEW_W;
constexpr float MP_TETHER_Y = 0.80f * MP_VIEW_H;
constexpr float PVP_SCALE = 0.55f;
constexpr float FIRE_RATE_MULT = 2.5f;    // سرعة الرمي (2.5 = ضعف ونص)
constexpr float ENEMY_SIZE_MULT = 1.6f;   // حجم طيارات العدو
constexpr float VERT_SPEED_MULT = 2.2f;   // سرعة الطائرة في الطيران العمودي (غيّر الرقم للتحكم)

class Run {
public:
	Run(Profile *prof, int pilotIdx, uint64_t seed, GameMode mode = GM_SOLO, int pilot1 = 0, const int *store1 = nullptr);

	void setView(float w, float h) { viewW = w; viewH = h; }
	void setMove(int pi, V2 dir) { if (pi >= 0 && pi < np) pl[pi].moveIn = dir; }
	void setMove(V2 dir) { setMove(0, dir); }
	void update(float dt);
	void choose(int pi, int i);
	void choose(int i) { choose(0, i); }
	void retreat(int pi = 0);          // solo: ends the run; multiplayer: that player quits
	void forfeit(int pi) { retreat(pi); }

	// ---- state (read by renderer) ----
	Profile *P;                        // player 0's profile (kept for compatibility)
	GameMode mode = GM_SOLO;
	int np = 1;
	Player pl[2];
	Player *cur = nullptr;             // player the per-player code is currently acting for
	int winner = -1;                   // pvp: index of the winner, -1 otherwise
	Rng rng;
	float viewW = 960, viewH = 2142;
	// نمط الطيران العمودي (فردي): الطائرة أسفل الشاشة، الأعداء ينزلون من فوق
	bool vertical = false, vertInit = false;
	// تحكم باللمس المباشر: الطائرة تتبع حركة الإصبع
	bool dragOn = false;
	V2 dragTarget;
	void dragBegin(int pi) { if (vertical && pi == 0) { dragOn = true; dragTarget = pl[0].ship.p; } }
	void dragEnd() { dragOn = false; }
	void dragMove(V2 d) {
		if (!vertical || !dragOn) return;
		dragTarget += d;
		float hx = vertHalfX();
		dragTarget.x = dragTarget.x < -hx ? -hx : (dragTarget.x > hx ? hx : dragTarget.x);
		dragTarget.y = dragTarget.y < vertMinY() ? vertMinY() : (dragTarget.y > vertMaxY() ? vertMaxY() : dragTarget.y);
	}
	float vertMinY() const { return viewH / 6.0f; }            // أعلى حد للطائرة (بداية الثلث السفلي)
	float vertMaxY() const { return viewH * 0.5f - 110.0f; }   // أسفل حد
	float vertHalfX() const { return viewW * 0.5f - 60.0f; }   // حد اليمين واليسار
	V2 camCenter;
	bool remote = false;               // mirror run on the guest: state comes from snapshots

	std::vector<Asteroid> asteroids;
	std::vector<Enemy> enemies;
	Boss boss;
	std::vector<EBullet> ebullets;
	std::vector<Shot> shots;
	std::vector<Pickup> pickups;
	std::vector<Mine> mines;
	std::vector<Boom> booms;
	std::vector<Zone> zones;
	std::vector<Fx> fx;

	bool over = false, died = false;

	float t = 0, diff = 1;
	int bossKills = 0;
	float bossAnnounce = 0;

	std::vector<int> sfx;              // drained by the host's renderer every frame
	std::vector<std::string> toasts;
	std::vector<int> sfxOut;           // accumulated for the next network snapshot
	std::vector<Fx> fxOut;

	// helpers for renderer
	void orbitals(int pi, std::vector<Orbital> &out) const;
	V2 droneFollowPos(int pi, int i) const;
	V2 wingmanPos(int pi) const;
	bool anyChoosing() const;
	int aliveCount() const;
	V2 centerTarget() const;
	void updateCamera(float dt, bool snap);
	std::string optionTitle(int pi, const Option &o) const;
	std::string optionDesc(int pi, const Option &o) const;
	int optionIcon(int pi, const Option &o, bool &isPassive) const;

	// ---- network (snapshot.cpp) ----
	void writeSnapshot(std::vector<uint8_t> &out);
	bool readSnapshot(const uint8_t *data, size_t n);
	void extrapolate(float dt);        // guest: advance the mirror between snapshots
	uint32_t snapSeq = 0;

	int weaponMaxSlots() const { return 4 + (cur->pas[P_SLOT] > 0 ? 1 : 0); }
	int passiveMaxSlots() const { return cur->pas[P_SLOT] > 0 ? 3 : 4; }
	int passivesOwned() const;
	float dmgMult() const;

private:
	int nextUid = 1;
	float asteroidTimer = 0.5f, enemyTimer = 7.0f, nextBoss = 180.0f, achTimer = 0;
	float upgradeDropT = 0;
	std::vector<Tgt> tg;
	Tgt foeT_[2] = {{3, 0, V2(), 0, 0}, {3, 0, V2(), 0, 0}};   // pvp: the opponent as an aim target for each pilot
	bool foeOk_[2] = {false, false};
	std::vector<Shot> pendingShots_;
	Profile scratch_[2];

	void initPlayer(int i, Profile *prof, int pilotIdx, const int *store, V2 pos);
	void finish(bool died);
	void checkEnd();
	void sfxEvent(int id) { if (sfx.size() < 48) sfx.push_back(id); if (sfxOut.size() < 24) sfxOut.push_back(id); }

	// player helpers
	int curIdx() const { return (int)(cur - pl); }
	void activate(int i) { cur = &pl[i]; }
	bool alive(int i) const { return !pl[i].dead; }
	int nearestPlayer(V2 p) const;       // index of the closest living ship (-1 when none)
	void damagePlayer(int i, float d, float invuln);
	float asteroidSpeedScale() const;

	// spawning
	void spawnAsteroid();
	void spawnEnemy();
	void spawnBoss();
	void splitAsteroid(const Asteroid &a);

	// updates
	void updateShips(float dt);
	void updateAsteroids(float dt);
	void updateEnemies(float dt);
	void updateBoss(float dt);
	void buildTargets();
	void updateWeapons(float dt);
	void updateOrbitalDamage(WeaponInst &w, float dt);
	void updateShots(float dt);
	void updateEBullets(float dt);
	void updateMines(float dt);
	void updateBooms(float dt);
	void updateZones(float dt);
	void updatePickups(float dt);
	void updateCompanions(float dt);
	void updatePassives(float dt);
	void reap();
	void updateFx(float dt);

	// combat
	void fireWeapon(WeaponInst &w);
	void damageShip(float d, float invuln);
	void die();
	void explode(V2 p, float r, float dmg, int wid, uint32_t col, bool hurtShip = false);
	void pvpHit(int target, float dmg, float invuln);
	void hitTarget(const Tgt &t, float dmg, int wid);
	void hitAsteroid(Asteroid &a, float dmg);
	void hitEnemy(Enemy &e, float dmg);
	void hitBoss(float dmg);
	float rollDamage(float base, bool &crit);
	void enemyFire(Enemy &e);
	void bossFire(float dt);
	void ebullet(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int kind = 0, float expR = 0);
	Shot &newShot(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int wid, int kind);
	const Tgt *nearest(V2 from, float maxR, int skipUid = -1) const;
	std::vector<const Tgt *> nearestN(V2 from, float maxR, int n) const;
	void addFx(int kind, V2 a, V2 b, float life, float size, uint32_t col, V2 v = V2(), const std::string &txt = "");
	void damageText(V2 p, float dmg, bool crit);
	void spawnCoins(V2 p, int pts);
	void spawnPickup(V2 p, int kind, float val);
	void dropFromAsteroid(const Asteroid &a);

	// upgrades
	void makeOptions();
	void applyOption(const Option &o);
	void addWeapon(int id);
	void toast(const std::string &s) { toasts.push_back(s); }
	void checkMeta();
};

} // namespace nj
