// نجوم العراق (Astro Loop) - C++ port core types. GPL-3.0-only (derived from Astro Loop by PubDeer).
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

namespace nj {

constexpr float PI = 3.14159265358979f;
constexpr float TAU = 6.28318530717959f;

struct V2 {
	float x = 0, y = 0;
	V2() = default;
	V2(float X, float Y) : x(X), y(Y) {}
	V2 operator+(V2 o) const { return {x + o.x, y + o.y}; }
	V2 operator-(V2 o) const { return {x - o.x, y - o.y}; }
	V2 operator*(float s) const { return {x * s, y * s}; }
	V2 operator/(float s) const { return {x / s, y / s}; }
	V2 &operator+=(V2 o) { x += o.x; y += o.y; return *this; }
	V2 &operator-=(V2 o) { x -= o.x; y -= o.y; return *this; }
	V2 &operator*=(float s) { x *= s; y *= s; return *this; }
	float len() const { return std::sqrt(x * x + y * y); }
	float len2() const { return x * x + y * y; }
	V2 norm() const {
		float l = len();
		return l > 1e-6f ? V2{x / l, y / l} : V2{0, 0};
	}
	float dot(V2 o) const { return x * o.x + y * o.y; }
	float angle() const { return std::atan2(y, x); }
	static V2 fromAngle(float a) { return {std::cos(a), std::sin(a)}; }
};
inline float dist(V2 a, V2 b) { return (a - b).len(); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }

struct Rng {
	uint64_t s;
	explicit Rng(uint64_t seed = 1) : s(seed * 0x9E3779B97F4A7C15ULL + 0x1234567ULL) { if (!s) s = 88172645463325252ULL; }
	uint32_t next() {
		s ^= s << 13; s ^= s >> 7; s ^= s << 17;
		return (uint32_t)((s * 0x2545F4914F6CDD1DULL) >> 32);
	}
	float f() { return (next() & 0xFFFFFF) / 16777216.0f; }
	float range(float a, float b) { return a + (b - a) * f(); }
	int i(int n) { return n <= 0 ? 0 : (int)(next() % (uint32_t)n); }
	bool chance(float p) { return f() < p; }
};

// ---------- Weapons / passives ----------
enum WeaponId {
	W_PULSE, W_SAW, W_SCATTER, W_HOMING, W_ORBIT, W_RAIL, W_MINES, W_SOLAR, W_NOVA, W_NEEDLE, W_CLUSTER, W_FLAK,
	W_STORM, W_WARPSAW, W_LEECH, W_ACE, W_FROST, W_OBLIVION, W_JACKPOT, W_PHOENIXFLARE, W_LINGER, W_SIPHON, W_HUNTER, W_BARRAGE,
	W_COUNT
};
constexpr int W_BASE_COUNT = 12;

enum PassiveId {
	P_NANO, P_DUP, P_MAGNET, P_PHOENIX, P_SLOT, P_TB26, P_DRONE, P_MOMENTUM, P_CRYO, P_LUCKY, P_REVENGE, P_VAMP, P_GLASS,
	P_COUNT
};

struct WeaponDef {
	const char *key;   // icon + sfx suffix
	const char *name;
	const char *desc;
	int evoPassive;    // passive needed to evolve (base weapons only)
};
struct PassiveDef {
	const char *key;
	const char *name;
	const char *desc;
};
struct EnemyDef {
	const char *name;
	int tier;
	float unlock, hp, speed, dmg, fire, range;
	uint32_t col;
	int pattern;
	float radius;
};
enum UnlockType {
	U_FREE, U_YEN, U_DAMAGE, U_SURVIVE, U_STREAK, U_DEATHS, U_KILLS_RUN, U_WEAPONS, U_EVOS, U_KILLS, U_JACKPOT, U_ALL, U_FLIGHT
};
struct PilotDef {
	const char *id;
	const char *callsign;
	const char *type;
	int passive;
	uint32_t col;
	int unlock;
	int thr;
};
struct StoreTile {
	const char *key;
	const char *nameAr;
	const char *effectAr;
	const char *detailAr;
	const char *icon;
	float perLevel;
};
// قطعة تتركب على الطائرة. تنشترى بالترتيب (القطعة n تنفتح بعد شراء n-1).
enum PartKind { PT_GUN, PT_GUN_BOOST, PT_ENGINE, PT_ENGINE_BOOST };
struct PartDef {
	const char *nameAr;
	const char *effectAr;
	int price;
	int kind;      // PartKind
	int gun;       // رقم المدفع (للمدفع وتسريعه)، -1 إذا ما إلها علاقة
	int image;     // رقم صورة الطيارة بعد شراء هاي القطعة (0 = الأساسية، 1.. = assets/ship/stage_N.png)
	float mx, my;  // مكان فوهة المدفع بوحدات نصف قطر الطائرة (x للأمام، y لليمين)
};
struct AchDef {
	const char *id;
	const char *titleAr;
	const char *descAr;
};

constexpr int N_ENEMY = 12;
constexpr int N_PILOT = 12;
constexpr int N_STAT = 8;         // ترقيات الإحصائيات القديمة (5 مستويات)
constexpr int N_PART = 12;        // قطع الطائرة الجديدة (تتركب على الطائرة)
constexpr int N_GUN = 5;          // أقصى عدد مدافع
constexpr int N_STORE = N_STAT + N_PART;   // الـ 8 الأولى = إحصائيات، والباقي = قطع الطائرة (مستوى 0 أو 1)
constexpr int N_ACH = 8;
constexpr int N_SHIP_COLOR = 6;   // ألوان الطائرة
constexpr int N_FIELD = 4;        // أشكال الفيلد (الخلفية)

struct SkinDef {
	const char *nameAr;
	int price;
	uint32_t argb;   // لون الصبغة على الطائرة
};
struct FieldDef {
	const char *nameAr;
	int price;
	uint32_t bg, star, glow;   // لون الخلفية، لون النجوم، لون السديم
};

extern const WeaponDef WEAPONS[W_COUNT];
extern const PassiveDef PASSIVES[P_COUNT];
extern const EnemyDef ENEMIES[N_ENEMY];
extern const PilotDef PILOTS[N_PILOT];
extern const StoreTile STORE[N_STORE];
extern const PartDef PARTS[N_PART];
extern const AchDef ACHS[N_ACH];
extern const SkinDef SHIP_COLORS[N_SHIP_COLOR];
extern const FieldDef FIELD_THEMES[N_FIELD];
extern const int UPGRADE_COSTS[5];

inline bool partOwned(const int *lv, int p) { return p >= 0 && p < N_PART && lv[N_STAT + p] > 0; }
inline int shipImageOf(const int *lv) {   // رقم صورة الطيارة الحالية حسب القطع المشتراة
	int img = 0;
	for (int p = 0; p < N_PART; p++)
		if (partOwned(lv, p) && PARTS[p].image > img) img = PARTS[p].image;
	return img;
}
inline bool gunOwned(const int *lv, int g) {
	for (int p = 0; p < N_PART; p++)
		if (PARTS[p].kind == PT_GUN && PARTS[p].gun == g) return partOwned(lv, p);
	return false;
}
inline float gunRate(const int *lv, int g) {   // تسريع المدفع: +25% لكل تسريع مشترى
	float m = 1.0f;
	for (int p = 0; p < N_PART; p++)
		if (PARTS[p].kind == PT_GUN_BOOST && PARTS[p].gun == g && partOwned(lv, p)) m += 0.25f;
	return m;
}
inline float engineSpeedBonus(const int *lv) {   // المحرك الثالث + تسريعه
	float b = 0;
	for (int p = 0; p < N_PART; p++) {
		if (!partOwned(lv, p)) continue;
		if (PARTS[p].kind == PT_ENGINE) b += 0.08f;
		else if (PARTS[p].kind == PT_ENGINE_BOOST) b += 0.10f;
	}
	return b;
}

inline bool isEvolution(int w) { return w >= W_BASE_COUNT; }
inline int evolutionOf(int baseWeapon) { return baseWeapon + W_BASE_COUNT; }

// Sound event ids (mapped to files in the Godot layer)
enum SfxId {
	S_ASTEROID, S_ENEMY_DEATH, S_EXPLOSION, S_PLAYER_HIT, S_SHIELD_HIT, S_SHIELD_BREAK, S_PLAYER_DEATH, S_POWERUP, S_YEN,
	S_BOSS, S_EVOLVE, S_REVIVE, S_UPGRADE, S_NEAR_MISS,
	S_WEAPON_BASE // + weapon id
};

} // namespace nj
