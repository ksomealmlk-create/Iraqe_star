// نجوم العراق - سيرفر الغرف (Cloudflare Worker + Durable Object)
// كل غرفة = Durable Object واحد، يربط لاعبين اثنين ويمرّر الرسائل (نص + بيانات ثنائية) بينهما.

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/") return new Response("nujoom server ok");
    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("expected websocket", { status: 426 });
      }
      const room = (url.searchParams.get("room") || "").replace(/[^0-9A-Za-z]/g, "").slice(0, 8);
      if (!room) return new Response("missing room", { status: 400 });
      // locationHint "me" = Middle East: the room lives near the players, so less lag
      const stub = env.ROOM.get(env.ROOM.idFromName(room), { locationHint: "me" });
      return stub.fetch(request);
    }
    return new Response("not found", { status: 404 });
  },
};

export class Room {
  constructor(ctx, env) {
    this.ctx = ctx;
  }

  async fetch(request) {
    const socks = this.ctx.getWebSockets();
    if (socks.length >= 2) return new Response("room full", { status: 403 });

    const used = new Set(socks.map((s) => (s.deserializeAttachment() || {}).idx));
    const idx = used.has(0) ? 1 : 0;

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ idx });

    const players = socks.length + 1;
    server.send(JSON.stringify({ t: "welcome", you: idx, players }));
    for (const s of socks) s.send(JSON.stringify({ t: "peer_join", players }));

    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(ws, message) {
    // text = small control messages (hello/start/input), binary = host snapshots
    if (typeof message === "string") {
      if (message.length > 2048) return;
    } else if (!message || message.byteLength > 60000) {
      return;
    }
    for (const s of this.ctx.getWebSockets()) {
      if (s !== ws) {
        try { s.send(message); } catch (e) {}
      }
    }
  }

  webSocketClose(ws, code) {
    try { ws.close(code === 1005 || code === 1006 ? 1000 : code, "bye"); } catch (e) {}
    this.notifyLeft(ws);
  }

  webSocketError(ws) {
    this.notifyLeft(ws);
  }

  notifyLeft(ws) {
    for (const s of this.ctx.getWebSockets()) {
      if (s !== ws) {
        try { s.send(JSON.stringify({ t: "peer_left" })); } catch (e) {}
      }
    }
  }
}
