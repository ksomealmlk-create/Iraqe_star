extends Node3D

# نجوم العراق — نموذج أولي ثلاثي الأبعاد.
# مشهد مستقل للتجربة؛ لا يستبدل اللعبة الأصلية تلقائياً.
@export var asteroid_count: int = 95
@export var field_radius: float = 42.0
@export var ship_speed: float = 13.0
@export var mouse_sensitivity: float = 0.012

var ship: Node3D
var ship_visual: Node3D
var camera: Camera3D
var laser_cooldown := 0.0
var touch_origin := Vector2.ZERO
var touch_vector := Vector2.ZERO
var touch_active := false
var hud_label: Label
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    _setup_environment()
    _create_stars()
    _create_planets()
    _create_asteroids()
    _create_ship()
    _create_hud()

func _process(delta: float) -> void:
    laser_cooldown = maxf(0.0, laser_cooldown - delta)
    _move_ship(delta)
    if Input.is_action_pressed("ui_accept") and laser_cooldown <= 0.0:
        _fire_laser()
    if is_instance_valid(hud_label):
        hud_label.text = "نُجُوم العراق  •  نموذج 3D\nتحرّك: WASD / الأسهم  |  إطلاق: Space أو لمس الشاشة"

func _setup_environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.008, 0.018, 0.055)
    sky_mat.sky_horizon_color = Color(0.035, 0.07, 0.12)
    sky_mat.ground_bottom_color = Color(0.004, 0.008, 0.018)
    sky_mat.ground_horizon_color = Color(0.025, 0.045, 0.075)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.30, 0.38, 0.55)
    env.ambient_light_energy = 0.65
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.7
    world.environment = env
    add_child(world)

    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-32, -28, 0)
    key.light_color = Color(0.70, 0.82, 1.0)
    key.light_energy = 1.4
    key.shadow_enabled = true
    add_child(key)

    var fill := OmniLight3D.new()
    fill.position = Vector3(0, 4, -10)
    fill.light_color = Color(0.05, 0.55, 1.0)
    fill.light_energy = 3.0
    fill.omni_range = 35.0
    add_child(fill)

func _create_stars() -> void:
    var mesh := ImmediateMesh.new()
    mesh.surface_begin(Mesh.PRIMITIVE_POINTS)
    for i in range(900):
        var p := Vector3(rng.randf_range(-100, 100), rng.randf_range(-65, 65), rng.randf_range(-100, 45))
        mesh.surface_set_color(Color(0.55, 0.75, 1.0, rng.randf_range(0.25, 1.0)))
        mesh.surface_add_vertex(p)
    mesh.surface_end()
    var stars := MeshInstance3D.new()
    stars.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.vertex_color_use_as_albedo = true
    mat.point_size = 2.0
    stars.material_override = mat
    add_child(stars)

func _create_planets() -> void:
    _planet(Vector3(-27, 11, -42), 8.0, Color(0.20, 0.33, 0.80), Color(0.55, 0.12, 0.70))
    _planet(Vector3(31, 7, -52), 10.0, Color(0.95, 0.13, 0.055), Color(1.0, 0.30, 0.08))

func _planet(pos: Vector3, radius: float, base: Color, glow: Color) -> void:
    var body := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = radius
    sphere.height = radius * 2.0
    sphere.radial_segments = 48
    sphere.rings = 24
    body.mesh = sphere
    body.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = base
    mat.roughness = 0.88
    mat.metallic = 0.08
    mat.emission_enabled = true
    mat.emission = glow
    mat.emission_energy_multiplier = 0.28
    body.material_override = mat
    add_child(body)

    var light := OmniLight3D.new()
    light.position = pos
    light.light_color = glow
    light.light_energy = 1.7
    light.omni_range = radius * 4.0
    add_child(light)

func _create_asteroids() -> void:
    for i in range(asteroid_count):
        var rock := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        var size := rng.randf_range(0.35, 1.65)
        sphere.radius = size
        sphere.height = size * 1.8
        sphere.radial_segments = 8
        sphere.rings = 5
        rock.mesh = sphere
        rock.position = Vector3(
            rng.randf_range(-field_radius, field_radius),
            rng.randf_range(-17.0, 17.0),
            rng.randf_range(-42.0, 18.0)
        )
        rock.rotation = Vector3(rng.randf_range(0, TAU), rng.randf_range(0, TAU), rng.randf_range(0, TAU))
        rock.scale = Vector3(rng.randf_range(0.75, 1.5), rng.randf_range(0.65, 1.3), rng.randf_range(0.75, 1.4))
        var mat := StandardMaterial3D.new()
        var shade := rng.randf_range(0.12, 0.34)
        mat.albedo_color = Color(shade, shade * 1.05, shade * 1.12)
        mat.roughness = 1.0
        mat.metallic = 0.12
        rock.material_override = mat
        add_child(rock)

func _create_ship() -> void:
    ship = Node3D.new()
    ship.position = Vector3(0, -1.0, 5.0)
    add_child(ship)
    ship_visual = Node3D.new()
    ship.add_child(ship_visual)

    # جسم السفينة: عدة مجسمات بسيطة قابلة للاستبدال لاحقاً بموديل احترافي.
    _ship_part(BoxMesh.new(), Vector3(0, 0, 0), Vector3(0.9, 0.38, 2.4), Color(0.20, 0.29, 0.38))
    _ship_part(BoxMesh.new(), Vector3(0, 0.12, -0.45), Vector3(0.56, 0.22, 1.2), Color(0.58, 0.66, 0.72))
    _ship_part(BoxMesh.new(), Vector3(-1.0, -0.05, 0.35), Vector3(1.45, 0.13, 0.72), Color(0.85, 0.40, 0.08))
    _ship_part(BoxMesh.new(), Vector3(1.0, -0.05, 0.35), Vector3(1.45, 0.13, 0.72), Color(0.85, 0.40, 0.08))
    _ship_part(BoxMesh.new(), Vector3(-0.48, 0.0, 0.95), Vector3(0.22, 0.12, 0.7), Color(0.12, 0.65, 1.0))
    _ship_part(BoxMesh.new(), Vector3(0.48, 0.0, 0.95), Vector3(0.22, 0.12, 0.7), Color(0.12, 0.65, 1.0))

    var engine_light := OmniLight3D.new()
    engine_light.position = Vector3(0, 0, 1.55)
    engine_light.light_color = Color(0.05, 0.55, 1.0)
    engine_light.light_energy = 2.8
    engine_light.omni_range = 7.0
    ship.add_child(engine_light)

    camera = Camera3D.new()
    camera.position = Vector3(0, 5.5, 12.5)
    camera.rotation_degrees = Vector3(-18, 0, 0)
    camera.current = true
    ship.add_child(camera)

func _ship_part(mesh: Mesh, pos: Vector3, size: Vector3, color: Color) -> void:
    var part := MeshInstance3D.new()
    part.mesh = mesh
    part.position = pos
    part.scale = size
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.72
    mat.roughness = 0.28
    mat.emission_enabled = color.b > 0.6
    mat.emission = color
    mat.emission_energy_multiplier = 1.1
    part.material_override = mat
    ship_visual.add_child(part)

func _move_ship(delta: float) -> void:
    var input_vec := Vector2.ZERO
    input_vec.x = Input.get_axis("ui_left", "ui_right")
    input_vec.y = Input.get_axis("ui_up", "ui_down")
    if touch_active:
        input_vec = touch_vector
    ship.position.x = clampf(ship.position.x + input_vec.x * ship_speed * delta, -12.0, 12.0)
    ship.position.y = clampf(ship.position.y - input_vec.y * ship_speed * delta, -7.0, 7.0)
    ship_visual.rotation.z = lerpf(ship_visual.rotation.z, -input_vec.x * 0.18, delta * 5.0)
    ship_visual.rotation.x = lerpf(ship_visual.rotation.x, input_vec.y * 0.08, delta * 4.0)

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_origin = event.position
            touch_active = true
            touch_vector = Vector2.ZERO
            if event.position.x > get_viewport().get_visible_rect().size.x * 0.62:
                _fire_laser()
        else:
            touch_active = false
            touch_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and touch_active:
        var view_size := get_viewport().get_visible_rect().size
        touch_vector = ((event.position - touch_origin) / Vector2(view_size.x * 0.20, view_size.y * 0.20)).limit_length(1.0)
    elif event is InputEventMouseButton and event.pressed:
        _fire_laser()

func _fire_laser() -> void:
    if laser_cooldown > 0.0:
        return
    laser_cooldown = 0.18
    var beam := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.045
    cylinder.bottom_radius = 0.045
    cylinder.height = 5.5
    beam.mesh = cylinder
    beam.position = ship.position + Vector3(0, 0.1, -4.0)
    beam.rotation_degrees.x = 90
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(0.15, 0.85, 1.0)
    mat.emission_enabled = true
    mat.emission = Color(0.1, 0.7, 1.0)
    mat.emission_energy_multiplier = 4.0
    beam.material_override = mat
    add_child(beam)
    var tween := create_tween()
    tween.tween_property(beam, "position:z", beam.position.z - 22.0, 0.22)
    tween.tween_callback(beam.queue_free)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(380, 88)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.015, 0.035, 0.08, 0.78)
    style.border_color = Color(0.05, 0.72, 1.0, 0.8)
    style.set_border_width_all(2)
    style.set_corner_radius_all(12)
    panel.add_theme_stylebox_override("panel", style)
    layer.add_child(panel)
    hud_label = Label.new()
    hud_label.text = "نُجُوم العراق  •  نموذج 3D"
    hud_label.add_theme_color_override("font_color", Color(0.75, 0.93, 1.0))
    hud_label.add_theme_font_size_override("font_size", 20)
    panel.add_child(hud_label)
