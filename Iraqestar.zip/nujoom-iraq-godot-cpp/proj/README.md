# نجوم العراق (Astro Loop) - Godot 4.3 + C++ (GDExtension)

طريقة البناء على GitHub:
1. ارفع كل محتويات المجلد إلى مستودع جديد (انتبه أن المجلد المخفي `.github/workflows/build.yml` يترفع).
2. من تبويب Actions شغّل "Build APK (Godot + C++)" (يشتغل تلقائياً عند أي push).
3. بعد ما يخلص (حوالي 15-25 دقيقة) نزّل الملف `nujoom-iraq-apk` من Artifacts واستخرج منه `nujoom.apk`.

الكود: `src/sim` (منطق اللعبة بـ C++ صرف)، `src/godot` (الرسم/اللمس/الصوت).
الرخصة: GPL-3.0 (مبنية على Astro Loop من PubDeer).
