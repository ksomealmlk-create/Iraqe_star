#pragma once
#include "core.hpp"

namespace nj {

struct Profile {
	long long yen = 0;            // spendable balance (د.ع)
	long long totalYenEarned = 0;
	int totalKills = 0;
	int bestStreak = 0;
	int bestSurvival = 0;         // seconds
	int totalDeaths = 0;
	int totalDamageTaken = 0;
	int maxKillsRun = 0;
	int bestFlight = 0;           // best continuous flight (seconds, no damage)
	int casinoSpins = 0;
	bool jackpotWon = false;
	int pilot = 0;
	int storeLevel[N_STORE] = {};
	bool weaponSeen[W_COUNT] = {};
	bool pilotUnlocked[N_PILOT] = {};
	bool ach[N_ACH] = {};
	bool introDone = false;

	Profile() { pilotUnlocked[0] = true; }

	std::string serialize() const;
	void deserialize(const std::string &s);

	int weaponsDiscovered() const;
	int evolutionsDiscovered() const;

	// Store
	int storeCost(int tile) const; // -1 when maxed
	bool canBuy(int tile) const;
	bool buy(int tile);
	float storeValue(int tile) const { return STORE[tile].perLevel * storeLevel[tile]; }

	// Unlocks: returns indices that were just unlocked
	std::vector<int> refreshPilots();
	bool meetsUnlock(int pilotIdx) const;
	std::string pilotHintAr(int pilotIdx) const;

	// Achievements: returns indices just earned
	std::vector<int> checkAchievements();
};

std::string formatYen(long long amount);

} // namespace nj
