#include "run.hpp"

namespace nj {

// ------------------------------------------------------------------ orbitals
static void genOrbitals(const Player &r, const WeaponInst &w, std::vector<Orbital> &out) {
	int extra = r.pas[P_DUP];
	if (w.id == W_SAW) {
		int n = 1 + extra;
		float br = 26.0f + 8.0f * w.lvl;
		for (int i = 0; i < n; i++) {
			float a = w.ang + (float)i * TAU / (float)n;
			out.push_back({r.ship.p + V2::fromAngle(a) * 125.0f, br, w.id, a});
		}
	} else if (w.id == W_ORBIT) {
		int n = 2 + (w.lvl - 1) + extra;
		for (int i = 0; i < n; i++) {
			float a = w.ang + (float)i * TAU / (float)n;
			out.push_back({r.ship.p + V2::fromAngle(a) * 175.0f, 17.0f, w.id, a});
		}
	} else if (w.id == W_FROST) {
		int n1 = 4 + extra, n2 = 6 + extra;
		for (int i = 0; i < n1; i++) {
			float a = w.ang + (float)i * TAU / (float)n1;
			out.push_back({r.ship.p + V2::fromAngle(a) * 150.0f, 17.0f, w.id, a});
		}
		for (int i = 0; i < n2; i++) {
			float a = -w.ang * 0.73f + (float)i * TAU / (float)n2;
			out.push_back({r.ship.p + V2::fromAngle(a) * 235.0f, 17.0f, w.id, a});
		}
	}
}

void Run::orbitals(int pi, std::vector<Orbital> &out) const {
	if (pi < 0 || pi >= np || pl[pi].dead) return;
	for (const auto &w : pl[pi].weapons) genOrbitals(pl[pi], w, out);
}

V2 Run::droneFollowPos(int pi, int i) const {
	const Player &p = pl[pi];
	int n = std::max(1, p.pas[P_DRONE]);
	return p.ship.p + V2::fromAngle(t * 2.6f + (float)i * TAU / (float)n) * 85.0f;
}
V2 Run::wingmanPos(int pi) const { return pl[pi].ship.p + V2(-85, 55); }

void Run::updateOrbitalDamage(WeaponInst &w, float dt) {
	float speed = w.id == W_SAW ? 3.4f : (w.id == W_ORBIT ? 2.2f : 2.6f);
	w.ang += speed * dt;
	w.tick -= dt;
	if (w.tick > 0) return;
	float T = w.id == W_SAW ? 0.12f : (w.id == W_ORBIT ? 0.25f : 0.2f);
	w.tick += T;
	float dmg = w.id == W_SAW ? 6.0f * (1.0f + 0.15f * (w.lvl - 1)) : (w.id == W_ORBIT ? 11.0f * (1.0f + 0.12f * (w.lvl - 1)) : 12.0f);
	std::vector<Orbital> orbs;
	genOrbitals(*cur, w, orbs);
	if (mode == GM_PVP && np == 2) {
		int v = 1 - curIdx();
		if (!pl[v].dead)
			for (const auto &o : orbs)
				if (dist(o.p, pl[v].ship.p) < o.r + pl[v].ship.r) { pvpHit(v, dmg, 0.2f); break; }
	}
	for (const auto &o : orbs)
		for (const auto &x : tg) {
			if (dist(o.p, x.p) >= o.r + x.r) continue;
			hitTarget(x, dmg, w.id);
			if (w.id == W_FROST) {
				if (x.kind == 1 && x.idx < (int)enemies.size()) { enemies[x.idx].slowT = 1.2f; enemies[x.idx].slowAmt = 0.5f; }
				if (x.kind == 0 && x.idx < (int)asteroids.size()) { asteroids[x.idx].slowT = 1.2f; asteroids[x.idx].slowAmt = 0.5f; }
			}
		}
}

static float distToSegment(V2 p, V2 a, V2 b) {
	V2 ab = b - a;
	float l2 = ab.len2();
	float u = l2 > 0 ? clampf((p - a).dot(ab) / l2, 0, 1) : 0;
	return dist(p, a + ab * u);
}

// ------------------------------------------------------------------ cur->weapons
void Run::updateWeapons(float dt) {
	for (int pi = 0; pi < np; pi++) {
		pl[pi].beamOn = false;
		if (pl[pi].dead) continue;
		cur = &pl[pi];
		float haste = cur->revengeT > 0 ? 1.5f : 1.0f;
		for (auto &w : cur->weapons) {
			switch (w.id) {
				case W_SAW:
				case W_ORBIT:
				case W_FROST:
					updateOrbitalDamage(w, dt);
					break;
				case W_OBLIVION: {
					w.aux = cur->ship.ang;   // الشعاع دائماً للأمام
					{
						w.cd = 0.3f;
						V2 d = V2::fromAngle(w.aux);
						cur->beamOn = true;
						cur->beamA = cur->ship.p;
						cur->beamB = cur->ship.p + d * 1500.0f;
						cur->beamW = 28.0f + 6.0f * cur->pas[P_DUP];
						w.tick -= dt;
						if (w.tick <= 0) {
							w.tick += 0.1f;
							for (const auto &t2 : tg)
								if (distToSegment(t2.p, cur->beamA, cur->beamB) < t2.r + cur->beamW * 0.5f) hitTarget(t2, 11.0f, w.id);
							if (mode == GM_PVP && np == 2) {
								int v = 1 - pi;
								if (!pl[v].dead && distToSegment(pl[v].ship.p, cur->beamA, cur->beamB) < pl[v].ship.r + cur->beamW * 0.5f) pvpHit(v, 11.0f, 0.1f);
							}
						}
						w.ang -= dt;
						if (w.ang <= 0) { w.ang = 0.9f; sfxEvent(S_WEAPON_BASE + w.id); }
					}
					break;
				}
				case W_WARPSAW: {
					int want = 2 + cur->pas[P_DUP], have = 0;
					for (const auto &z : zones) if (z.kind == ZK_BLADE && z.wid == W_WARPSAW && z.owner == pi) have++;
					if (have < want) {
						Zone z;
						z.p = cur->ship.p; z.r = 30; z.life = z.maxLife = 1e9f; z.dps = 13; z.tick = 0.1f; z.kind = ZK_BLADE; z.wid = W_WARPSAW;
						z.col = 0xFFFFAA33; z.homing = 1; z.owner = pi;
						zones.push_back(z);
					}
					break;
				}
				default:
					w.cd -= dt * haste;
					if (w.cd <= 0) fireWeapon(w);
			}
		}
	}
	cur = &pl[0];
}

void Run::fireWeapon(WeaponInst &w) {
	int L = w.lvl, extra = cur->pas[P_DUP];
	float cdm = 1.0f;
	const Tgt *tt = nearest(cur->ship.p, 950);
	V2 d = V2::fromAngle(cur->ship.ang);   // كل الطلقات ترمي للأمام (باتجاه مقدمة الطائرة)
	V2 perp(-d.y, d.x);
	auto aimAng = [&]() { return d.angle(); };
	auto sfx = [&]() { sfxEvent(S_WEAPON_BASE + w.id); };
	switch (w.id) {
		case W_PULSE: {
			int n = L + extra;
			for (int i = 0; i < n; i++) {
				float off = ((float)i - (float)(n - 1) * 0.5f) * 14.0f;
				newShot(cur->ship.p + perp * off, d * 900.0f, 9.0f, 6, 1.1f, 0xFF66F0FF, w.id, 0);
			}
			w.cd = 0.5f * cdm; sfx();
			break;
		}
		case W_SCATTER:
		case W_LEECH: {
			bool leech = w.id == W_LEECH;
			int n = leech ? 11 + extra * 2 : 5 + 2 * (L - 1) + extra * 2;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + rng.range(-0.3f, 0.3f);
				Shot &s = newShot(cur->ship.p, V2::fromAngle(a) * rng.range(700.0f, 820.0f), leech ? 6.0f : 5.5f, 4, 0.42f, leech ? 0xFF88FF88 : 0xFFFFCC66, w.id, 0);
				if (leech) s.heal = 0.25f;
			}
			w.cd = (leech ? 0.95f : 1.0f) * cdm; sfx();
			break;
		}
		case W_HOMING:
		case W_ACE: {
			bool ace = w.id == W_ACE;
			int n = ace ? 4 + extra : L + extra;
			auto list = nearestN(cur->ship.p, 950, n);
			for (int i = 0; i < n; i++) {
				float a = aimAng() + ((float)i - (float)(n - 1) * 0.5f) * 0.35f;
				Shot &s = newShot(cur->ship.p, V2::fromAngle(a) * 520.0f, ace ? 20.0f : 16.0f, 7, 3.0f, 0xFFFF8844, w.id, 1);
				s.homing = 5.0f;
				s.expR = 55; s.expDmg = ace ? 16.0f : 14.0f;
				s.tgt = list.empty() ? -1 : list[i % list.size()]->uid;
				s.split = false; // ace split handled via direct-hit only when no explosion
			}
			w.cd = (ace ? 1.4f : 1.6f) * cdm; sfx();
			break;
		}
		case W_RAIL: {
			static const float rr[5] = {8, 12, 18, 26, 38};
			Shot &s = newShot(cur->ship.p, d * 2200.0f, 60.0f * (1.0f + 0.15f * (L - 1)), rr[std::min(4, L - 1)], 0.9f, 0xFF99EEFF, w.id, 5);
			s.pierce = 10 + extra;
			w.cd = 2.2f * cdm; sfx();
			break;
		}
		case W_MINES:
		case W_JACKPOT: {
			bool jp = w.id == W_JACKPOT;
			int n = jp ? 3 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			for (int i = 0; i < n; i++) {
				Mine m;
				m.p = cur->ship.p + V2(rng.range(-25, 25), rng.range(-25, 25));
				m.dmg = jp ? 70.0f : 42.0f;
				m.expR = jp ? 150.0f : 105.0f + (L >= 2 ? 25.0f : 0) + (L >= 4 ? 25.0f : 0);
				m.wid = w.id;
				m.owner = curIdx();
				m.jackpot = jp && rng.chance(0.12f);
				mines.push_back(m);
			}
			w.cd = 2.6f * cdm; sfx();
			break;
		}
		case W_SOLAR: {
			std::vector<const Tgt *> cand;
			for (const auto &x : tg) if (dist(x.p, cur->ship.p) < 800) cand.push_back(&x);
			if (cand.empty()) return;
			int n = 1 + L / 2 + extra;
			for (int i = 0; i < n && !cand.empty(); i++) {
				int k = rng.i((int)cand.size());
				V2 p = cand[k]->p;
				addFx(FX_LINE, p + V2(rng.range(-60, 60), -900), p, 0.25f, 7, 0xFFFFFF99);
				explode(p, 55, 28.0f, w.id, 0xFFFFEE66);
				cand.erase(cand.begin() + k);
			}
			w.cd = 1.4f * cdm; sfx();
			break;
		}
		case W_NOVA: {
			float R = 200.0f + 30.0f * L;
			explode(cur->ship.p, R, (22.0f + 4.0f * L) * (1.0f + 0.15f * extra), w.id, 0xFF88CCFF);
			w.cd = 2.8f * cdm; sfx();
			break;
		}
		case W_LINGER: {
			float R = 300.0f;
			explode(cur->ship.p, R, 38.0f, w.id, 0xFFAA88FF);
			Zone z;
			z.p = cur->ship.p; z.r = 40; z.life = z.maxLife = 1.3f; z.kind = ZK_CORE; z.col = 0xFFCC99FF; z.wid = w.id; z.owner = curIdx();
			zones.push_back(z);
			Boom b;
			b.p = cur->ship.p; b.t = 1.3f; b.r = R * 0.85f; b.dmg = 30.0f; b.wid = w.id; b.col = 0xFFCC99FF; b.owner = curIdx();
			booms.push_back(b);
			w.cd = 3.0f * cdm; sfx();
			break;
		}
		case W_NEEDLE:
		case W_SIPHON: {
			bool sip = w.id == W_SIPHON;
			int n = sip ? 3 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + rng.range(-0.07f, 0.07f) + (n > 1 ? ((float)i - (float)(n - 1) * 0.5f) * 0.06f : 0);
				Shot &s = newShot(cur->ship.p, V2::fromAngle(a) * 1400.0f, (sip ? 5.0f : 3.6f) * (1.0f + 0.15f * (L - 1)), 3.5f, 0.9f, sip ? 0xFF88FF88 : 0xFFDDDDFF, w.id, 4);
				s.pierce = sip ? 4 : 2 + L / 2;
				if (sip) s.heal = 0.3f;
			}
			w.cd = (sip ? 0.15f : 0.17f) * cdm; sfx();
			break;
		}
		case W_CLUSTER: {
			float dd = tt ? dist(tt->p, cur->ship.p) : 420.0f;
			Shot &s = newShot(cur->ship.p, d * 560.0f, 0, 8, std::max(0.15f, dd / 560.0f), 0xFFFF9944, w.id, 2);
			s.expR = 75; s.expDmg = 22.0f + 3.0f * L; s.bomblets = 3 + L + extra;
			w.cd = 2.3f * cdm; sfx();
			break;
		}
		case W_HUNTER: {
			int n = 1 + extra;
			auto list = nearestN(cur->ship.p, 950, n);
			for (int i = 0; i < n; i++) {
				float a = aimAng() + ((float)i - (float)(n - 1) * 0.5f) * 0.3f;
				Shot &s = newShot(cur->ship.p, V2::fromAngle(a) * 520.0f, 0, 9, 3.0f, 0xFFFF6633, w.id, 6);
				s.homing = 4.5f; s.expR = 95; s.expDmg = 30; s.bomblets = 3;
				s.tgt = list.empty() ? -1 : list[i % list.size()]->uid;
			}
			w.cd = 1.15f * cdm; sfx();
			break;
		}
		case W_FLAK:
		case W_BARRAGE: {
			bool bar = w.id == W_BARRAGE;
			int n = bar ? 5 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			float spread = bar ? 0.6f : 0.25f;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + (n > 1 ? ((float)i - (float)(n - 1) * 0.5f) * spread / (float)(n - 1) : 0.0f);
				Shot &s = newShot(cur->ship.p, V2::fromAngle(a) * 760.0f, 0, 7, 1.1f, 0xFFFFDD66, w.id, 3);
				s.expR = bar ? 90.0f : 85.0f; s.expDmg = (bar ? 28.0f : 20.0f) + 3.0f * L;
			}
			w.cd = 1.05f * cdm; sfx();
			break;
		}
		case W_STORM: {
			int arms = 3 + extra;
			for (int i = 0; i < arms; i++) {
				float a = cur->ship.ang + std::sin(w.aux) * 0.5f + ((float)i - (float)(arms - 1) * 0.5f) * 0.22f;
				newShot(cur->ship.p, V2::fromAngle(a) * 650.0f, 6.5f, 5, 1.4f, 0xFFAA88FF, w.id, 0);
			}
			w.aux += 0.5f;
			w.cd = 0.11f;
			if (rng.chance(0.15f)) sfxEvent(S_WEAPON_BASE + w.id);
			break;
		}
		case W_PHOENIXFLARE: {
			if (!tt) return;
			auto list = nearestN(cur->ship.p, 900, 3 + extra);
			for (const Tgt *x : list) {
				static const float radii[3] = {60, 100, 140};
				for (int k = 0; k < 3; k++) {
					Boom b;
					b.p = x->p; b.t = 0.15f * (float)k; b.r = radii[k]; b.dmg = 28.0f; b.wid = w.id; b.col = 0xFFFF7733; b.owner = curIdx();
					booms.push_back(b);
				}
			}
			w.cd = 2.0f * cdm; sfx();
			break;
		}
		default: w.cd = 1.0f; break;
	}
}

void Run::updateMines(float dt) {
	for (auto &m : mines) {
		cur = &pl[m.owner < np ? m.owner : 0];
		m.t += dt;
		m.life -= dt;
		bool boom = m.life <= 0;
		if (!boom && m.t > m.arm) {
			for (const auto &x : tg)
				if (dist(x.p, m.p) < x.r + 45) { boom = true; break; }
			if (!boom && mode == GM_PVP && np == 2) {
				int v = 1 - m.owner;
				if (!pl[v].dead && dist(pl[v].ship.p, m.p) < pl[v].ship.r + 45) boom = true;
			}
		}
		if (boom) {
			float dmg = m.dmg;
			if (m.jackpot) {
				dmg *= 3;
				spawnCoins(m.p, 400);
				addFx(FX_TEXT, m.p + V2(0, -40), V2(), 1.4f, 34, 0xFFFFE04A, V2(0, -50), "JACKPOT!");
			}
			explode(m.p, m.jackpot ? m.expR * 1.4f : m.expR, dmg, m.wid, m.jackpot ? 0xFFFFE04A : 0xFFFF8855);
			m.life = -1000;
		}
	}
	cur = &pl[0];
	mines.erase(std::remove_if(mines.begin(), mines.end(), [](const Mine &m) { return m.life <= -999; }), mines.end());
}

void Run::updateBooms(float dt) {
	for (auto &b : booms) {
		b.t -= dt;
		if (b.t <= 0) {
			cur = &pl[b.owner < np ? b.owner : 0];
			explode(b.p, b.r, b.dmg, b.wid, b.col);
			b.t = -1000;
		}
	}
	cur = &pl[0];
	booms.erase(std::remove_if(booms.begin(), booms.end(), [](const Boom &b) { return b.t <= -999; }), booms.end());
}

void Run::updateZones(float dt) {
	for (auto &z : zones) {
		z.life -= dt;
		if (z.kind == ZK_BLADE) {
			cur = &pl[z.owner < np ? z.owner : 0];
			V2 want;
			const Tgt *x = nearest(z.p, 1000);
			if (x) want = (x->p - z.p).norm() * 420.0f;
			else want = (cur->ship.p + V2::fromAngle(t * 2.0f) * 120.0f - z.p) * 3.0f;
			z.v = z.v + (want - z.v) * std::min(1.0f, dt * 4.0f);
			z.p += z.v * dt;
			z.ang += dt * 14.0f;
			z.tickT -= dt;
			if (z.tickT <= 0) {
				z.tickT += z.tick;
				for (const auto &y : tg)
					if (dist(y.p, z.p) < z.r + y.r) hitTarget(y, z.dps, z.wid);
				if (mode == GM_PVP && np == 2) {
					int v = 1 - z.owner;
					if (!pl[v].dead && dist(pl[v].ship.p, z.p) < z.r + pl[v].ship.r) pvpHit(v, z.dps, 0.1f);
				}
			}
		} else if (z.kind == ZK_GAS && z.hostile) {
			z.tickT -= dt;
			if (z.tickT <= 0) {
				z.tickT += 0.5f;
				for (int i = 0; i < np; i++)
					if (!pl[i].dead && dist(z.p, pl[i].ship.p) < z.r + pl[i].ship.r * 0.6f) damagePlayer(i, z.dps * 0.5f, 0.3f);
			}
		}
	}
	cur = &pl[0];
	zones.erase(std::remove_if(zones.begin(), zones.end(), [](const Zone &z) { return z.life <= 0; }), zones.end());
}

// ------------------------------------------------------------------ passives & companions
void Run::updatePassives(float dt) {
	if (upgradeDropT > 0) upgradeDropT -= dt;
	for (int pi = 0; pi < np; pi++) {
		if (pl[pi].dead) { pl[pi].cryoVis = 0; continue; }
		cur = &pl[pi];
		Ship &sh = cur->ship;
		if (cur->pas[P_NANO] > 0 && sh.hp < sh.maxHp) sh.hp = std::min(sh.maxHp, sh.hp + 0.6f * cur->pas[P_NANO] * dt);
		if (cur->pas[P_CRYO] > 0) {
			float r = 170.0f + 25.0f * cur->pas[P_CRYO];
			float amt = 0.3f + 0.06f * cur->pas[P_CRYO];
			for (auto &a : asteroids) if (dist(a.p, sh.p) < r + a.r) { a.slowT = 0.3f; a.slowAmt = amt; }
			for (auto &e : enemies) if (dist(e.p, sh.p) < r + e.r) { e.slowT = 0.3f; e.slowAmt = amt; }
			cur->cryoVis = r;
		} else cur->cryoVis = 0;
		if (cur->pas[P_VAMP] > 0) {
			int n = 0;
			for (auto &a : asteroids)
				if (a.hp > 0 && dist(a.p, sh.p) < 230 + a.r) {
					a.hp -= 5.0f * cur->pas[P_VAMP] * dt;
					if (++n <= 3) sh.hp = std::min(sh.maxHp, sh.hp + 0.6f * cur->pas[P_VAMP] * dt);
				}
		}
	}
	cur = &pl[0];
}

void Run::updateCompanions(float dt) {
	for (int pi = 0; pi < np; pi++) {
		if (pl[pi].dead) continue;
		cur = &pl[pi];
		// مدافع الطائرة المركّبة من المتجر: كلها ترمي للأمام من أماكنها على الطائرة
		{
			float ca = std::cos(cur->ship.ang), sa = std::sin(cur->ship.ang);
			for (int g = 0; g < N_GUN; g++) {
				if (!gunOwned(cur->store, g)) continue;
				cur->gunCd[g] -= dt;
				if (cur->gunCd[g] > 0) continue;
				for (int q = 0; q < N_PART; q++) {
					if (PARTS[q].kind != PT_GUN || PARTS[q].gun != g) continue;
					V2 off(PARTS[q].mx * ca - PARTS[q].my * sa, PARTS[q].mx * sa + PARTS[q].my * ca);
					V2 mp = cur->ship.p + off * cur->ship.r;
					newShot(mp, V2(ca, sa) * 950.0f, 6.0f, 4.0f, 0.9f, 0xFFFFE066, -1, 0);
					addFx(FX_FLASH, mp, V2(), 0.07f, 6, 0xFFFFEE88);
					break;
				}
				cur->gunCd[g] = 0.42f / gunRate(cur->store, g);
			}
		}
		// مدافع الطائرة المشتراة من قسم الطائرات: ترمي للأمام (ميزة Rafale تصوّب على أقرب هدف، وميزة MiG ترفع السرعة 3 أضعاف)
		if (cur->plane >= 0) {
			const PlaneDef &pd = PLANES[cur->plane];
			cur->planeGunCd -= dt;
			if (cur->planeGunCd <= 0) {
				float ca = std::cos(cur->ship.ang), sa = std::sin(cur->ship.ang);
				V2 dir(ca, sa);
				if (pd.ability == AB_PRECISION && cur->abT > 0) {
					const Tgt *aim = nearest(cur->ship.p, 1100);
					if (aim) dir = (aim->p - cur->ship.p).norm();
				}
				for (int g = 0; g < pd.guns; g++) {
					float lx, ly;
					planeMuzzle(pd.guns, g, lx, ly);
					V2 mp = cur->ship.p + V2(lx * ca - ly * sa, lx * sa + ly * ca) * cur->ship.r;
					newShot(mp, dir * 980.0f, pd.gunDmg, pd.gunDmg > 9.0f ? 5.5f : 4.0f, 0.9f, pd.gunDmg > 9.0f ? 0xFFFFAA55 : 0xFFFFE066, -1, 0);
					addFx(FX_FLASH, mp, V2(), 0.07f, 6, 0xFFFFEE88);
				}
				cur->planeGunCd = pd.gunGap / ((pd.ability == AB_BURST && cur->abT > 0) ? 3.0f : 1.0f);
			}
		}
		if (cur->pas[P_TB26] > 0) {
			cur->wingCd -= dt;
			if (cur->wingCd <= 0) {
				V2 wp = wingmanPos(pi);
				{
					V2 d = V2::fromAngle(cur->ship.ang);
					newShot(wp, d * 820.0f, 7.0f * (1.0f + 0.35f * (cur->pas[P_TB26] - 1)), 5, 0.9f, 0xFF88FFAA, -1, 0);
					cur->wingCd = 0.45f;
				}
			}
		}
		if (cur->pas[P_DRONE] > 0) {
			cur->droneCd -= dt;
			if (cur->droneCd <= 0) {
				bool fired = false;
				for (int i = 0; i < cur->pas[P_DRONE]; i++) {
					V2 dp = droneFollowPos(pi, i);
					{
						newShot(dp, V2::fromAngle(cur->ship.ang) * 800.0f, 6.0f, 4, 0.8f, 0xFFFFDD88, -1, 0);
						fired = true;
					}
				}
				cur->droneCd = fired ? 0.7f : 0.15f;
			}
		}
	}
	cur = &pl[0];
}

// ------------------------------------------------------------------ pickups & loot
void Run::spawnPickup(V2 p, int kind, float val) {
	if (pickups.size() > 260) return;
	Pickup k;
	k.p = p; k.kind = kind; k.val = val;
	k.v = V2::fromAngle(rng.range(0, TAU)) * rng.range(30, 120);
	k.life = kind == PK_UPGRADE ? 30.0f : 20.0f;
	pickups.push_back(k);
}

void Run::spawnCoins(V2 p, int pts) {
	int n = pts <= 10 ? 1 : (pts <= 40 ? 2 : (pts <= 150 ? 3 : 5));
	for (int i = 0; i < n; i++) spawnPickup(p, PK_COIN, (float)pts / (float)n);
}

void Run::dropFromAsteroid(const Asteroid &a) {
	static const int pts[3] = {3, 8, 18};
	if (rng.chance(0.55f)) spawnCoins(a.p, pts[a.size] * (a.type == 2 ? 2 : 1));
	bool haveOrb = false;
	for (const auto &k : pickups) if (k.kind == PK_UPGRADE) haveOrb = true;
	if (haveOrb || anyChoosing()) return;
	int taken = 1 << 20, lucky = 0;
	for (int i = 0; i < np; i++) if (!pl[i].dead) { taken = std::min(taken, pl[i].upgradesTaken); lucky = std::max(lucky, pl[i].pas[P_LUCKY]); }
	if (taken == (1 << 20)) return;
	float sizeF = a.size == 2 ? 1.5f : (a.size == 1 ? 1.0f : 0.5f);
	float chance = (taken < 4 ? 0.18f : 0.07f) * sizeF * (1.0f + cur->storeValue(7)) * (1.0f + 0.25f * lucky);
	bool force = taken == 0 && t > 15.0f;
	if (force || (upgradeDropT <= 0 && rng.chance(chance))) {
		spawnPickup(a.p, PK_UPGRADE, 0);
		upgradeDropT = taken < 4 ? 10.0f : 18.0f;
	}
}

void Run::updatePickups(float dt) {
	bool collectedUpgrade[2] = {false, false};
	for (auto &k : pickups) {
		k.life -= dt;
		k.t += dt;
		int ti = nearestPlayer(k.p);
		if (ti < 0) { k.p += k.v * dt; k.v *= 0.96f; continue; }
		cur = &pl[ti];
		Ship &sh = cur->ship;
		float range = 90.0f * (1.0f + cur->storeValue(5)) * (1.0f + 0.4f * cur->pas[P_MAGNET]);
		float d = dist(k.p, sh.p);
		float pull = k.kind == PK_UPGRADE ? range * 1.6f + 160.0f : range;
		if (d < pull) {
			V2 dir = (sh.p - k.p).norm();
			k.p += dir * (380.0f + 500.0f * (1.0f - d / pull)) * dt;
		} else {
			k.p += k.v * dt;
			k.v *= 0.96f;
		}
		if (d < sh.r + 24.0f) {
			if (k.kind == PK_COIN) {
				int gain = std::max(1, (int)std::round(k.val * 0.5f * (1.0f + cur->storeValue(6))));
				cur->yenEarned += gain;
				sfxEvent(S_YEN);
				k.life = -1;
			} else if (k.kind == PK_HEAL) {
				sh.hp = std::min(sh.maxHp, sh.hp + k.val);
				sfxEvent(S_POWERUP);
				addFx(FX_TEXT, sh.p + V2(0, -40), V2(), 0.8f, 20, 0xFF66FF88, V2(0, -50), "+HP");
				k.life = -1;
			} else if (k.kind == PK_SHIELD) {
				sh.sh = std::min(sh.maxSh, sh.sh + k.val);
				sfxEvent(S_POWERUP);
				k.life = -1;
			} else if (k.kind == PK_UPGRADE && !collectedUpgrade[ti] && !cur->choosing) {
				collectedUpgrade[ti] = true;
				sfxEvent(S_POWERUP);
				k.life = -1;
				cur->upgradesTaken++;
				makeOptions();
				cur->choosing = true;
				cur->chooseT = 0;
			}
		}
	}
	cur = &pl[0];
	pickups.erase(std::remove_if(pickups.begin(), pickups.end(), [](const Pickup &k) { return k.life <= 0; }), pickups.end());
}

// ------------------------------------------------------------------ reaping dead things
void Run::reap() {
	// asteroids
	size_t n = asteroids.size();
	for (size_t i = 0; i < n; i++) {
		if (asteroids[i].hp > 0) continue;
		Asteroid a = asteroids[i];
		sfxEvent(S_ASTEROID);
		for (int k = 0; k < 5; k++)
			addFx(FX_SPARK, a.p, V2(), 0.5f, 2.5f, 0xFFBBBBBB, V2::fromAngle(rng.range(0, TAU)) * rng.range(40, 160));
		if (a.type == 3) explode(a.p, 150, 28.0f, -1, 0xFFFF8833, true);
		if (a.type == 1) {
			for (auto &e : enemies) if (dist(e.p, a.p) < 280) { e.slowT = 2.5f; e.slowAmt = 0.6f; }
			for (auto &o : asteroids) if (dist(o.p, a.p) < 280) { o.slowT = 2.5f; o.slowAmt = 0.6f; }
			addFx(FX_RING, a.p, V2(), 0.5f, 280, 0xFF99DDFF);
		}
		splitAsteroid(a);
		dropFromAsteroid(a);
	}
	asteroids.erase(std::remove_if(asteroids.begin(), asteroids.end(), [](const Asteroid &a) { return a.hp <= 0; }), asteroids.end());

	// enemies
	for (size_t i = 0; i < enemies.size(); i++) {
		if (enemies[i].hp > 0) continue;
		Enemy e = enemies[i];
		const EnemyDef &d = ENEMIES[e.type];
		Player &kp = pl[e.by < np ? e.by : 0];
		kp.kills++;
		kp.abKills++;
		kp.streak++;
		kp.bestStreak = std::max(kp.bestStreak, kp.streak);
		kp.prof->totalKills++;
		sfxEvent(S_ENEMY_DEATH);
		explode(e.p, 70, 0, -1, d.col);
		static const int tierPts[5] = {0, 40, 90, 180, 350};
		spawnCoins(e.p, tierPts[d.tier]);
		if (rng.chance(0.08f)) spawnPickup(e.p, PK_HEAL, 20);
		else if (rng.chance(0.05f)) spawnPickup(e.p, PK_SHIELD, 20);
	}
	enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [](const Enemy &e) { return e.hp <= 0; }), enemies.end());

	// boss
	if (boss.active && boss.hp <= 0) {
		boss.active = false;
		bossKills++;
		Player &kp = pl[boss.by < np ? boss.by : 0];
		kp.kills++;
		kp.streak++;
		kp.bestStreak = std::max(kp.bestStreak, kp.streak);
		kp.prof->totalKills++;
		sfxEvent(S_ENEMY_DEATH);
		explode(boss.p, 260, 0, -1, 0xFFFFCC44);
		for (int k = 0; k < 30; k++)
			addFx(FX_SPARK, boss.p, V2(), 0.9f, 4, 0xFFFFDD66, V2::fromAngle(rng.range(0, TAU)) * rng.range(80, 460));
		spawnCoins(boss.p, 3000);
		spawnPickup(boss.p, PK_UPGRADE, 0);
		for (int i = 0; i < np; i++)
			if (!pl[i].dead) pl[i].ship.hp = std::min(pl[i].ship.maxHp, pl[i].ship.hp + pl[i].ship.maxHp * 0.5f);
		nextBoss = t + 150.0f;
		for (auto &b : ebullets) b.life = 0;
		toast("تم القضاء على الزعيم!");
	}
}

// ------------------------------------------------------------------ upgrades
void Run::addWeapon(int id) {
	WeaponInst w;
	w.id = id;
	w.lvl = isEvolution(id) ? 5 : 1;
	cur->weapons.push_back(w);
	cur->prof->weaponSeen[id] = true;
}

void Run::makeOptions() {
	cur->options.clear();
	for (int i = 0; i < (int)cur->weapons.size(); i++) {
		const auto &w = cur->weapons[i];
		if (!isEvolution(w.id) && w.lvl >= 5 && cur->pas[WEAPONS[w.id].evoPassive] > 0) cur->options.push_back({OK_EVOLVE, i});
	}
	std::vector<Option> pool;
	for (int i = 0; i < (int)cur->weapons.size(); i++)
		if (!isEvolution(cur->weapons[i].id) && cur->weapons[i].lvl < 5) pool.push_back({OK_LEVEL, i});
	if ((int)cur->weapons.size() < weaponMaxSlots()) {
		for (int id = 0; id < W_BASE_COUNT; id++) {
			bool owned = false;
			for (const auto &w : cur->weapons) if (w.id == id || w.id == evolutionOf(id)) owned = true;
			if (!owned) pool.push_back({OK_NEW_WEAPON, id});
		}
	}
	int owned = passivesOwned();
	for (int p = 0; p < P_COUNT; p++) {
		if (cur->pas[p] > 0 && cur->pas[p] < 5) pool.push_back({OK_STACK, p});
		else if (cur->pas[p] == 0 && owned < passiveMaxSlots()) pool.push_back({OK_NEW_PASSIVE, p});
	}
	for (int i = (int)pool.size() - 1; i > 0; i--) std::swap(pool[i], pool[rng.i(i + 1)]);
	int want = 3 + (cur->pas[P_LUCKY] >= 3 ? 1 : 0);
	for (size_t i = 0; i < pool.size() && (int)cur->options.size() < want; i++) cur->options.push_back(pool[i]);
	if (cur->options.empty()) cur->options.push_back({OK_HEAL, 0});
}

void Run::applyOption(const Option &o) {
	switch (o.kind) {
		case OK_NEW_WEAPON: addWeapon(o.a); break;
		case OK_LEVEL: if (o.a >= 0 && o.a < (int)cur->weapons.size()) cur->weapons[o.a].lvl = std::min(5, cur->weapons[o.a].lvl + 1); break;
		case OK_NEW_PASSIVE:
		case OK_STACK:
			cur->pas[o.a] = std::min(5, cur->pas[o.a] + 1);
			if (o.a == P_GLASS) { cur->ship.maxSh = 0; cur->ship.sh = 0; }
			break;
		case OK_EVOLVE: {
			WeaponInst &w = cur->weapons[o.a];
			w.id = evolutionOf(w.id);
			w.lvl = 5;
			w.cd = 0; w.tick = 0; w.aux = 0;
			cur->prof->weaponSeen[w.id] = true;
			sfxEvent(S_EVOLVE);
			addFx(FX_RING, cur->ship.p, V2(), 0.8f, 380, 0xFFFFDD55);
			toast(std::string("تطوير: ") + WEAPONS[w.id].name);
			break;
		}
		case OK_HEAL: cur->ship.hp = std::min(cur->ship.maxHp, cur->ship.hp + cur->ship.maxHp * 0.5f); break;
	}
}

void Run::choose(int pi, int i) {
	if (pi < 0 || pi >= np) return;
	Player *save = cur;
	cur = &pl[pi];
	if (cur->choosing && i >= 0 && i < (int)cur->options.size()) {
		Option o = cur->options[i];
		applyOption(o);
		if (o.kind != OK_EVOLVE) sfxEvent(S_UPGRADE);
		cur->options.clear();
		cur->choosing = false;
	}
	cur = save;
}

std::string Run::optionTitle(int pi, const Option &o) const {
	const Player &p = pl[pi];
	switch (o.kind) {
		case OK_NEW_WEAPON: return WEAPONS[o.a].name;
		case OK_LEVEL: return std::string(WEAPONS[p.weapons[o.a].id].name) + "  Lv" + std::to_string(p.weapons[o.a].lvl + 1);
		case OK_NEW_PASSIVE: return PASSIVES[o.a].name;
		case OK_STACK: return std::string(PASSIVES[o.a].name) + "  x" + std::to_string(p.pas[o.a] + 1);
		case OK_EVOLVE: return WEAPONS[evolutionOf(p.weapons[o.a].id)].name;
		default: return "Repair Kit";
	}
}
std::string Run::optionDesc(int pi, const Option &o) const {
	const Player &p = pl[pi];
	switch (o.kind) {
		case OK_NEW_WEAPON: return WEAPONS[o.a].desc;
		case OK_LEVEL: return "Stronger and more projectiles";
		case OK_NEW_PASSIVE: case OK_STACK: return PASSIVES[o.a].desc;
		case OK_EVOLVE: return WEAPONS[evolutionOf(p.weapons[o.a].id)].desc;
		default: return "Restore 50% health";
	}
}
int Run::optionIcon(int pi, const Option &o, bool &isPassive) const {
	const Player &p = pl[pi];
	isPassive = false;
	switch (o.kind) {
		case OK_NEW_WEAPON: return o.a;
		case OK_LEVEL: return p.weapons[o.a].id;
		case OK_NEW_PASSIVE: case OK_STACK: isPassive = true; return o.a;
		case OK_EVOLVE: return evolutionOf(p.weapons[o.a].id);
		default: return -1;
	}
}

} // namespace nj
