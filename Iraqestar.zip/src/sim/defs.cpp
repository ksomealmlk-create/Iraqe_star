#include "core.hpp"

namespace nj {

const WeaponDef WEAPONS[W_COUNT] = {
	{"pulse_cannon", "Pulse Cannon", "Auto-targeting energy bolts", P_DUP},
	{"energy_saw", "Energy Saw", "Spinning disc that shreds on contact", P_MOMENTUM},
	{"scatter_shot", "Scatter Shot", "Close spread of pellets", P_VAMP},
	{"homing_missiles", "Homing Missiles", "Lock-on missiles", P_TB26},
	{"ion_orbiters", "Ion Orbiters", "Orbiting energy spheres", P_CRYO},
	{"railgun", "Railgun", "Piercing sniper shot", P_GLASS},
	{"space_mines", "Space Mines", "Dropped proximity mines", P_LUCKY},
	{"solar_storm", "Solar Storm", "Random lightning strikes", P_PHOENIX},
	{"nova_blast", "Nova Blast", "Ring burst around your ship", P_REVENGE},
	{"needle_gun", "Needle Gun", "Rapid piercing needles", P_NANO},
	{"cluster_bomb", "Cluster Bomb", "Bomb that scatters bomblets", P_MAGNET},
	{"flak_cannon", "Flak Cannon", "Direct-fire exploding shells", P_SLOT},
	// evolutions
	{"storm_cannon", "Storm Cannon", "A spiral of bolts that fills the field", -1},
	{"warp_saw", "Warp Saw", "The blade detaches and hunts alone", -1},
	{"leech_burst", "Leech Burst", "Pellets that heal you on hit", -1},
	{"autonomous_ace", "Autonomous Ace", "Missiles split and chase new targets", -1},
	{"frost_ring", "Frost Ring", "Two rings of orbs, always turning", -1},
	{"oblivion_beam", "Oblivion Beam", "Always-on piercing lance", -1},
	{"jackpot_mines", "Gambler's Mines", "Mines that sometimes hit the jackpot", -1},
	{"phoenix_flare", "Phoenix Flare", "Three rings erupt where enemies stand", -1},
	{"lingering_nova", "Lingering Nova", "Blasts, leaves a core, blasts again", -1},
	{"siphon_needles", "Siphon Needles", "Piercing needles that heal you on hit", -1},
	{"hunter_killer", "Hunter-Killer", "Homing torpedo, fired twice as often", -1},
	{"flak_barrage", "Flak Barrage", "A burst of five exploding shells", -1},
};

const PassiveDef PASSIVES[P_COUNT] = {
	{"nano_repair", "Nano Repair", "Regenerates health over time"},
	{"duplicator_core", "Duplicator Core", "Adds an extra projectile"},
	{"magnet_field", "Magnet Field", "Increases pickup range"},
	{"phoenix_core", "Phoenix Core", "Resurrect once on death"},
	{"extra_weapon_slot", "Weapon Expansion", "Gain a 5th weapon slot"},
	{"tb26", "TB-26", "Fly with TB-26"},
	{"combat_drone", "Combat Drone", "Deploy Combat Drone"},
	{"momentum_drive", "Momentum Drive", "Damage increases while moving"},
	{"cryo_field", "Cryo Field", "Slow zone around ship"},
	{"lucky_star", "Lucky Star", "More upgrades drop"},
	{"revenge_protocol", "Revenge Protocol", "Retaliatory fire rate burst"},
	{"vampiric_core", "Vampiric Core", "Drain life from nearby asteroids"},
	{"glass_cannon", "Glass Cannon", "No shields, massive damage"},
};

// name, tier, unlock, hp, speed, dmg, fire, range, colour, pattern, radius
const EnemyDef ENEMIES[N_ENEMY] = {
	{"The Juke", 1, 0, 25, 250, 6, 2.0f, 250, 0xFF4488FF, 0, 22},
	{"The Hunter", 1, 30, 30, 230, 8, 1.8f, 280, 0xFF44DD66, 1, 22},
	{"The Shotgunner", 1, 60, 40, 180, 10, 2.2f, 150, 0xFFFF9933, 2, 24},
	{"The Guardian", 2, 120, 60, 140, 10, 1.5f, 180, 0xFF33DDEE, 3, 26},
	{"The Scorcher", 2, 180, 50, 200, 12, 1.2f, 220, 0xFFFF7766, 4, 24},
	{"The Weaver", 2, 240, 70, 150, 15, 2.0f, 300, 0xFFFFDD33, 5, 26},
	{"The Flakker", 3, 300, 100, 150, 15, 1.8f, 200, 0xFFAAEE33, 6, 30},
	{"The Stitcher", 3, 330, 80, 180, 12, 0.8f, 250, 0xFFAA55EE, 7, 28},
	{"The Bomber", 3, 360, 120, 130, 20, 2.5f, 160, 0xFFEE3333, 8, 32},
	{"The Juggernaut", 4, 420, 200, 100, 25, 2.0f, 180, 0xFF5566DD, 9, 38},
	{"The Rusher", 4, 450, 100, 250, 30, 0.6f, 80, 0xFFEE44BB, 10, 28},
	{"The Phantom", 4, 480, 120, 200, 20, 1.5f, 350, 0xFFEEEEEE, 11, 28},
};

const PilotDef PILOTS[N_PILOT] = {
	{"pilot_medic", "MEDIC", "Human", P_NANO, 0xFFFF88AA, U_FREE, 0},
	{"pilot_rascal", "RASCAL", "Raccoon", P_MAGNET, 0xFFDDAA33, U_YEN, 5000},
	{"pilot_brutus", "BRUTUS", "Bear", P_REVENGE, 0xFF77AA33, U_DAMAGE, 500},
	{"pilot_frost", "FROST", "Penguin", P_CRYO, 0xFF55BBFF, U_SURVIVE, 300},
	{"pilot_dash", "DASH", "Cheetah", P_MOMENTUM, 0xFFFFDD22, U_FLIGHT, 30},
	{"pilot_ember", "EMBER", "Phoenix", P_PHOENIX, 0xFFFF6622, U_DEATHS, 18},
	{"pilot_fang", "FANG", "Bat", P_VAMP, 0xFF8844CC, U_KILLS_RUN, 5},
	{"pilot_kraken", "KRAKEN", "Octopus", P_SLOT, 0xFF33AAAA, U_WEAPONS, 6},
	{"pilot_whiskers", "WHISKERS", "Cat", P_LUCKY, 0xFFFFBB88, U_JACKPOT, 0},
	{"pilot_unit7", "UNIT-7", "Robot", P_DUP, 0xFF44EE55, U_KILLS, 100},
	{"pilot_havoc", "HAVOC", "Human", P_GLASS, 0xFFBBFF22, U_SURVIVE, 540},
	{"pilot_astro", "ASTRO", "Human", P_TB26, 0xFFDD3333, U_ALL, 0},
};

const StoreTile STORE[N_STORE] = {
	{"health", "لوح الخردة", "+10 للصحة القصوى", "تنجو من ضربات أكثر.", "salvage_plate", 10},
	{"shields", "جهاز الصد", "+10 للدرع الأقصى", "يمتص ضربات أكثر.", "deflector_rig", 10},
	{"speed", "دفعة النيترو", "+5% سرعة السفينة", "تتحرك أسرع.", "nitro_boost", 0.05f},
	{"damage", "طلقات ساخنة", "+5% لكل الضرر", "كل ما تطلقه يضرب بقوة أكبر.", "hot_rounds", 0.05f},
	{"crit", "طلقات محظوظة", "+5% فرصة الضربة الحرجة", "بعض الطلقات تضرب بضعف القوة.", "lucky_rounds", 0.05f},
	{"magnet", "حبل الجر", "+15% نطاق الالتقاط", "يجمع الغنائم من مسافة أبعد.", "haul_line", 0.15f},
	{"yen_bonus", "عمولة الباحث", "+20% د.ع مكتسب", "اكسب أكثر بكل جولة.", "finders_fee", 0.20f},
	{"salvage", "جهاز اللقّاط", "+20% معدل الإسقاط", "الكويكبات تُسقط ترقيات بشكل أكثر تكراراً.", "scavenger_rig", 0.20f},
};

const AchDef ACHS[N_ACH] = {
	{"first_kill", "أول صيدة", "اقتل أول عدو"},
	{"kills_100", "صياد النجوم", "اقتل 100 عدو"},
	{"kills_1000", "أسطورة الفضاء", "اقتل 1000 عدو"},
	{"streak_20", "سلسلة نار", "سلسلة قتل 20"},
	{"survive_120", "صامد", "ابقَ حياً دقيقتين"},
	{"first_death", "لا بأس", "أول خسارة لك"},
	{"weapons_5", "جامع الأسلحة", "اكتشف 5 أسلحة"},
	{"casino_10", "مقامر", "العب الكازينو 10 مرات"},
};

const int UPGRADE_COSTS[5] = {1000, 2500, 7500, 25000, 50000};

} // namespace nj
