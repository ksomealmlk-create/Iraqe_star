#include "nujoom_game.hpp"
#include "net_config.hpp"
#include "firebase_config.hpp"

#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>

#include <godot_cpp/classes/audio_stream_ogg_vorbis.hpp>
#include <godot_cpp/classes/engine.hpp>
#include <godot_cpp/classes/http_client.hpp>
#include <godot_cpp/classes/os.hpp>
#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/classes/file_access.hpp>
#include <godot_cpp/classes/input_event_screen_drag.hpp>
#include <godot_cpp/classes/input_event_screen_touch.hpp>
#include <godot_cpp/classes/resource_loader.hpp>
#include <godot_cpp/classes/scene_tree.hpp>
#include <godot_cpp/classes/theme_db.hpp>
#include <godot_cpp/classes/time.hpp>
#include <godot_cpp/core/memory.hpp>
#include <godot_cpp/variant/packed_vector2_array.hpp>
#include <godot_cpp/variant/transform2d.hpp>

using namespace godot;

static const char *SAVE_PATH = "user://nujoom_profile.dat";

// وضع التجربة: كل ما تفتح اللعبة يصير رصيدك مليار د.ع حتى تجرب كل المتجر. غيّرها إلى 0 لإلغاء الوضع قبل النشر.
static const long long TEST_YEN = 1000000000LL;

Color NujoomGame::Cc(uint32_t argb, float am) {
	return Color(((argb >> 16) & 255) / 255.0f, ((argb >> 8) & 255) / 255.0f, (argb & 255) / 255.0f, (((argb >> 24) & 255) / 255.0f) * am);
}

static bool hasArabic(const std::string &s) {
	for (unsigned char ch : s)
		if (ch == 0xD8 || ch == 0xD9 || ch == 0xDA || ch == 0xDB) return true;
	return false;
}

static std::string commas(long long v) {
	std::string s = std::to_string(v), out;
	int c = 0;
	for (int i = (int)s.size() - 1; i >= 0; i--) {
		out.insert(out.begin(), s[i]);
		if (++c % 3 == 0 && i > 0) out.insert(out.begin(), ',');
	}
	return out;
}

static std::string mmss(float t) {
	int s = (int)t;
	char b[16];
	std::snprintf(b, sizeof b, "%d:%02d", s / 60, s % 60);
	return b;
}

// ------------------------------------------------------------------ resources
Ref<Texture2D> NujoomGame::tex(const std::string &path) {
	auto it = texCache.find(path);
	if (it != texCache.end()) return it->second;
	Ref<Resource> r = ResourceLoader::get_singleton()->load(S(path));
	Ref<Texture2D> t = r;
	texCache[path] = t;
	return t;
}

Ref<AudioStream> NujoomGame::snd(const std::string &path) {
	auto it = sndCache.find(path);
	if (it != sndCache.end()) return it->second;
	Ref<Resource> r = ResourceLoader::get_singleton()->load(S(path));
	Ref<AudioStream> s = r;
	sndCache[path] = s;
	return s;
}

Ref<Font> NujoomGame::loadFont(const char *path) {
	Ref<Resource> r = ResourceLoader::get_singleton()->load(path);
	Ref<Font> f = r;
	if (f.is_null()) f = ThemeDB::get_singleton()->get_fallback_font();
	return f;
}

void NujoomGame::playSfx(const std::string &name, double minGap) {
	if (sfxPlayers.empty()) return;
	double now = Time::get_singleton()->get_ticks_msec() / 1000.0;
	size_t h = std::hash<std::string>()(name) % 64;
	if (now - sfxLast[h] < minGap) return;
	sfxLast[h] = now;
	Ref<AudioStream> s = snd("res://assets/audio/sfx/" + name + ".ogg");
	if (s.is_null()) return;
	AudioStreamPlayer *p = sfxPlayers[sfxNext++ % sfxPlayers.size()];
	p->set_stream(s);
	p->play();
}

void NujoomGame::playSfxId(int id) {
	using namespace nj;
	switch (id) {
		case S_ASTEROID: playSfx("sfx_asteroid_break", 0.06); break;
		case S_ENEMY_DEATH: playSfx("sfx_enemy_death", 0.06); break;
		case S_EXPLOSION: playSfx("sfx_explosion", 0.08); break;
		case S_PLAYER_HIT: playSfx("sfx_player_hit", 0.1); break;
		case S_SHIELD_HIT: playSfx("sfx_shield_hit", 0.1); break;
		case S_SHIELD_BREAK: playSfx("sfx_shield_break", 0.1); break;
		case S_PLAYER_DEATH: playSfx("sfx_player_death", 0.1); break;
		case S_POWERUP: playSfx("sfx_powerup_pickup", 0.1); break;
		case S_YEN: playSfx("sfx_yen_pickup", 0.07); break;
		case S_BOSS: playSfx("sfx_boss_spawn", 0.5); break;
		case S_EVOLVE: playSfx("sfx_evolution", 0.5); break;
		case S_REVIVE: playSfx("sfx_phoenix_revive", 0.5); break;
		case S_UPGRADE: playSfx("sfx_ui_upgrade_select", 0.1); break;
		case S_NEAR_MISS: playSfx("sfx_near_miss", 0.2); break;
		default:
			if (id >= S_WEAPON_BASE && id < S_WEAPON_BASE + W_COUNT)
				playSfx(std::string("sfx_weapon_") + WEAPONS[id - S_WEAPON_BASE].key, 0.08);
	}
}

void NujoomGame::playMusic(const std::string &name) {
	if (!music || musicName == name) return;
	musicName = name;
	Ref<AudioStream> s = snd("res://assets/audio/music/" + name + ".ogg");
	if (s.is_null()) return;
	Ref<AudioStreamOggVorbis> ogg = s;
	if (ogg.is_valid()) ogg->set_loop(true);
	music->set_stream(s);
	music->play();
}

void NujoomGame::loadProfile() {
	if (!FileAccess::file_exists(SAVE_PATH)) return;
	Ref<FileAccess> f = FileAccess::open(SAVE_PATH, FileAccess::READ);
	if (f.is_null()) return;
	String s = f->get_as_text();
	prof.deserialize(std::string(s.utf8().get_data()));
}

void NujoomGame::saveProfile() {
	Ref<FileAccess> f = FileAccess::open(SAVE_PATH, FileAccess::WRITE);
	if (f.is_null()) return;
	f->store_string(S(prof.serialize()));
	fbDirty = true;
}

// ------------------------------------------------------------------ lifecycle
void NujoomGame::_ready() {
	if (Engine::get_singleton()->is_editor_hint()) return;
	set_process(true);
	set_process_input(true);
	get_tree()->set_auto_accept_quit(false);
	fontLat = loadFont("res://assets/fonts/exo2_bold.ttf");
	fontAr = loadFont("res://assets/fonts/DejaVuSans-Bold.ttf");
	for (int i = 0; i < 12; i++) {
		AudioStreamPlayer *p = memnew(AudioStreamPlayer);
		add_child(p);
		p->set_volume_db(-3.0f);
		sfxPlayers.push_back(p);
	}
	music = memnew(AudioStreamPlayer);
	add_child(music);
	music->set_volume_db(-10.0f);
	nj::Rng r(12345);
	for (int l = 0; l < 3; l++)
		for (int i = 0; i < 55; i++) stars[l].push_back(Vector2(r.f(), r.f()));
	loadProfile();
	if (TEST_YEN > 0 && prof.yen < TEST_YEN) prof.yen = TEST_YEN;
	prof.refreshPilots();
	nameEdit = memnew(LineEdit);
	add_child(nameEdit);
	nameEdit->set_max_length(12);
	nameEdit->set_placeholder("اكتب اسمك هنا");
	nameEdit->set_horizontal_alignment(HORIZONTAL_ALIGNMENT_CENTER);
	if (fontAr.is_valid()) nameEdit->add_theme_font_override("font", fontAr);
	nameEdit->add_theme_color_override("font_color", Color(1, 1, 1));
	nameEdit->set_visible(false);
	fbInit();
	applyPlayerName();
	goTo(SC_MENU);
	if (prof.playerName.empty()) openNameAsk();   // أول مرة: يختار اسمه
}

void NujoomGame::_notification(int p_what) {
	if (p_what == 1007) { // NOTIFICATION_WM_GO_BACK_REQUEST
		if (updShow) { if (!updForce) updShow = false; return; }
		if (nameAsk) { if (!prof.playerName.empty()) nameAsk = false; return; }   // أول مرة لازم يختار اسم
		if (screen == SC_PLAY) paused = !paused;
		else if (screen == SC_MENU) get_tree()->quit();
		else if (screen == SC_OVER) goTo(SC_MENU);
		else if (screen == SC_LOBBY && netState != NS_IDLE) onButton(B_BACK);
		else goTo(SC_MENU);
	}
}

void NujoomGame::goTo(Screen s) {
	if (s == SC_MENU) {
		netClose();
		duel = false;
	}
	if (s == SC_LOBBY) {
		netState = NS_IDLE;
		netMsg.clear();
		netInput.clear();
		peerHello = false;
		peerLeft = false;
	}
	if (s == SC_BOARD) {
		boardWant = true;
		board.clear();
		boardMsg.clear();
	}
	screen = s;
	paused = false;
	joyId = -1;
	joyVec = Vector2();
	if (s == SC_PLAY) playMusic("combat");
	else playMusic("hangar");
	if (s == SC_CREW) crewFocus = prof.pilot;
}

void NujoomGame::startRun(bool asDuel, uint64_t seed) {
	if (seed == 0) seed = Time::get_singleton()->get_ticks_usec();
	duel = asDuel;
	snapT = 0;
	inSendT = 0;
	peerMove = nj::V2();
	peerMoveT = 0;
	peerLeft = false;
	chooseHideT = 0;
	if (!asDuel) {
		run.reset(new nj::Run(&prof, prof.pilot, seed));
	} else if (netYou == 0) {
		run.reset(new nj::Run(&prof, prof.pilot, seed, netMode, peerPilot, peerStore));
	} else {
		// guest: a mirror of the host's game, filled from snapshots
		run.reset(new nj::Run(nullptr, hostPilot, seed, netMode, prof.pilot, nullptr));
		run->remote = true;
	}
	toasts.clear();
	playSfx("sfx_launch", 0.1);
	goTo(SC_PLAY);
}

void NujoomGame::endRun() {
	if (!run) return;
	int m = me();
	const nj::Player &p = run->pl[m];
	lastDied = p.dead;
	lastTime = run->t;
	lastKills = p.kills;
	lastYen = p.yenEarned;
	lastStreak = p.bestStreak;
	lastBoss = run->bossKills;
	lastDuel = duel;
	lastMode = duel ? run->mode : nj::GM_SOLO;
	lastWinner = run->winner;
	lastNp = run->np;
	lastMe = m;
	for (int i = 0; i < 2; i++) {
		lastSum[i].kills = i < run->np ? run->pl[i].kills : 0;
		lastSum[i].yen = i < run->np ? run->pl[i].yenEarned : 0;
		lastSum[i].dead = i < run->np ? run->pl[i].dead : false;
		lastSum[i].quit = i < run->np ? run->pl[i].quit : false;
	}
	if (duel && !run->remote && netOpen && ws.is_valid()) {
		// last snapshot so the guest sees the end of the match
		run->writeSnapshot(snapBuf);
		netSendBin(snapBuf);
		ws->poll();
	}
	if (run->remote) {
		// the host's Run only updated the host profile; the guest applies its own result here
		prof.yen += p.yenEarned;
		prof.totalYenEarned += p.yenEarned;
		prof.totalKills += p.kills;
		if (p.dead && !p.quit) prof.totalDeaths++;
		prof.bestSurvival = std::max(prof.bestSurvival, (int)run->t);
		prof.maxKillsRun = std::max(prof.maxKillsRun, p.kills);
		prof.bestStreak = std::max(prof.bestStreak, p.bestStreak);
		for (int i : prof.checkAchievements()) addToast(std::string("إنجاز جديد: ") + nj::ACHS[i].titleAr);
		for (int i : prof.refreshPilots()) addToast(std::string("انضم طيار جديد: ") + nj::PILOTS[i].callsign);
	}
	saveProfile();
	goTo(SC_OVER);
}

void NujoomGame::addToast(const std::string &s) {
	if (toasts.size() < 4) toasts.push_back({s, 3.5f});
}


// ------------------------------------------------------------------ Firebase (REST)
static const char *FB_AUTH_PATH = "user://fb_auth.dat";

static Dictionary fsStr(const String &s) {
	Dictionary d;
	d["stringValue"] = s;
	return d;
}
static Dictionary fsInt(long long v) {
	Dictionary d;
	d["integerValue"] = String::num_int64((int64_t)v);
	return d;
}
static std::string fsGetStr(const Dictionary &f, const char *k) {
	if (!f.has(k)) return "";
	Dictionary x = f[k];
	String s = x.get("stringValue", "");
	return std::string(s.utf8().get_data());
}
static long long fsGetInt(const Dictionary &f, const char *k) {
	if (!f.has(k)) return 0;
	Dictionary x = f[k];
	String s = x.get("integerValue", "0");
	return (long long)s.to_int();
}

void NujoomGame::_bind_methods() {
	ClassDB::bind_method(D_METHOD("fb_auth_done", "result", "code", "headers", "body"), &NujoomGame::fbAuthDone);
	ClassDB::bind_method(D_METHOD("fb_save_done", "result", "code", "headers", "body"), &NujoomGame::fbSaveDone);
	ClassDB::bind_method(D_METHOD("fb_lb_done", "result", "code", "headers", "body"), &NujoomGame::fbLbDone);
	ClassDB::bind_method(D_METHOD("fb_load_done", "result", "code", "headers", "body"), &NujoomGame::fbLoadDone);
	ClassDB::bind_method(D_METHOD("fb_board_done", "result", "code", "headers", "body"), &NujoomGame::fbBoardDone);
	ClassDB::bind_method(D_METHOD("fb_cfg_done", "result", "code", "headers", "body"), &NujoomGame::fbCfgDone);
}

std::string NujoomGame::fbDocUrl(const std::string &path) const {
	return std::string("https://firestore.googleapis.com/v1/projects/") + FB_PROJECT_ID + "/databases/(default)/documents/" + path;
}

PackedStringArray NujoomGame::fbHeaders() const {
	PackedStringArray h;
	h.push_back("Content-Type: application/json");
	if (!fbIdToken.empty()) h.push_back(String("Authorization: Bearer ") + S(fbIdToken));
	return h;
}

void NujoomGame::fbInit() {
#if FB_ENABLED
	auto mk = [&](HTTPRequest *&p, const char *cb) {
		p = memnew(HTTPRequest);
		add_child(p);
		p->set_timeout(20.0);
		p->connect("request_completed", Callable(this, cb));
	};
	mk(fbAuthReq, "fb_auth_done");
	mk(fbSaveReq, "fb_save_done");
	mk(fbLbReq, "fb_lb_done");
	mk(fbLoadReq, "fb_load_done");
	mk(fbBoardReq, "fb_board_done");
	mk(fbCfgReq, "fb_cfg_done");
	if (FileAccess::file_exists(FB_AUTH_PATH)) {
		Ref<FileAccess> f = FileAccess::open(FB_AUTH_PATH, FileAccess::READ);
		if (f.is_valid()) {
			fbRefresh = std::string(f->get_line().strip_edges().utf8().get_data());
			fbUid = std::string(f->get_line().strip_edges().utf8().get_data());
			fbName = std::string(f->get_line().strip_edges().utf8().get_data());
		}
	}
	fbFetchConfig();
#endif
}

void NujoomGame::fbSaveAuth() {
	Ref<FileAccess> f = FileAccess::open(FB_AUTH_PATH, FileAccess::WRITE);
	if (f.is_null()) return;
	f->store_line(S(fbRefresh));
	f->store_line(S(fbUid));
	f->store_line(S(fbName));
}

void NujoomGame::fbSignUp() {
	fbAuthBusy = true;
	Dictionary d;
	d["returnSecureToken"] = true;
	PackedStringArray h;
	h.push_back("Content-Type: application/json");
	Error e = fbAuthReq->request(String("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=") + FB_API_KEY, h, HTTPClient::METHOD_POST, JSON::stringify(d));
	if (e != OK) { fbAuthBusy = false; fbRetryT = 30; }
}

void NujoomGame::fbRefreshTok() {
	fbAuthBusy = true;
	PackedStringArray h;
	h.push_back("Content-Type: application/x-www-form-urlencoded");
	String body = String("grant_type=refresh_token&refresh_token=") + S(fbRefresh).uri_encode();
	Error e = fbAuthReq->request(String("https://securetoken.googleapis.com/v1/token?key=") + FB_API_KEY, h, HTTPClient::METHOD_POST, body);
	if (e != OK) { fbAuthBusy = false; fbRetryT = 30; }
}

void NujoomGame::fbAuthDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	fbAuthBusy = false;
	Variant v = JSON::parse_string(body.get_string_from_utf8());
	Dictionary d;
	if (v.get_type() == Variant::DICTIONARY) d = v;
	if (code != 200 || d.is_empty()) {
		fbSignedIn = false;
		fbLastErr = "HTTP " + std::to_string(code);
		if (d.has("error")) {
			Dictionary er = d["error"];
			String m = er.get("message", "");
			fbLastErr = std::string(m.utf8().get_data());
		}
		if (!fbRefresh.empty() && (code == 400 || code == 401)) fbRefresh.clear();   // الرمز القديم مرفوض: نسجّل حساب جديد
		fbRetryT = fbRefresh.empty() ? 15.0f : 30.0f;
		return;
	}
	String id = d.get("idToken", d.get("id_token", ""));
	String rt = d.get("refreshToken", d.get("refresh_token", ""));
	String uid = d.get("localId", d.get("user_id", ""));
	String ex = d.get("expiresIn", d.get("expires_in", "3600"));
	fbIdToken = std::string(id.utf8().get_data());
	if (!rt.is_empty()) fbRefresh = std::string(rt.utf8().get_data());
	std::string newUid = std::string(uid.utf8().get_data());
	if (!newUid.empty()) {
		if (newUid != fbUid) fbName.clear();
		fbUid = newUid;
	}
	if (!prof.playerName.empty()) fbName = std::string("طيار-") + prof.playerName;
	else if (fbName.empty() && fbUid.size() >= 4) {
		std::string t = fbUid.substr(fbUid.size() - 4);
		for (auto &ch : t) ch = (char)std::toupper((unsigned char)ch);
		fbName = std::string("طيار-") + t;
	}
	fbTokenLeft = (float)ex.to_float();
	fbSignedIn = !fbIdToken.empty() && !fbUid.empty();
	fbLastErr.clear();
	fbSaveAuth();
}

void NujoomGame::fbLoadCloud() {
	fbLoadBusy = true;
	Error e = fbLoadReq->request(S(fbDocUrl("players/" + fbUid)), fbHeaders(), HTTPClient::METHOD_GET);
	if (e != OK) { fbLoadBusy = false; fbLoadRetryT = 15; }
}

void NujoomGame::fbLoadDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	fbLoadBusy = false;
	if (code == 404) {   // أول مرة: ما في نسخة سحابية، نرفع اللي عندنا
		fbLoaded = true;
		fbDirty = true;
		return;
	}
	if (code == 401) { fbTokenLeft = 0; fbLoadRetryT = 3; return; }
	if (code != 200) { fbLoadRetryT = code == 403 ? 60.0f : 20.0f; return; }
	Variant v = JSON::parse_string(body.get_string_from_utf8());
	if (v.get_type() != Variant::DICTIONARY) { fbLoadRetryT = 20; return; }
	Dictionary doc = v;
	Dictionary f = doc.get("fields", Dictionary());
	std::string ps = fsGetStr(f, "profile");
	nj::Profile cl;
	cl.deserialize(ps);
	bool better = cl.totalYenEarned > prof.totalYenEarned || (cl.totalYenEarned == prof.totalYenEarned && cl.totalKills > prof.totalKills);
	if (better && !ps.empty()) {
		fbPendingProfile = ps;
		fbPendingCloud = true;   // نطبّقها في القائمة الرئيسية عشان ما نخرب جولة شغّالة
	} else {
		fbDirty = true;
	}
	fbLoaded = true;
}

void NujoomGame::fbApplyPending() {
	nj::Profile cl;
	cl.deserialize(fbPendingProfile);
	std::string keepName = prof.playerName;
	prof = cl;
	if (prof.playerName.empty()) prof.playerName = keepName;
	applyPlayerName();
	if (TEST_YEN > 0 && prof.yen < TEST_YEN) prof.yen = TEST_YEN;
	prof.refreshPilots();
	fbPendingCloud = false;
	fbPendingProfile.clear();
	saveProfile();
	addToast("تم استرجاع تقدمك من السحابة");
}

void NujoomGame::fbPushCloud() {
	Dictionary f;
	f["profile"] = fsStr(S(prof.serialize()));
	f["name"] = fsStr(S(fbName));
	f["totalKills"] = fsInt(prof.totalKills);
	f["bestSurvival"] = fsInt(prof.bestSurvival);
	f["maxKillsRun"] = fsInt(prof.maxKillsRun);
	f["totalYenEarned"] = fsInt(prof.totalYenEarned);
	f["updated"] = fsInt((long long)Time::get_singleton()->get_unix_time_from_system());
	Dictionary b;
	b["fields"] = f;
	String url = S(fbDocUrl("players/" + fbUid)) + "?updateMask.fieldPaths=profile&updateMask.fieldPaths=name&updateMask.fieldPaths=totalKills&updateMask.fieldPaths=bestSurvival&updateMask.fieldPaths=maxKillsRun&updateMask.fieldPaths=totalYenEarned&updateMask.fieldPaths=updated";
	Error e = fbSaveReq->request(url, fbHeaders(), HTTPClient::METHOD_PATCH, JSON::stringify(b));
	if (e != OK) fbDirty = true;
}

void NujoomGame::fbSaveDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	if (code == 401) { fbTokenLeft = 0; fbDirty = true; return; }
	if (code != 200) { fbDirty = true; fbSaveCd = 60; return; }
	if (prof.bestSurvival <= 0) return;
	// لوحة المتصدرين: وثيقة صغيرة منفصلة تقرأها كل اللاعبين
	Dictionary f;
	f["name"] = fsStr(S(fbName));
	f["bestSurvival"] = fsInt(prof.bestSurvival);
	f["maxKillsRun"] = fsInt(prof.maxKillsRun);
	f["totalKills"] = fsInt(prof.totalKills);
	Dictionary b;
	b["fields"] = f;
	String url = S(fbDocUrl("leaderboard/" + fbUid)) + "?updateMask.fieldPaths=name&updateMask.fieldPaths=bestSurvival&updateMask.fieldPaths=maxKillsRun&updateMask.fieldPaths=totalKills";
	fbLbReq->request(url, fbHeaders(), HTTPClient::METHOD_PATCH, JSON::stringify(b));
}

void NujoomGame::fbLbDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	if (code == 401) fbTokenLeft = 0;
}

void NujoomGame::fbFetchBoard() {
	fbBoardBusy = true;
	Dictionary from;
	from["collectionId"] = "leaderboard";
	Array fromA;
	fromA.push_back(from);
	Dictionary fld;
	fld["fieldPath"] = "bestSurvival";
	Dictionary ob;
	ob["field"] = fld;
	ob["direction"] = "DESCENDING";
	Array obA;
	obA.push_back(ob);
	Dictionary sq;
	sq["from"] = fromA;
	sq["orderBy"] = obA;
	sq["limit"] = 20;
	Dictionary b;
	b["structuredQuery"] = sq;
	String qurl = String("https://firestore.googleapis.com/v1/projects/") + FB_PROJECT_ID + "/databases/(default)/documents:runQuery";
	Error e = fbBoardReq->request(qurl, fbHeaders(), HTTPClient::METHOD_POST, JSON::stringify(b));
	if (e != OK) { fbBoardBusy = false; boardMsg = "تعذر تحميل القائمة"; }
}

void NujoomGame::fbBoardDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	fbBoardBusy = false;
	Variant v = JSON::parse_string(body.get_string_from_utf8());
	if (code == 401) { fbTokenLeft = 0; boardWant = true; return; }
	if (code != 200 || v.get_type() != Variant::ARRAY) {
		boardMsg = code == 403 ? "ما عندك صلاحية. تأكد من قواعد Firestore" : "تعذر تحميل القائمة";
		return;
	}
	Array a = v;
	board.clear();
	for (int i = 0; i < a.size(); i++) {
		Dictionary e = a[i];
		if (!e.has("document")) continue;
		Dictionary doc = e["document"];
		Dictionary f = doc.get("fields", Dictionary());
		BoardRow r;
		String nm = doc.get("name", "");
		int sl = nm.rfind("/");
		r.uid = std::string((sl >= 0 ? nm.substr(sl + 1) : nm).utf8().get_data());
		r.name = fsGetStr(f, "name");
		r.surv = (int)fsGetInt(f, "bestSurvival");
		r.kills = (int)fsGetInt(f, "maxKillsRun");
		board.push_back(r);
	}
	if (board.empty()) boardMsg = "ما في لاعبين بعد. كن أول واحد!";
}

void NujoomGame::fbFetchConfig() {
	String url = S(fbDocUrl("config/app")) + "?key=" + FB_API_KEY;
	fbCfgReq->request(url, PackedStringArray(), HTTPClient::METHOD_GET);
}

void NujoomGame::fbCfgDone(int result, int code, const PackedStringArray &headers, const PackedByteArray &body) {
	if (code != 200) return;
	Variant v = JSON::parse_string(body.get_string_from_utf8());
	if (v.get_type() != Variant::DICTIONARY) return;
	Dictionary doc = v;
	Dictionary f = doc.get("fields", Dictionary());
	long long latest = fsGetInt(f, "latestVersion");
	std::string url = fsGetStr(f, "apkUrl");
	std::string msg = fsGetStr(f, "message");
	std::string ann = fsGetStr(f, "announcement");
	bool force = false;
	if (f.has("force")) {
		Dictionary x = f["force"];
		force = (bool)x.get("booleanValue", false);
	}
	if (latest > FB_APP_VERSION && url.rfind("https://", 0) == 0) {
		updShow = true;
		updForce = force;
		updUrl = url;
		updMsg = msg;
	}
	if (!ann.empty() && ann != fbSeenAnn) {
		fbSeenAnn = ann;
		addToast(ann);
	}
}

void NujoomGame::fbTick(float dt) {
#if FB_ENABLED
	if (!fbAuthReq) return;
	if (fbRetryT > 0) fbRetryT -= dt;
	if (fbLoadRetryT > 0) fbLoadRetryT -= dt;
	if (fbSaveCd > 0) fbSaveCd -= dt;
	if (fbSignedIn) fbTokenLeft -= dt;
	if (!fbAuthBusy && fbRetryT <= 0 && (!fbSignedIn || fbTokenLeft < 120.0f)) {
		if (!fbRefresh.empty()) fbRefreshTok();
		else fbSignUp();
	}
	bool ok = fbSignedIn && fbTokenLeft > 60.0f;
	if (ok && !fbLoaded && !fbLoadBusy && fbLoadRetryT <= 0) fbLoadCloud();
	if (fbPendingCloud && screen == SC_MENU) fbApplyPending();
	if (ok && fbDirty && fbLoaded && !fbPendingCloud && fbSaveCd <= 0 && screen != SC_PLAY) {
		fbDirty = false;
		fbSaveCd = 10;
		fbPushCloud();
	}
	if (screen == SC_BOARD && boardWant && ok && !fbBoardBusy) {
		boardWant = false;
		fbFetchBoard();
	}
#endif
}

void NujoomGame::drawBoard() {
	drawHeader("المتصدرون");
	text("أطول بقاء في رحلة واحدة", W * 0.5f, 150 * u, 28 * u, Color(0.8f, 0.9f, 1));
	button(B_NAME_EDIT, Rect2(W - 250 * u, 112 * u, 230 * u, 58 * u), "تغيير الاسم", Color(0.25f, 0.3f, 0.5f), 26);
	if (board.empty()) {
		std::string m = boardMsg;
		if (m.empty()) {
			if (!fbSignedIn) m = fbLastErr.empty() ? "جاري تسجيل الدخول..." : "تعذر الدخول: " + fbLastErr;
			else m = "جاري التحميل...";
		}
		textFit(m, W * 0.5f, H * 0.3f, 34 * u, W - 80 * u, Color(1, 0.9f, 0.6f));
		return;
	}
	float top = 190 * u, rh = std::min(92.0f * u, (H - top - 20 * u) / 20.0f);
	for (size_t i = 0; i < board.size() && i < 20; i++) {
		const BoardRow &r = board[i];
		Rect2 rc(30 * u, top + rh * (float)i + 3 * u, W - 60 * u, rh - 6 * u);
		bool mine = r.uid == fbUid;
		panel(rc, Color(0, 0, 0, 0.5f), mine ? Color(0.4f, 1, 0.5f) : Color(1, 1, 1, 0.25f));
		float y = rc.position.y + rc.size.y * 0.5f + 11 * u;
		text(std::to_string(i + 1), W - 50 * u, y, 32 * u, i < 3 ? Color(1, 0.85f, 0.3f) : Color(0.85f, 0.9f, 1), 2);
		textFit(r.name.empty() ? "طيار" : r.name, W - 120 * u, y, 30 * u, W * 0.42f, mine ? Color(0.5f, 1, 0.6f) : Color(1, 1, 1), 2);
		text(mmss((float)r.surv), 50 * u, y, 30 * u, Color(1, 0.9f, 0.4f), 0);
		text(std::to_string(r.kills) + " قتيل", 190 * u, y, 24 * u, Color(0.8f, 0.85f, 0.95f), 0);
	}
}

// ------------------------------------------------------------------ اسم اللاعب
void NujoomGame::applyPlayerName() {
	if (!prof.playerName.empty()) fbName = std::string("طيار-") + prof.playerName;
}

void NujoomGame::openNameAsk() {
	if (!nameEdit) return;
	nameAsk = true;
	nameMsg.clear();
	nameEdit->set_text(S(prof.playerName));
	nameEdit->set_visible(true);
	nameEdit->grab_focus();
}

void NujoomGame::confirmName() {
	if (!nameEdit) return;
	String t = nameEdit->get_text().strip_edges();
	t = t.replace("=", "").replace("\n", "").replace("\r", "").replace("\t", "").strip_edges();
	if (t.length() < 2) {
		nameMsg = "اكتب اسم من حرفين على الأقل";
		return;
	}
	if (t.length() > 12) t = t.substr(0, 12);
	prof.playerName = std::string(t.utf8().get_data());
	applyPlayerName();
	nameAsk = false;
	nameEdit->release_focus();
	nameEdit->set_visible(false);
	saveProfile();   // يرفع الاسم للسحابة ولوحة المتصدرين
	fbSaveAuth();
	addToast("أهلاً " + prof.playerName);
}

void NujoomGame::drawName() {
	if (!nameAsk) {
		if (nameEdit && nameEdit->is_visible()) {
			nameEdit->release_focus();
			nameEdit->set_visible(false);
		}
		return;
	}
	btns.clear();   // النافذة تحجب أزرار الشاشة اللي تحتها
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.82f), true);
	float pw = std::min(W - 60 * u, 800 * u);
	bool first = prof.playerName.empty();
	Rect2 r(W * 0.5f - pw * 0.5f, H * 0.1f, pw, (first ? 520.0f : 620.0f) * u);
	panel(r, Color(0.05f, 0.08f, 0.18f, 0.97f), Color(1, 0.85f, 0.3f));
	text(first ? "اختر اسمك" : "تغيير الاسم", W * 0.5f, r.position.y + 85 * u, 52 * u, Color(1, 0.85f, 0.3f));
	textFit("يظهر بلوحة المتصدرين: طيار-اسمك", W * 0.5f, r.position.y + 150 * u, 28 * u, pw - 50 * u, Color(0.8f, 0.9f, 1));
	if (nameEdit) {
		nameEdit->set_visible(!updShow);
		nameEdit->add_theme_font_size_override("font_size", (int)(40 * u));
		nameEdit->set_position(Vector2(r.position.x + 40 * u, r.position.y + 190 * u));
		nameEdit->set_size(Vector2(pw - 80 * u, 90 * u));
	}
	if (!nameMsg.empty()) textFit(nameMsg, W * 0.5f, r.position.y + 325 * u, 28 * u, pw - 60 * u, Color(1, 0.6f, 0.5f));
	button(B_NAME_OK, Rect2(r.position.x + 40 * u, r.position.y + 350 * u, pw - 80 * u, 100 * u), "تأكيد", Color(0.15f, 0.65f, 0.3f), 44);
	if (!first) button(B_NAME_CANCEL, Rect2(r.position.x + 40 * u, r.position.y + 470 * u, pw - 80 * u, 90 * u), "إلغاء", Color(0.35f, 0.38f, 0.5f), 36);
}

void NujoomGame::drawUpdate() {
	if (!updShow) return;
	btns.clear();   // النافذة تحجب أزرار الشاشة اللي تحتها
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.78f), true);
	float pw = std::min(W - 60 * u, 780 * u);
	Rect2 r(W * 0.5f - pw * 0.5f, H * 0.3f, pw, 520 * u);
	panel(r, Color(0.05f, 0.08f, 0.18f, 0.97f), Color(1, 0.85f, 0.3f));
	text("تحديث جديد متوفر", W * 0.5f, r.position.y + 90 * u, 52 * u, Color(1, 0.85f, 0.3f));
	textFit(updMsg.empty() ? "نزّل آخر نسخة من اللعبة" : updMsg, W * 0.5f, r.position.y + 190 * u, 32 * u, pw - 60 * u, Color(0.9f, 0.95f, 1));
	button(B_UPD_GO, Rect2(r.position.x + 40 * u, r.position.y + 270 * u, pw - 80 * u, 100 * u), "تحديث الآن", Color(0.15f, 0.65f, 0.3f), 44);
	if (!updForce) button(B_UPD_LATER, Rect2(r.position.x + 40 * u, r.position.y + 390 * u, pw - 80 * u, 90 * u), "لاحقاً", Color(0.35f, 0.38f, 0.5f), 36);
}

// ------------------------------------------------------------------ online
static bool serverUrlSet() { return std::string(NJ_SERVER_URL).find("YOUR-SUBDOMAIN") == std::string::npos; }
static const size_t NET_CODE_LEN = 5;

void NujoomGame::netConnect(const std::string &code) {
	netClose();
	netCode = code;
	peerHello = false;
	peerLeft = false;
	if (!serverUrlSet()) {
		netState = NS_IDLE;
		netMsg = "لم يتم ضبط رابط السيرفر في net_config.hpp";
		return;
	}
	ws.instantiate();
	ws->set_inbound_buffer_size(1 << 18);
	ws->set_outbound_buffer_size(1 << 18);
	String url = S(std::string(NJ_SERVER_URL) + "/ws?room=" + code);
	Error e = ws->connect_to_url(url);
	if (e != OK) {
		ws.unref();
		netState = NS_IDLE;
		netMsg = "تعذر الاتصال بالسيرفر";
		return;
	}
	netState = NS_CONNECTING;
	netConnT = 0;
	netMsg = "جاري الاتصال...";
}

void NujoomGame::netClose() {
	if (ws.is_valid()) {
		ws->close();
		ws.unref();
	}
	netOpen = false;
	netPlayers = 0;
	netYou = -1;
}

void NujoomGame::netPoll(float dt) {
	if (ws.is_null()) return;
	ws->poll();
	WebSocketPeer::State st = ws->get_ready_state();
	if (st == WebSocketPeer::STATE_OPEN) {
		netOpen = true;
		while (ws.is_valid() && ws->get_available_packet_count() > 0) {
			PackedByteArray pk = ws->get_packet();
			if (ws->was_string_packet()) {
				netHandle(pk.get_string_from_utf8());
			} else if (run && run->remote && screen == SC_PLAY && pk.size() > 0) {
				run->readSnapshot(pk.ptr(), (size_t)pk.size());
			}
		}
	} else if (st == WebSocketPeer::STATE_CLOSED) {
		bool was = netOpen;
		netOpen = false;
		ws.unref();
		if (screen == SC_PLAY) {
			addToast("انقطع الاتصال");
			peerLeft = true;
			if (run && !run->over) {
				if (run->remote) run->over = true;   // guest: the host is gone, end the match
				else run->forfeit(1);
			}
		} else if (screen == SC_OVER) {
			peerLeft = true;
		} else {
			netState = NS_IDLE;
			netMsg = was ? "انقطع الاتصال" : "تعذر الاتصال (تأكد من الإنترنت ورابط السيرفر)";
		}
	} else if (st == WebSocketPeer::STATE_CONNECTING) {
		netConnT += dt;
		if (netConnT > 12.0f) {
			netClose();
			netState = NS_IDLE;
			netMsg = "انتهت مهلة الاتصال";
		}
	}
}

void NujoomGame::netHandle(const String &msg) {
	Variant v = JSON::parse_string(msg);
	if (v.get_type() != Variant::DICTIONARY) return;
	Dictionary d = v;
	String t = d.get("t", "");
	if (t == String("welcome")) {
		netYou = (int)d.get("you", 0);
		netPlayers = (int)d.get("players", 1);
		netState = NS_ROOM;
		netMsg.clear();
		helloT = 0;
		if (netYou == 1) sendHello();
	} else if (t == String("peer_join")) {
		netPlayers = (int)d.get("players", 2);
		peerHello = false;
		if (netYou == 0) {   // tell the newcomer which mode is selected
			Dictionary m;
			m["t"] = "mode";
			m["m"] = (int)netMode;
			netSend(m);
		}
	} else if (t == String("peer_left")) {
		netPlayers = 1;
		peerHello = false;
		if (screen == SC_LOBBY) {
			// stay in the room, wait for someone else
		} else if (screen == SC_PLAY && run && !run->over) {
			peerLeft = true;
			addToast("الصديق غادر");
			if (run->remote) run->over = true;
			else run->forfeit(1);
		} else {
			peerLeft = true;
		}
	} else if (t == String("hello")) {
		if (netYou == 0) {
			peerPilot = (int)d.get("pilot", 0);
			Array a = d.get("store", Array());
			for (int i = 0; i < nj::N_STORE; i++) peerStore[i] = i < a.size() ? (int)a[i] : 0;
			peerHello = true;
		}
	} else if (t == String("mode")) {
		if (netYou == 1) {
			int m = (int)d.get("m", 1);
			netMode = m == 2 ? nj::GM_PVP : nj::GM_COOP;
		}
	} else if (t == String("start")) {
		if (netYou == 1 && screen == SC_LOBBY) {
			int m = (int)d.get("m", 1);
			netMode = m == 2 ? nj::GM_PVP : nj::GM_COOP;
			hostPilot = (int)d.get("p0", 0);
			startRun(true, (uint64_t)(int64_t)d.get("seed", 1));
		}
	} else if (t == String("in")) {
		if (netYou == 0) {
			float x = (float)d.get("x", 0.0), y = (float)d.get("y", 0.0);
			float l = std::sqrt(x * x + y * y);
			if (l > 1.0f) { x /= l; y /= l; }
			peerMove = nj::V2(x, y);
			peerMoveT = 0;
		}
	} else if (t == String("ch")) {
		if (netYou == 0 && run && !run->remote) run->choose(1, (int)d.get("i", 0));
	} else if (t == String("quit")) {
		if (netYou == 0 && run && !run->remote) run->retreat(1);
	}
}

void NujoomGame::netSend(const Dictionary &d) {
	if (ws.is_null() || !netOpen) return;
	ws->send_text(JSON::stringify(d));
}

void NujoomGame::netSendBin(const std::vector<uint8_t> &v) {
	if (ws.is_null() || !netOpen || v.empty()) return;
	PackedByteArray pk;
	pk.resize((int64_t)v.size());
	std::memcpy(pk.ptrw(), v.data(), v.size());
	ws->send(pk, WebSocketPeer::WRITE_MODE_BINARY);
}

void NujoomGame::sendHello() {
	Dictionary d;
	d["t"] = "hello";
	d["pilot"] = prof.pilot;
	Array a;
	for (int i = 0; i < nj::N_STORE; i++) a.push_back(prof.storeLevel[i]);
	d["store"] = a;
	netSend(d);
}

void NujoomGame::_process(double delta) {
	if (Engine::get_singleton()->is_editor_hint()) return;
	clock += (float)delta;
	fbTick((float)delta);
	if (storeMsgT > 0) storeMsgT -= (float)delta;
	if (storeFade < 1.0f) storeFade = std::min(1.0f, storeFade + (float)delta * 1.4f);
	if (storeSpark > 0.0f) storeSpark = std::max(0.0f, storeSpark - (float)delta * 1.1f);
	for (auto &t : toasts) t.t -= (float)delta;
	toasts.erase(std::remove_if(toasts.begin(), toasts.end(), [](const Toast &t) { return t.t <= 0; }), toasts.end());

	if (spinning) {
		spinT -= (float)delta;
		for (int i = 0; i < 3; i++)
			if (spinT > 0.4f * (float)(2 - i) ) reels[i] = (int)(clock * 14.0f + i * 2) % 6;
			else reels[i] = finalReels[i];
		if (spinT <= 0) {
			spinning = false;
			for (int i = 0; i < 3; i++) reels[i] = finalReels[i];
			if (spinPayout > 0) {
				prof.yen += spinPayout;
				casinoMsg = (spinPayout >= 10000 ? "الجائزة الكبرى! +" : "ربحت +") + commas(spinPayout) + " د.ع";
				playSfx(spinPayout >= 10000 ? "sfx_slot_jackpot" : "sfx_slot_win");
				if (spinPayout >= 10000) prof.jackpotWon = true;
			} else {
				casinoMsg = "حظ أوفر في المرة القادمة";
			}
			for (int i : prof.checkAchievements()) addToast(std::string("إنجاز جديد: ") + nj::ACHS[i].titleAr);
			for (int i : prof.refreshPilots()) { addToast(std::string("انضم طيار جديد: ") + nj::PILOTS[i].callsign); playSfx("sfx_pilot_recruit"); }
			saveProfile();
		}
	}

	if (chooseHideT > 0) chooseHideT -= (float)delta;
	if (screen == SC_LOBBY && netState == NS_ROOM && netYou == 1 && netOpen) {
		helloT -= (float)delta;
		if (helloT <= 0) { helloT = 1.5f; sendHello(); }   // the host needs our pilot + store levels
	}
	netPoll((float)delta);
	if (screen == SC_PLAY && run) {
		if (run->bossAnnounce > 0 || run->boss.active) playMusic("boss");
		else playMusic("combat");
		if (run->remote) {
			// guest: smooth between snapshots, send our stick 30 times a second
			run->extrapolate(std::min((float)delta, 0.1f));
			inSendT -= (float)delta;
			if (inSendT <= 0) {
				inSendT = 0.025f;
				Dictionary d;
				d["t"] = "in";
				d["x"] = std::round(joyVec.x * 100.0f) / 100.0;
				d["y"] = std::round(joyVec.y * 100.0f) / 100.0;
				netSend(d);
			}
		} else if ((!paused || duel) && !run->over) {
			// pause never stops a shared match
			if (!duel) run->setView(W / (u * 0.85f), H / (u * 0.85f));
			run->setMove(0, nj::V2(joyVec.x, joyVec.y));
			if (duel) {
				peerMoveT += (float)delta;
				run->setMove(1, peerMoveT < 1.0f ? peerMove : nj::V2());
			}
			float dt = std::min((float)delta, 0.1f);
			while (dt > 0 && !run->over) {
				float s = std::min(dt, 1.0f / 60.0f);
				run->update(s);
				dt -= s;
			}
			if (duel && netOpen) {
				snapT -= (float)delta;
				if (snapT <= 0 || run->over) {
					snapT = 0.025f;
					run->writeSnapshot(snapBuf);
					netSendBin(snapBuf);
				}
			}
		}
		int played = 0;
		for (int id : run->sfx)
			if (played++ < 8) playSfxId(id);
		run->sfx.clear();
		for (auto &s : run->toasts) addToast(s);
		run->toasts.clear();
		if (run->over) endRun();
	}
	queue_redraw();
}

// ------------------------------------------------------------------ input
int NujoomGame::btnAt(Vector2 p) const {
	for (int i = (int)btns.size() - 1; i >= 0; i--)
		if (btns[i].r.has_point(p)) return btns[i].id;
	return -1;
}

void NujoomGame::_input(const Ref<InputEvent> &event) {
	if (Engine::get_singleton()->is_editor_hint()) return;
	Ref<InputEventScreenTouch> st = event;
	if (st.is_valid()) {
		Vector2 pos = st->get_position();
		int idx = st->get_index();
		if (st->is_pressed()) {
			int b = btnAt(pos);
			if (b >= 0) {
				if (b == B_ABILITY && screen == SC_PLAY) {   // الميزة تشتغل لحظة اللمس (أسرع بالقتال)
					onButton(b);
					return;
				}
				pressBtn = b;
				return;
			}
			if (screen == SC_PLAY && run && !paused && !run->pl[me()].choosing && joyId < 0) {
				joyId = idx;
				joyCenter = pos;
				joyPos = pos;
				joyVec = Vector2();
			}
		} else {
			if (idx == joyId) {
				joyId = -1;
				joyVec = Vector2();
			}
			if (pressBtn >= 0) {
				int b = btnAt(pos);
				int pb = pressBtn;
				pressBtn = -1;
				if (b == pb) onButton(b);
			}
		}
		return;
	}
	Ref<InputEventScreenDrag> sd = event;
	if (sd.is_valid()) {
		if (sd->get_index() == joyId) {
			joyPos = sd->get_position();
			Vector2 d = joyPos - joyCenter;
			float R = 70.0f * u;
			if (d.length() > R) {
				joyCenter = joyPos - d.normalized() * R; // floating stick follows the finger
				d = joyPos - joyCenter;
			}
			joyVec = d / R;
		}
	}
}

void NujoomGame::onButton(int id) {
	playSfx("sfx_ui_tap", 0.05);
	if (id >= B_CHOOSE && id < B_CHOOSE + 8) {
		if (run) {
			int k = id - B_CHOOSE;
			if (run->remote) {
				Dictionary d;
				d["t"] = "ch";
				d["i"] = k;
				netSend(d);
				run->pl[me()].choosing = false;
				run->pl[me()].options.clear();
				chooseHideT = 0.5f;
			} else run->choose(me(), k);
		}
		return;
	}
	if (id == B_NAME_OK) { confirmName(); return; }
	if (id == B_NAME_CANCEL) { nameAsk = false; return; }
	if (id == B_NAME_EDIT) { openNameAsk(); return; }
	if (id == B_ABILITY) {   // ميزة الطائرة (زر داخل اللعبة)
		if (run && !run->remote && !paused) run->useAbility(me());
		return;
	}
	if (id >= B_STORE_TAB && id < B_STORE_TAB + 3) {
		storeTab = id - B_STORE_TAB;
		return;
	}
	if (id >= B_PLANE_CARD && id < B_PLANE_CARD + nj::N_PLANE) {   // اختيار طائرة للمعاينة
		planeView = id - B_PLANE_CARD;
		return;
	}
	if (id == B_PLANE_ACT) {   // شراء / اختيار / إلغاء اختيار الطائرة المعروضة
		int k = planeView;
		if (k < 0 || k >= nj::N_PLANE) return;
		if (prof.planeSel == k) {
			prof.selectPlane(-1);
			storeMsg = "رجعت للطيارة الأساسية";
		} else if (prof.planeOwned[k]) {
			prof.selectPlane(k);
			storeMsg = "تم اختيار الطائرة ✔";
		} else if (prof.buyPlane(k)) {
			playSfx("sfx_ui_purchase");
			prof.selectPlane(k);
			storeMsg = "تم شراء الطائرة واختيارها ✔";
		} else storeMsg = "رصيدك لا يكفي";
		storeMsgT = 2.0f;
		saveProfile();
		return;
	}
	if (id == B_STORE_RESET) {   // وضع التجربة: يرجّع القطع للصفر والرصيد لمليار
		prof.resetParts();
		prof.yen = std::max(prof.yen, TEST_YEN);
		storeMsg = "رجعنا من الصفر — جرّب القطع من جديد";
		storeMsgT = 2.5f;
		saveProfile();
		return;
	}
	if (id >= B_STORE_TILE && id < B_STORE_TILE + nj::N_STORE) {
		int k = id - B_STORE_TILE;
		bool part = k >= nj::N_STAT;
		if (part && prof.storeLevel[k] > 0) storeMsg = "مركّبة على الطيارة بالفعل";
		else if (part && !prof.partUnlocked(k - nj::N_STAT)) storeMsg = "لازم تشتري القطعة اللي قبلها أول";
		else if (prof.storeCost(k) < 0) storeMsg = "وصلت للحد الأقصى";
		else if (prof.buy(k)) {
			playSfx("sfx_ui_purchase");
			if (part) {
				storeMsg = "تم التركيب على الطيارة ✔";
				storeSparkPart = k - nj::N_STAT;
				storeSpark = 1.0f;
				storeTab = 0;
			} else storeMsg = "تم الشراء";
			saveProfile();
		} else storeMsg = "رصيدك لا يكفي";
		storeMsgT = 2.0f;
		return;
	}
	if (id >= B_LOOK_COLOR && id < B_LOOK_COLOR + nj::N_SHIP_COLOR) {
		int k = id - B_LOOK_COLOR;
		if (prof.colorOwned[k]) {
			prof.shipColor = k;
			storeMsg = "تم التفعيل";
			saveProfile();
		} else if (prof.buyColor(k)) {
			playSfx("sfx_ui_purchase");
			prof.shipColor = k;
			storeMsg = "تم الشراء";
			saveProfile();
		} else storeMsg = "رصيدك لا يكفي";
		storeMsgT = 2.0f;
		return;
	}
	if (id >= B_LOOK_FIELD && id < B_LOOK_FIELD + nj::N_FIELD) {
		int k = id - B_LOOK_FIELD;
		if (prof.fieldOwned[k]) {
			prof.fieldTheme = k;
			storeMsg = "تم التفعيل";
			saveProfile();
		} else if (prof.buyField(k)) {
			playSfx("sfx_ui_purchase");
			prof.fieldTheme = k;
			storeMsg = "تم الشراء";
			saveProfile();
		} else storeMsg = "رصيدك لا يكفي";
		storeMsgT = 2.0f;
		return;
	}
	if (id >= B_CREW_TILE && id < B_CREW_TILE + nj::N_PILOT) {
		int k = id - B_CREW_TILE;
		crewFocus = k;
		if (prof.pilotUnlocked[k]) {
			prof.pilot = k;
			saveProfile();
		}
		return;
	}
	if (id >= B_NET_DIGIT && id < B_NET_DIGIT + 10) {
		if (netInput.size() < NET_CODE_LEN) netInput += (char)('0' + (id - B_NET_DIGIT));
		return;
	}
	switch (id) {
		case B_ONLINE: goTo(SC_LOBBY); break;
		case B_NET_CREATE: {
			int n = (int)(Time::get_singleton()->get_ticks_usec() % 90000ULL) + 10000;
			netConnect(std::to_string(n));
			break;
		}
		case B_NET_JOIN:
			netState = NS_JOIN_INPUT;
			netInput.clear();
			netMsg.clear();
			break;
		case B_NET_DEL:
			if (!netInput.empty()) netInput.pop_back();
			break;
		case B_NET_GO:
			if (netInput.size() == NET_CODE_LEN) netConnect(netInput);
			else netMsg = "اكتب رمز من 5 أرقام";
			break;
		case B_NET_COOP:
		case B_NET_PVP:
			if (netState == NS_ROOM && netYou == 0) {
				netMode = id == B_NET_PVP ? nj::GM_PVP : nj::GM_COOP;
				Dictionary d;
				d["t"] = "mode";
				d["m"] = (int)netMode;
				netSend(d);
			}
			break;
		case B_NET_START:
			if (netState == NS_ROOM && netYou == 0 && netPlayers >= 2 && netOpen && peerHello) {
				uint64_t seed = Time::get_singleton()->get_ticks_usec() % 2147483647ULL;
				Dictionary d;
				d["t"] = "start";
				d["seed"] = (int64_t)seed;
				d["m"] = (int)netMode;
				d["p0"] = prof.pilot;
				netSend(d);
				startRun(true, seed);
			}
			break;
		case B_LAUNCH: startRun(); break;
		case B_CREW: goTo(SC_CREW); break;
		case B_STORE: goTo(SC_STORE); break;
		case B_CASINO: goTo(SC_CASINO); break;
		case B_ACH: goTo(SC_ACH); break;
		case B_LOOK: goTo(SC_LOOK); break;
		case B_BOARD: goTo(SC_BOARD); break;
		case B_UPD_GO:
			if (!updUrl.empty()) OS::get_singleton()->shell_open(S(updUrl));
			break;
		case B_UPD_LATER:
			if (!updForce) updShow = false;
			break;
		case B_BACK:
			if (screen == SC_LOBBY && netState != NS_IDLE) {
				netClose();
				netState = NS_IDLE;
				netMsg.clear();
			} else goTo(SC_MENU);
			break;
		case B_PAUSE: paused = true; break;
		case B_RESUME: paused = false; break;
		case B_RETREAT:
			if (run) {
				paused = false;
				if (run->remote) {
					Dictionary d;
					d["t"] = "quit";
					netSend(d);
				} else run->retreat(me());
			}
			break;
		case B_OVER_OK: goTo(SC_MENU); break;
		case B_SPIN: startSpin(); break;
	}
}

void NujoomGame::startSpin() {
	if (spinning) return;
	if (prof.yen < 100) { casinoMsg = "تحتاج 100 د.ع"; return; }
	prof.yen -= 100;
	prof.casinoSpins++;
	nj::Rng r(Time::get_singleton()->get_ticks_usec());
	// symbols: 0 bolt 1 diamond 2 gear 3 rocket 4 star 5 yen
	float f = r.f();
	int win = -1;
	spinPayout = 0;
	if (f < 0.005f) { win = 3; spinPayout = 10000; }
	else if (f < 0.025f) { win = 1; spinPayout = 750; }
	else if (f < 0.085f) { win = 4; spinPayout = 300; }
	else if (f < 0.145f) { win = 5; spinPayout = 100; }
	else if (f < 0.225f) { win = 0; spinPayout = 50; }
	else if (f < 0.325f) { win = 2; spinPayout = 20; }
	if (win >= 0) {
		for (int i = 0; i < 3; i++) finalReels[i] = win;
	} else {
		do {
			for (int i = 0; i < 3; i++) finalReels[i] = r.i(6);
		} while (finalReels[0] == finalReels[1] && finalReels[1] == finalReels[2]);
	}
	spinning = true;
	spinT = 1.6f;
	casinoMsg = "";
	playSfx("sfx_slot_spin");
}

// ------------------------------------------------------------------ draw helpers
void NujoomGame::text(const std::string &s, float x, float y, float size, Color c, int align, bool shadow) {
	Ref<Font> f = hasArabic(s) ? fontAr : fontLat;
	if (f.is_null()) return;
	int fs = (int)std::round(size);
	String str = S(s);
	float w = f->get_string_size(str, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x;
	float px = align == 1 ? x - w * 0.5f : (align == 2 ? x - w : x);
	if (shadow) draw_string(f, Vector2(px + 2, y + 2), str, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0, 0, 0, 0.6f * c.a));
	draw_string(f, Vector2(px, y), str, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, c);
}

void NujoomGame::panel(Rect2 r, Color fill, Color line) {
	draw_rect(r, fill, true);
	draw_rect(r, line, false, 2.0f * u);
}

void NujoomGame::button(int id, Rect2 r, const std::string &label, Color col, float fs) {
	btns.push_back({id, r});
	bool down = pressBtn == id;
	Color fill = col;
	fill.a = down ? 0.95f : 0.75f;
	draw_rect(r, Color(0, 0, 0, 0.45f), true);
	draw_rect(r.grow(-2.0f * u), fill, true);
	draw_rect(r, Color(1, 1, 1, 0.55f), false, 2.0f * u);
	text(label, r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.5f + fs * u * 0.34f, fs * u, Color(1, 1, 1, 1));
}

void NujoomGame::bar(Rect2 r, float frac, Color fill, Color back) {
	draw_rect(r, back, true);
	frac = std::max(0.0f, std::min(1.0f, frac));
	if (frac > 0) draw_rect(Rect2(r.position, Vector2(r.size.x * frac, r.size.y)), fill, true);
	draw_rect(r, Color(1, 1, 1, 0.35f), false, 1.5f);
}

void NujoomGame::icon(const std::string &path, Rect2 r, Color mod) {
	Ref<Texture2D> t = tex(path);
	if (t.is_valid()) draw_texture_rect(t, r, false, mod);
}

void NujoomGame::polyFill(const std::vector<Vector2> &pts, Color fill, Color line, float lw) {
	PackedVector2Array a;
	for (auto &p : pts) a.push_back(p);
	if (fill.a > 0 && pts.size() >= 3) draw_colored_polygon(a, fill);
	if (line.a > 0) {
		a.push_back(pts[0]);
		draw_polyline(a, line, lw);
	}
}

void NujoomGame::glow(Vector2 c, float r, Color col) {
	for (int i = 3; i >= 1; i--) {
		Color k = col;
		k.a = col.a * 0.18f;
		draw_circle(c, r * (0.45f + 0.28f * (float)i), k);
	}
	draw_circle(c, r * 0.4f, col);
}

void NujoomGame::drawBackground(Vector2 cam, float scale) {
	const nj::FieldDef &fth = nj::FIELD_THEMES[prof.fieldTheme];
	draw_rect(Rect2(0, 0, W, H), Cc(fth.bg), true);
	if (prof.fieldTheme > 0) {   // سديم ملوّن خفيف يتحرك ببطء
		float tt = clock * 0.05f;
		draw_circle(Vector2(W * (0.25f + 0.1f * std::sin(tt)), H * 0.3f), W * 0.75f, Cc(fth.glow, 0.07f));
		draw_circle(Vector2(W * 0.8f, H * (0.75f + 0.05f * std::cos(tt))), W * 0.6f, Cc(fth.glow, 0.06f));
	}
	static const float par[3] = {0.12f, 0.3f, 0.6f};
	static const float sz[3] = {1.2f, 1.8f, 2.6f};
	static const float al[3] = {0.35f, 0.55f, 0.85f};
	for (int l = 0; l < 3; l++)
		for (const Vector2 &s : stars[l]) {
			float x = std::fmod(s.x * W - cam.x * scale * par[l], W);
			float y = std::fmod(s.y * H - cam.y * scale * par[l], H);
			if (x < 0) x += W;
			if (y < 0) y += H;
			{
				Color stc = Cc(fth.star);
				stc.a = al[l];
				draw_circle(Vector2(x, y), sz[l] * u, stc);
			}
		}
}

void NujoomGame::drawHeader(const std::string &title) {
	button(B_BACK, Rect2(14 * u, 14 * u, 170 * u, 76 * u), "رجوع", Color(0.25f, 0.3f, 0.5f), 32);
	text(title, W * 0.5f, 68 * u, 44 * u, Color(1, 0.85f, 0.3f));
	text(nj::formatYen(prof.yen), W - 18 * u, 68 * u, 34 * u, Color(1, 0.9f, 0.4f), 2);
}

// ------------------------------------------------------------------ main draw
void NujoomGame::_draw() {
	if (Engine::get_singleton()->is_editor_hint()) return;
	Vector2 vs = get_viewport_rect().size;
	W = vs.x;
	H = vs.y;
	u = std::min(W, H) / 960.0f;
	btns.clear();

	if (screen == SC_PLAY && run) {
		drawWorld();
		drawHud();
		if (run->pl[me()].choosing && chooseHideT <= 0) drawChoose();
		else if (paused) drawPause();
		drawToasts();
		return;
	}
	drawBackground(Vector2(clock * 20.0f, clock * 35.0f), 1.0f);
	switch (screen) {
		case SC_MENU: drawMenu(); break;
		case SC_CREW: drawCrew(); break;
		case SC_STORE: drawStore(); break;
		case SC_CASINO: drawCasino(); break;
		case SC_ACH: drawAch(); break;
		case SC_OVER: drawOver(); break;
		case SC_LOBBY: drawLobby(); break;
		case SC_LOOK: drawLook(); break;
		case SC_BOARD: drawBoard(); break;
		default: break;
	}
	drawToasts();
	drawName();
	drawUpdate();
}

void NujoomGame::drawToasts() {
	float y = (screen == SC_PLAY ? 230.0f : 150.0f) * u;
	for (auto &t : toasts) {
		float a = std::min(1.0f, t.t);
		float w = 640.0f * u;
		Rect2 r(W * 0.5f - w * 0.5f, y, w, 64 * u);
		draw_rect(r, Color(0, 0, 0, 0.65f * a), true);
		draw_rect(r, Color(1, 0.85f, 0.3f, a), false, 2.0f * u);
		text(t.s, W * 0.5f, y + 43 * u, 30 * u, Color(1, 0.95f, 0.7f, a));
		y += 74 * u;
	}
}

// ------------------------------------------------------------------ menu
void NujoomGame::drawMenu() {
	bool land = W > H * 1.05f;
	float cx = land ? W * 0.27f : W * 0.5f;
	text("نجوم العراق", cx, (land ? 0.2f : 0.11f) * H, 84 * u, Color(1, 0.85f, 0.3f));
	text("ASTRO LOOP", cx, (land ? 0.2f : 0.11f) * H + 46 * u, 28 * u, Color(0.7f, 0.85f, 1.0f));
	text(nj::formatYen(prof.yen), cx, (land ? 0.3f : 0.185f) * H, 40 * u, Color(1, 0.9f, 0.4f));

	const nj::PilotDef &pd = nj::PILOTS[prof.pilot];
	float ps = (land ? 0.34f * H : 0.2f * H);
	ps = std::min(ps, 360.0f * u);
	float py = (land ? 0.36f * H : 0.215f * H);
	draw_circle(Vector2(cx, py + ps * 0.5f), ps * 0.58f, Cc(pd.col, 0.18f));
	icon(std::string("res://assets/icons/portraits/portrait_") + (pd.id + 6) + ".png", Rect2(cx - ps * 0.5f, py, ps, ps));
	text(pd.callsign, cx, py + ps + 40 * u, 40 * u, Cc(pd.col));
	text(std::string(pd.type) + " | " + nj::PASSIVES[pd.passive].name, cx, py + ps + 76 * u, 24 * u, Color(0.8f, 0.85f, 0.95f));

	float bx = land ? W * 0.56f : W * 0.5f - 300 * u;
	float bw = land ? W * 0.38f : 600 * u;
	float by = land ? 0.14f * H : py + ps + 120 * u;
	float bh = 96 * u, gap = 22 * u;
	if (land) { bh = std::min(bh, (H * 0.74f - 6 * gap) / 7.0f); }
	button(B_LAUNCH, Rect2(bx, by, bw, bh * 1.2f), "الإطلاق", Color(0.15f, 0.65f, 0.3f), 48);
	by += bh * 1.2f + gap;
	button(B_ONLINE, Rect2(bx, by, bw, bh), "العب مع صديق", Color(0.1f, 0.55f, 0.65f), 38);
	by += bh + gap;
	button(B_CREW, Rect2(bx, by, bw, bh), "الطاقم", Color(0.25f, 0.35f, 0.7f), 38);
	by += bh + gap;
	button(B_STORE, Rect2(bx, by, bw, bh), "المتجر", Color(0.6f, 0.4f, 0.15f), 38);
	by += bh + gap;
	button(B_LOOK, Rect2(bx, by, bw, bh), "المظهر", Color(0.2f, 0.5f, 0.35f), 38);
	by += bh + gap;
	button(B_CASINO, Rect2(bx, by, bw, bh), "السوق السوداء", Color(0.55f, 0.2f, 0.5f), 38);
	by += bh + gap;
	button(B_ACH, Rect2(bx, by, bw * 0.5f - gap * 0.5f, bh), "الإنجازات", Color(0.3f, 0.5f, 0.5f), 32);
	button(B_BOARD, Rect2(bx + bw * 0.5f + gap * 0.5f, by, bw * 0.5f - gap * 0.5f, bh), "المتصدرون", Color(0.7f, 0.5f, 0.1f), 32);
	text("C++ / Godot", W * 0.5f, H - 20 * u, 20 * u, Color(1, 1, 1, 0.35f), 1, false);
}

void NujoomGame::drawCrew() {
	drawHeader("الطاقم");
	int cols = W > H ? 6 : 3, rows = (nj::N_PILOT + cols - 1) / cols;
	float top = 120 * u, bottomPanel = 250 * u;
	float availH = H - top - bottomPanel - 20 * u, availW = W - 40 * u;
	float cell = std::min(availW / (float)cols, availH / (float)rows);
	float gx = (W - cell * cols) * 0.5f;
	for (int i = 0; i < nj::N_PILOT; i++) {
		int cx = i % cols, cy = i / cols;
		Rect2 r(gx + cell * (float)cx + 6 * u, top + cell * (float)cy + 6 * u, cell - 12 * u, cell - 12 * u);
		bool unl = prof.pilotUnlocked[i];
		const nj::PilotDef &pd = nj::PILOTS[i];
		btns.push_back({B_CREW_TILE + i, r});
		Color border = i == prof.pilot ? Color(0.3f, 1, 0.4f) : (i == crewFocus ? Color(1, 0.85f, 0.3f) : Color(1, 1, 1, 0.3f));
		draw_rect(r, Color(0, 0, 0, 0.5f), true);
		draw_rect(r, border, false, 3 * u);
		float ps = r.size.x * 0.82f;
		std::string path = unl ? std::string("res://assets/icons/portraits/portrait_") + (pd.id + 6) + ".png" : "res://assets/icons/portraits/portrait_locked.png";
		icon(path, Rect2(r.position.x + (r.size.x - ps) * 0.5f, r.position.y + 4 * u, ps, ps));
		text(unl ? pd.callsign : "؟؟؟", r.position.x + r.size.x * 0.5f, r.position.y + r.size.y - 10 * u, std::min(26.0f * u, r.size.x * 0.16f), unl ? Cc(pd.col) : Color(0.6f, 0.6f, 0.6f));
	}
	// details panel
	Rect2 dp(20 * u, H - bottomPanel, W - 40 * u, bottomPanel - 20 * u);
	panel(dp, Color(0, 0, 0, 0.55f), Color(1, 1, 1, 0.3f));
	const nj::PilotDef &fd = nj::PILOTS[crewFocus];
	bool unl = prof.pilotUnlocked[crewFocus];
	text(unl ? fd.callsign : "مقفل", W * 0.5f, dp.position.y + 48 * u, 38 * u, unl ? Cc(fd.col) : Color(0.7f, 0.7f, 0.7f));
	if (unl) {
		icon(passiveIcon(fd.passive), Rect2(dp.position.x + 20 * u, dp.position.y + 70 * u, 96 * u, 96 * u));
		text(nj::PASSIVES[fd.passive].name, dp.position.x + 130 * u, dp.position.y + 108 * u, 30 * u, Color(1, 1, 1), 0);
		text(nj::PASSIVES[fd.passive].desc, dp.position.x + 130 * u, dp.position.y + 148 * u, 24 * u, Color(0.8f, 0.85f, 0.95f), 0);
		text(crewFocus == prof.pilot ? "الطيار المختار" : "اضغط للاختيار", W * 0.5f, dp.position.y + dp.size.y - 18 * u, 26 * u, Color(0.4f, 1, 0.5f));
	} else {
		text(prof.pilotHintAr(crewFocus), W * 0.5f, dp.position.y + 120 * u, 34 * u, Color(1, 0.85f, 0.4f));
	}
}

// ------------------------------------------------------------------ المتجر (واجهة ثلاثية الأبعاد)
static std::string shipTexPath(int img) {
	return img <= 0 ? std::string("res://assets/ship/ship_delta.png") : std::string("res://assets/ship/stage_") + std::to_string(img) + ".png";
}

// صورة الطائرة حسب المرحلة. صور المراحل مرسومة على لوحة 640 (بدل 512) فيرجع k = 1.25 للتعويض.
Ref<Texture2D> NujoomGame::shipTexFor(int img, float *k) {
	if (img > 0) {
		Ref<Texture2D> t = tex(shipTexPath(img));
		if (t.is_valid()) {
			*k = 1.25f;
			return t;
		}
	}
	*k = 1.0f;
	return tex(shipTexPath(0));
}

static const nj::PartDef *gunPart(int gun) {
	for (int p = 0; p < nj::N_PART; p++)
		if (nj::PARTS[p].kind == nj::PT_GUN && nj::PARTS[p].gun == gun) return &nj::PARTS[p];
	return nullptr;
}

// مكان القطعة على الطائرة بوحدات نصف قطر الطائرة (x للأمام، y لليمين)
static Vector2 partAnchor(int p) {
	const nj::PartDef &pd = nj::PARTS[p];
	if (pd.kind == nj::PT_ENGINE || pd.kind == nj::PT_ENGINE_BOOST) return Vector2(-1.9f, 0.0f);
	const nj::PartDef *g = gunPart(pd.gun);
	return g ? Vector2(g->mx, g->my) : Vector2(0.0f, 0.0f);
}

// بطاقة بسماكة وظل (تنضغط لتحت إذا انضغطت). ترجع وجه البطاقة لرسم المحتوى عليه.
Rect2 NujoomGame::card3d(int id, Rect2 r, Color fill, Color edge) {
	if (id >= 0) btns.push_back({id, r});
	bool down = id >= 0 && pressBtn == id;
	float d = 8.0f * u;
	float sh = down ? d * 0.75f : 0.0f;
	Rect2 face(r.position.x, r.position.y + sh, r.size.x, r.size.y - d);
	draw_rect(Rect2(r.position.x + 5.0f * u, r.position.y + d + 5.0f * u, r.size.x, r.size.y - d), Color(0, 0, 0, 0.45f), true);
	draw_rect(Rect2(r.position.x, r.position.y + d, r.size.x, r.size.y - d), Color(edge.r * 0.35f, edge.g * 0.35f, edge.b * 0.35f, 1.0f), true);
	draw_rect(face, fill, true);
	draw_rect(Rect2(face.position.x, face.position.y, face.size.x, face.size.y * 0.38f), Color(1, 1, 1, 0.07f), true);
	draw_rect(face, edge, false, 2.5f * u);
	return face;
}

// نص يصغّر نفسه إذا أطول من المساحة
void NujoomGame::textFit(const std::string &s, float x, float y, float size, float maxW, Color c, int align) {
	Ref<Font> f = hasArabic(s) ? fontAr : fontLat;
	if (f.is_valid()) {
		float w = f->get_string_size(S(s), HORIZONTAL_ALIGNMENT_LEFT, -1, (int)std::round(size)).x;
		if (w > maxW && w > 1.0f) size *= maxW / w;
	}
	text(s, x, y, size, c, align);
}

// منصة استعراض: الطائرة تدور على منصة بسماكة وظل، والقطع المشتراة تظهر عليها وتطلق للأمام
void NujoomGame::drawShipShowcase(Rect2 a) {
	panel(a, Color(0.01f, 0.03f, 0.09f, 0.8f), Color(0.4f, 0.65f, 1.0f, 0.45f));
	Vector2 mid(a.position.x + a.size.x * 0.5f, a.position.y + a.size.y * 0.5f);
	glow(mid, a.size.y * 0.5f, Color(0.2f, 0.4f, 0.9f, 0.10f));
	float R = std::min(a.size.x * 0.46f, a.size.y * 0.62f);
	const float tilt = 0.62f;   // ميلان الكاميرا (1 = من فوق تماماً)
	Vector2 P(mid.x, a.position.y + a.size.y * 0.66f);   // مركز المنصة

	// المنصة (دوائر مسطّحة = منظور)
	draw_set_transform(P, 0, Vector2(1.0f, 0.3f));
	draw_circle(Vector2(0, 0), R, Color(0.02f, 0.05f, 0.12f, 0.85f));
	draw_arc(Vector2(0, 0), R, 0, nj::TAU, 72, Color(0.3f, 0.8f, 1, 0.8f), 4.0f * u);
	draw_arc(Vector2(0, 0), R * 0.72f, 0, nj::TAU, 64, Color(0.3f, 0.8f, 1, 0.35f), 2.5f * u);
	draw_arc(Vector2(0, 0), R * 0.42f, 0, nj::TAU, 48, Color(0.3f, 0.8f, 1, 0.25f), 2.0f * u);
	for (int k = 0; k < 16; k++) {
		float an = clock * 0.5f + (float)k * nj::TAU / 16.0f;
		draw_circle(Vector2(std::cos(an), std::sin(an)) * R * 0.88f, 3.5f * u, Color(0.5f, 0.9f, 1, 0.8f));
	}
	draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));

	// ظل تحت الطائرة
	float bob = std::sin(clock * 1.7f) * 7.0f * u;
	draw_set_transform(Vector2(P.x, P.y - R * 0.02f), 0, Vector2(1.0f, 0.3f));
	draw_circle(Vector2(0, 0), R * 0.5f, Color(0, 0, 0, 0.38f));
	draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));

	// الطائرة: طبقات مزاحة لتعطي سماكة، ومحاور مائلة لتعطي منظور
	float SZ = R * 1.5f;
	Vector2 shipC(P.x, P.y - R * 0.5f + bob);
	float yaw = std::sin(clock * 0.45f) * 0.6f;
	float psi = -nj::PI * 0.5f + yaw;
	float cp = std::cos(psi), sp = std::sin(psi);
	float pop = 1.0f + 0.10f * std::sin(storeFade * nj::PI);   // قفزة صغيرة وقت التركيب
	float kNew = 1.0f, kOld = 1.0f;
	Ref<Texture2D> tNew = shipTexFor(storeImg, &kNew), tOld = shipTexFor(storePrevImg, &kOld);
	Color tint = Cc(nj::SHIP_COLORS[prof.shipColor].argb);
	const int LAYERS = 7;
	for (int k = 0; k < LAYERS; k++) {
		float depth = (float)(LAYERS - 1 - k) * 2.4f * u;
		float shade = 0.28f + 0.72f * (float)k / (float)(LAYERS - 1);
		bool top = k == LAYERS - 1;
		Transform2D xf(Vector2(cp, sp * tilt) * pop, Vector2(-sp, cp * tilt) * pop, Vector2(shipC.x, shipC.y + depth));
		draw_set_transform_matrix(xf);
		Color m(tint.r * shade, tint.g * shade, tint.b * shade, 1.0f);
		if (top && storeFade < 1.0f && tOld.is_valid()) {
			float so = SZ * kOld;
			draw_texture_rect(tOld, Rect2(Vector2(-so * 0.5f, -so * 0.5f), Vector2(so, so)), false, m);
		}
		if (tNew.is_valid()) {
			float sn = SZ * kNew;
			Color mm = m;
			if (top && storeFade < 1.0f) mm.a = storeFade;
			draw_texture_rect(tNew, Rect2(Vector2(-sn * 0.5f, -sn * 0.5f), Vector2(sn, sn)), false, mm);
		}
	}
	draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));

	// تحويل مكان على الطائرة (وحدات نصف القطر) لمكان على الشاشة
	float unitPx = SZ / 5.4f * pop;
	auto proj = [&](float lx, float ly) {
		float qx = lx * unitPx, qy = ly * unitPx;
		return Vector2(shipC.x + qx * cp - qy * sp, shipC.y + (qx * sp + qy * cp) * tilt);
	};

	// طلقات المدافع المركّبة: كلها للأمام
	for (int g = 0; g < nj::N_GUN; g++) {
		if (!nj::gunOwned(prof.storeLevel, g)) continue;
		const nj::PartDef *gd = gunPart(g);
		if (!gd) continue;
		float rate = nj::gunRate(prof.storeLevel, g);
		for (int j = 0; j < 3; j++) {
			float ph = std::fmod(clock * 0.9f * rate + (float)j / 3.0f + (float)g * 0.21f, 1.0f);
			draw_circle(proj(gd->mx + ph * 7.0f, gd->my), 3.2f * u, Color(1, 0.9f, 0.4f, 1.0f - ph));
		}
		draw_circle(proj(gd->mx, gd->my), 5.0f * u, Color(1, 0.9f, 0.4f, 0.45f + 0.3f * std::sin(clock * 12.0f + (float)g)));
	}
	// وميض التركيب على القطعة اللي توّها انشترت
	if (storeSpark > 0 && storeSparkPart >= 0 && storeSparkPart < nj::N_PART) {
		Vector2 an = partAnchor(storeSparkPart);
		Vector2 q = proj(an.x, an.y);
		float k = 1.0f - storeSpark;
		draw_arc(q, (10.0f + 90.0f * k) * u, 0, nj::TAU, 40, Color(1, 0.9f, 0.4f, storeSpark), 4.0f * u);
		glow(q, 30.0f * u * storeSpark, Color(1, 0.8f, 0.3f, 0.6f * storeSpark));
	}

	// معلومات
	int owned = 0, guns = 0;
	for (int p = 0; p < nj::N_PART; p++) owned += prof.storeLevel[nj::N_STAT + p] > 0 ? 1 : 0;
	for (int g = 0; g < nj::N_GUN; g++) guns += nj::gunOwned(prof.storeLevel, g) ? 1 : 0;
	int spd = (int)std::lround((prof.storeValue(2) + nj::engineSpeedBonus(prof.storeLevel)) * 100.0f);
	text("القطع " + std::to_string(owned) + " / " + std::to_string(nj::N_PART), a.position.x + 18.0f * u, a.position.y + 38.0f * u, 30.0f * u, Color(1, 0.85f, 0.3f), 0);
	text("المدافع: " + std::to_string(guns) + "   |   السرعة +" + std::to_string(spd) + "%", mid.x, a.position.y + a.size.y - 18.0f * u, 28.0f * u, Color(0.8f, 0.9f, 1));
}

// بطاقات قطع الطائرة (تنشترى بالترتيب)
void NujoomGame::drawStoreParts(Rect2 area) {
	bool land = W > H;
	int cols = land ? 3 : 2, rows = (nj::N_PART + cols - 1) / cols;
	float cw = area.size.x / (float)cols, ch = area.size.y / (float)rows;
	for (int p = 0; p < nj::N_PART; p++) {
		int tile = nj::N_STAT + p;
		const nj::PartDef &pd = nj::PARTS[p];
		bool owned = prof.storeLevel[tile] > 0;
		bool unlocked = prof.partUnlocked(p);
		int cost = prof.storeCost(tile);
		bool afford = !owned && unlocked && cost > 0 && prof.yen >= cost;
		Color edge = owned ? Color(0.3f, 0.9f, 0.5f, 0.9f) : (!unlocked ? Color(0.5f, 0.5f, 0.6f, 0.6f) : (afford ? Color(0.4f, 1.0f, 0.5f, 0.9f) : Color(1.0f, 0.45f, 0.45f, 0.8f)));
		Color fill = owned ? Color(0.02f, 0.14f, 0.07f, 0.92f) : Color(0.02f, 0.03f, 0.07f, 0.92f);
		Rect2 r(area.position.x + cw * (float)(p % cols) + 6.0f * u, area.position.y + ch * (float)(p / cols) + 6.0f * u, cw - 12.0f * u, ch - 12.0f * u);
		Rect2 f = card3d(B_STORE_TILE + tile, r, fill, edge);

		// صورة مصغّرة للطائرة بعد هاي القطعة، ودائرة على مكانها
		float is = std::min(f.size.y - 14.0f * u, f.size.x * 0.32f);
		Vector2 tc(f.position.x + 10.0f * u + is * 0.5f, f.position.y + f.size.y * 0.5f);
		float kk = 1.0f;
		Ref<Texture2D> tt = shipTexFor(pd.image, &kk);
		if (tt.is_valid()) {
			Color mod = (owned || unlocked) ? Color(1, 1, 1, 1) : Color(0.35f, 0.35f, 0.42f, 1);
			float sz = is * kk;
			draw_set_transform(tc, -nj::PI * 0.5f, Vector2(1, 1));
			draw_texture_rect(tt, Rect2(Vector2(-sz * 0.5f, -sz * 0.5f), Vector2(sz, sz)), false, mod);
			draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));
		}
		bool boost = pd.kind == nj::PT_GUN_BOOST || pd.kind == nj::PT_ENGINE_BOOST;
		Vector2 an = partAnchor(p);
		float kpx = is / 5.4f;
		Vector2 ap = tc + Vector2(an.y * kpx, -an.x * kpx);
		float pulse = 0.6f + 0.4f * std::sin(clock * 5.0f);
		Color hc = boost ? Color(1.0f, 0.6f, 0.2f, pulse) : Color(0.4f, 1.0f, 0.6f, pulse);
		draw_arc(ap, 11.0f * u * (0.9f + 0.2f * pulse), 0, nj::TAU, 24, hc, 3.0f * u);
		if (boost) draw_arc(ap, 18.0f * u, 0, nj::TAU, 24, Color(hc.r, hc.g, hc.b, 0.4f), 2.0f * u);
		// رقم المرحلة
		draw_circle(Vector2(f.position.x + 20.0f * u, f.position.y + 20.0f * u), 15.0f * u, Color(0, 0, 0, 0.7f));
		text(std::to_string(p + 1), f.position.x + 20.0f * u, f.position.y + 20.0f * u + 8.0f * u, 22.0f * u, Color(1, 0.9f, 0.5f));

		float tx = f.position.x + 10.0f * u + is + 14.0f * u;
		float maxW = f.position.x + f.size.x - tx - 10.0f * u;
		textFit(pd.nameAr, tx, f.position.y + 38.0f * u, 28.0f * u, maxW, Color(1, 0.9f, 0.5f), 0);
		textFit(pd.effectAr, tx, f.position.y + 72.0f * u, 22.0f * u, maxW, Color(0.8f, 0.9f, 1), 0);
		std::string label;
		Color lc;
		if (owned) { label = "✔ مركّبة"; lc = Color(0.4f, 1, 0.5f); }
		else if (!unlocked) { label = "مقفول (اشترِ " + std::to_string(p) + " أول)"; lc = Color(0.6f, 0.6f, 0.7f); }
		else { label = commas(cost) + " د.ع"; lc = afford ? Color(0.4f, 1, 0.5f) : Color(1, 0.5f, 0.5f); }
		textFit(label, tx, f.position.y + f.size.y - 22.0f * u, 28.0f * u, maxW, lc, 0);
	}
}

// بطاقات الترقيات القديمة (الصحة، الدرع، السرعة...)
void NujoomGame::drawStoreStats(Rect2 area) {
	int cols = W > H ? 4 : 2, rows = (nj::N_STAT + cols - 1) / cols;
	float cw = area.size.x / (float)cols, ch = std::min(area.size.y / (float)rows, 330.0f * u);
	for (int i = 0; i < nj::N_STAT; i++) {
		int cx = i % cols, cy = i / cols;
		Rect2 r(area.position.x + cw * (float)cx + 6.0f * u, area.position.y + ch * (float)cy + 6.0f * u, cw - 12.0f * u, ch - 12.0f * u);
		const nj::StoreTile &st = nj::STORE[i];
		int lv = prof.storeLevel[i];
		int cost = prof.storeCost(i);
		bool afford = cost > 0 && prof.yen >= cost;
		Rect2 f = card3d(B_STORE_TILE + i, r, Color(0.02f, 0.03f, 0.07f, 0.92f), afford ? Color(0.4f, 1, 0.5f, 0.9f) : Color(1, 1, 1, 0.3f));
		float is = std::min(f.size.y * 0.42f, 120.0f * u);
		icon(std::string("res://assets/icons/store/icon_store_") + st.icon + ".png", Rect2(f.position.x + 12.0f * u, f.position.y + 12.0f * u, is, is));
		float tx = f.position.x + is + 26.0f * u;
		float fs = std::min(30.0f * u, ch * 0.11f);
		text(st.nameAr, tx, f.position.y + 12.0f * u + fs, fs, Color(1, 0.9f, 0.5f), 0);
		text(st.effectAr, tx, f.position.y + 12.0f * u + fs * 2.2f, fs * 0.72f, Color(0.8f, 0.9f, 1), 0);
		for (int k = 0; k < 5; k++) {
			float pr = std::min(11.0f * u, f.size.x * 0.03f);
			Vector2 c(tx + pr + (float)k * pr * 2.6f, f.position.y + 12.0f * u + fs * 3.3f);
			draw_circle(c, pr, k < lv ? Color(1, 0.85f, 0.2f) : Color(1, 1, 1, 0.2f));
		}
		std::string label = cost < 0 ? "الحد الأقصى" : commas(cost) + " د.ع";
		text(label, f.position.x + f.size.x * 0.5f, f.position.y + f.size.y - 18.0f * u, std::min(32.0f * u, ch * 0.12f), afford ? Color(0.4f, 1, 0.5f) : Color(1, 0.5f, 0.5f));
	}
}

// ------------------------------------------------------------------ قسم الطائرات (10 طائرات بميزات)
static std::string planeTexPath(int i) {
	return std::string("res://assets/planes/plane_") + std::to_string(i + 1) + ".png";
}

Ref<Texture2D> NujoomGame::planeTex(int plane) {
	if (plane < 0 || plane >= nj::N_PLANE) return Ref<Texture2D>();
	return tex(planeTexPath(plane));
}

// صورة طائرة اللاعب: طائرة المتجر المختارة، وإلا الطيارة الأساسية بقطعها
Ref<Texture2D> NujoomGame::playerShipTex(float *k) {
	if (prof.planeSel >= 0) {
		Ref<Texture2D> t = planeTex(prof.planeSel);
		if (t.is_valid()) {
			*k = 1.25f;
			return t;
		}
	}
	return shipTexFor(prof.shipImage(), k);
}

// منصة استعراض الطائرة: تدور على منصة بسماكة وظل ومنظور، ومدافعها تطلق للأمام
void NujoomGame::drawPlaneShowcase(Rect2 a, int pl) {
	if (pl < 0 || pl >= nj::N_PLANE) return;
	const nj::PlaneDef &pd = nj::PLANES[pl];
	Color pc = Cc(pd.col);
	panel(a, Color(0.01f, 0.03f, 0.09f, 0.8f), Color(pc.r, pc.g, pc.b, 0.55f));
	Vector2 mid(a.position.x + a.size.x * 0.5f, a.position.y + a.size.y * 0.5f);
	glow(mid, a.size.y * 0.5f, Color(pc.r, pc.g, pc.b, 0.12f));
	float R = std::min(a.size.x * 0.46f, a.size.y * 0.62f);
	const float tilt = 0.62f;
	Vector2 P(mid.x, a.position.y + a.size.y * 0.66f);

	draw_set_transform(P, 0, Vector2(1.0f, 0.3f));
	draw_circle(Vector2(0, 0), R, Color(0.02f, 0.05f, 0.12f, 0.85f));
	draw_arc(Vector2(0, 0), R, 0, nj::TAU, 72, Color(pc.r, pc.g, pc.b, 0.85f), 4.0f * u);
	draw_arc(Vector2(0, 0), R * 0.72f, 0, nj::TAU, 64, Color(pc.r, pc.g, pc.b, 0.35f), 2.5f * u);
	draw_arc(Vector2(0, 0), R * 0.42f, 0, nj::TAU, 48, Color(pc.r, pc.g, pc.b, 0.25f), 2.0f * u);
	for (int k = 0; k < 16; k++) {
		float an = clock * 0.5f + (float)k * nj::TAU / 16.0f;
		draw_circle(Vector2(std::cos(an), std::sin(an)) * R * 0.88f, 3.5f * u, Color(1, 1, 1, 0.7f));
	}
	draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));

	float bob = std::sin(clock * 1.7f) * 7.0f * u;
	draw_set_transform(Vector2(P.x, P.y - R * 0.02f), 0, Vector2(1.0f, 0.3f));
	draw_circle(Vector2(0, 0), R * 0.5f, Color(0, 0, 0, 0.38f));
	draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));

	float SZ = R * 1.5f;
	Vector2 shipC(P.x, P.y - R * 0.5f + bob);
	float psi = -nj::PI * 0.5f + clock * 0.7f;   // الطائرة تلف على المنصة
	float cp = std::cos(psi), sp = std::sin(psi);
	Ref<Texture2D> t = planeTex(pl);
	Color tint = Cc(nj::SHIP_COLORS[prof.shipColor].argb);
	if (t.is_valid()) {
		float sn = SZ * 1.25f;
		const int LAYERS = 7;
		for (int k = 0; k < LAYERS; k++) {
			float depth = (float)(LAYERS - 1 - k) * 2.4f * u;
			float shade = 0.28f + 0.72f * (float)k / (float)(LAYERS - 1);
			Transform2D xf(Vector2(cp, sp * tilt), Vector2(-sp, cp * tilt), Vector2(shipC.x, shipC.y + depth));
			draw_set_transform_matrix(xf);
			Color m(tint.r * shade, tint.g * shade, tint.b * shade, 1.0f);
			draw_texture_rect(t, Rect2(Vector2(-sn * 0.5f, -sn * 0.5f), Vector2(sn, sn)), false, m);
		}
		draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));
	}

	// طلقات المدافع (كلها للأمام)
	float unitPx = SZ / 5.4f;
	auto proj = [&](float lx, float ly) {
		float qx = lx * unitPx, qy = ly * unitPx;
		return Vector2(shipC.x + qx * cp - qy * sp, shipC.y + (qx * sp + qy * cp) * tilt);
	};
	float rate = 0.3f / std::max(0.1f, pd.gunGap);
	for (int g = 0; g < pd.guns; g++) {
		float lx, ly;
		nj::planeMuzzle(pd.guns, g, lx, ly);
		for (int j = 0; j < 3; j++) {
			float ph = std::fmod(clock * rate * 3.0f + (float)j / 3.0f + (float)g * 0.17f, 1.0f);
			draw_circle(proj(lx + ph * 7.0f, ly), 3.2f * u, Color(1, 0.9f, 0.4f, 1.0f - ph));
		}
		draw_circle(proj(lx, ly), 5.0f * u, Color(1, 0.9f, 0.4f, 0.45f + 0.3f * std::sin(clock * 12.0f + (float)g)));
	}
	text(pd.name, mid.x, a.position.y + 40.0f * u, 34.0f * u, Color(1, 0.95f, 0.7f));
}

// قسم الطائرات: منصة ثلاثية الأبعاد + مواصفات الطائرة + زر شراء/اختيار + بطاقات الطائرات العشر
void NujoomGame::drawPlanes(Rect2 area) {
	if (planeView < 0 || planeView >= nj::N_PLANE) planeView = prof.planeSel >= 0 ? prof.planeSel : 0;
	bool land = W > H;
	float g = 8.0f * u;
	Rect2 showR, infoR, listR;
	if (land) {
		float lw = area.size.x * 0.46f, sh = area.size.y * 0.5f;
		showR = Rect2(area.position.x, area.position.y, lw, sh);
		infoR = Rect2(area.position.x, area.position.y + sh + g, lw, area.size.y - sh - g);
		listR = Rect2(area.position.x + lw + g, area.position.y, area.size.x - lw - g, area.size.y);
	} else {
		float sh = std::min(area.size.y * 0.30f, 560.0f * u), ih = area.size.y * 0.27f;
		showR = Rect2(area.position.x, area.position.y, area.size.x, sh);
		infoR = Rect2(area.position.x, area.position.y + sh + g, area.size.x, ih);
		listR = Rect2(area.position.x, area.position.y + sh + ih + 2.0f * g, area.size.x, area.size.y - sh - ih - 2.0f * g);
	}
	drawPlaneShowcase(showR, planeView);

	// ---- المواصفات
	const nj::PlaneDef &pd = nj::PLANES[planeView];
	Color pc = Cc(pd.col);
	panel(infoR, Color(0.02f, 0.04f, 0.1f, 0.85f), Color(pc.r, pc.g, pc.b, 0.5f));
	float bh = std::min(84.0f * u, infoR.size.y * 0.24f);
	float x = infoR.position.x + infoR.size.x - 18.0f * u, tw = infoR.size.x - 36.0f * u;
	float lineH = (infoR.size.y - bh - 28.0f * u) / 5.0f, fs = std::min(30.0f * u, lineH * 0.72f);
	float y0 = infoR.position.y + 10.0f * u;
	std::string cdTxt = pd.ability == nj::AB_HEAL ? std::string("شرط التفعيل: تدمير 10 أعداء") : "وقت إعادة الميزة: " + std::to_string((int)pd.cd) + " ثانية";
	textFit(std::string("المدفع: ") + pd.gunAr, x, y0 + lineH * 0.8f, fs, tw, Color(1, 0.9f, 0.5f), 2);
	textFit(std::string("الميزة: ") + pd.abilityAr, x, y0 + lineH * 1.8f, fs, tw, Color(0.6f, 1, 0.8f), 2);
	textFit(std::string("السرعة: ") + pd.speedAr, x, y0 + lineH * 2.8f, fs, tw, Color(0.6f, 0.85f, 1), 2);
	textFit(std::string("التحمل: ") + pd.enduranceAr, x, y0 + lineH * 3.8f, fs, tw, Color(1, 0.7f, 0.7f), 2);
	textFit(cdTxt, x, y0 + lineH * 4.8f, fs, tw, Color(0.85f, 0.85f, 1), 2);

	// ---- زر شراء / اختيار
	bool own = prof.planeOwned[planeView], sel = prof.planeSel == planeView;
	bool afford = prof.yen >= pd.price;
	std::string lab;
	Color fillc, edgec, tc;
	if (sel) {
		lab = "✔ مختارة — اضغط للإلغاء";
		fillc = Color(0.05f, 0.25f, 0.1f, 0.95f); edgec = Color(0.4f, 1, 0.5f, 1); tc = Color(0.5f, 1, 0.6f);
	} else if (own) {
		lab = "اختيار هذه الطائرة";
		fillc = Color(0.1f, 0.2f, 0.4f, 0.95f); edgec = Color(0.5f, 0.75f, 1, 1); tc = Color(1, 0.95f, 0.7f);
	} else {
		lab = "شراء — " + commas(pd.price) + " د.ع";
		fillc = afford ? Color(0.08f, 0.28f, 0.12f, 0.95f) : Color(0.28f, 0.08f, 0.08f, 0.95f);
		edgec = afford ? Color(0.4f, 1, 0.5f, 1) : Color(1, 0.45f, 0.45f, 1);
		tc = afford ? Color(0.5f, 1, 0.6f) : Color(1, 0.6f, 0.6f);
	}
	Rect2 br(infoR.position.x + 14.0f * u, infoR.position.y + infoR.size.y - bh - 10.0f * u, infoR.size.x - 28.0f * u, bh);
	Rect2 f = card3d(B_PLANE_ACT, br, fillc, edgec);
	textFit(lab, f.position.x + f.size.x * 0.5f, f.position.y + f.size.y * 0.5f + 11.0f * u, 32.0f * u, f.size.x - 20.0f * u, tc, 1);

	// ---- بطاقات الطائرات العشر (عمودين × 5 صفوف)
	int cols = 2, rows = (nj::N_PLANE + cols - 1) / cols;
	float cw = listR.size.x / (float)cols, ch = listR.size.y / (float)rows;
	for (int i = 0; i < nj::N_PLANE; i++) {
		const nj::PlaneDef &d = nj::PLANES[i];
		Color c = Cc(d.col);
		int cx = i % cols, cy = i / cols;
		Rect2 r(listR.position.x + cw * (float)cx + 4.0f * u, listR.position.y + ch * (float)cy + 4.0f * u, cw - 8.0f * u, ch - 8.0f * u);
		bool view = planeView == i, o = prof.planeOwned[i], s2 = prof.planeSel == i;
		Rect2 cf = card3d(B_PLANE_CARD + i, r, view ? Color(c.r * 0.30f, c.g * 0.30f, c.b * 0.30f, 0.95f) : Color(0.03f, 0.04f, 0.1f, 0.9f), view ? Color(c.r, c.g, c.b, 1.0f) : Color(c.r, c.g, c.b, 0.45f));
		Ref<Texture2D> t = planeTex(i);
		if (t.is_valid()) {
			float is = std::min(cf.size.y * 1.15f, cf.size.x * 0.42f);
			Vector2 ctr(cf.position.x + cf.size.x * 0.2f, cf.position.y + cf.size.y * 0.5f);
			draw_set_transform(ctr, -nj::PI * 0.5f, Vector2(1, 1));
			draw_texture_rect(t, Rect2(Vector2(-is * 0.5f, -is * 0.5f), Vector2(is, is)), false, Color(1, 1, 1, o ? 1.0f : 0.8f));
			draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));
		}
		float tx = cf.position.x + cf.size.x * 0.62f, mw = cf.size.x * 0.52f;
		textFit(d.name, tx, cf.position.y + cf.size.y * 0.44f, std::min(26.0f * u, cf.size.y * 0.2f), mw, Color(1, 0.95f, 0.8f), 1);
		std::string st = s2 ? "● مختارة" : (o ? "✔ مملوكة" : commas(d.price) + " د.ع");
		Color sc = s2 ? Color(0.4f, 1, 0.5f) : (o ? Color(0.7f, 0.9f, 1) : (prof.yen >= d.price ? Color(0.4f, 1, 0.5f) : Color(1, 0.5f, 0.5f)));
		textFit(st, tx, cf.position.y + cf.size.y * 0.78f, std::min(24.0f * u, cf.size.y * 0.18f), mw, sc, 1);
	}
}

void NujoomGame::drawStore() {
	drawHeader("المتجر");
	// الطائرة المعروضة: إذا تغيّرت (شراء/إعادة) نسوي انتقال سلس
	int target = prof.shipImage();
	if (storeImg < 0) { storeImg = storePrevImg = target; storeFade = 1.0f; }
	else if (target != storeImg) { storePrevImg = storeImg; storeImg = target; storeFade = 0.0f; }

	bool land = W > H;
	float avail = W - 40.0f * u;
	float ty = 104.0f * u, th = 66.0f * u, gap = 10.0f * u;
	bool testBtn = TEST_YEN > 0;
	float tw = testBtn ? (avail - 3.0f * gap) * 0.22f : (avail - 2.0f * gap) / 3.0f;
	static const char *tabNames[3] = {"القطع", "الترقيات", "الطائرات"};
	for (int i = 0; i < 3; i++) {
		Rect2 r(20.0f * u + (tw + gap) * (float)i, ty, tw, th);
		bool on = storeTab == i;
		Rect2 f = card3d(B_STORE_TAB + i, r, on ? Color(0.12f, 0.2f, 0.42f, 0.95f) : Color(0.03f, 0.04f, 0.1f, 0.9f), on ? Color(0.5f, 0.75f, 1.0f, 1.0f) : Color(1, 1, 1, 0.3f));
		textFit(tabNames[i], f.position.x + f.size.x * 0.5f, f.position.y + f.size.y * 0.5f + 11.0f * u, 32.0f * u, f.size.x - 12.0f * u, on ? Color(1, 0.9f, 0.5f) : Color(0.8f, 0.85f, 0.95f), 1);
	}
	if (testBtn) {
		Rect2 r(20.0f * u + (tw + gap) * 3.0f, ty, avail - (tw + gap) * 3.0f, th);
		Rect2 f = card3d(B_STORE_RESET, r, Color(0.3f, 0.12f, 0.05f, 0.95f), Color(1.0f, 0.6f, 0.3f, 0.9f));
		text("تجربة: إعادة من الصفر", f.position.x + f.size.x * 0.5f, f.position.y + f.size.y * 0.5f + 10.0f * u, 26.0f * u, Color(1, 0.85f, 0.6f));
	}

	float y0 = ty + th + 12.0f * u, y1 = H - 70.0f * u;
	if (storeTab == 0) {
		if (land) {
			float sw = W * 0.38f;
			drawShipShowcase(Rect2(20.0f * u, y0, sw, y1 - y0));
			drawStoreParts(Rect2(20.0f * u + sw + 10.0f * u, y0, avail - sw - 10.0f * u, y1 - y0));
		} else {
			float sh = std::min((y1 - y0) * 0.31f, 640.0f * u);
			drawShipShowcase(Rect2(20.0f * u, y0, avail, sh));
			drawStoreParts(Rect2(20.0f * u, y0 + sh + 8.0f * u, avail, y1 - (y0 + sh + 8.0f * u)));
		}
	} else if (storeTab == 1) {
		drawStoreStats(Rect2(20.0f * u, y0, avail, y1 - y0));
	} else {
		drawPlanes(Rect2(20.0f * u, y0, avail, y1 - y0));
	}
	if (storeMsgT > 0) text(storeMsg, W * 0.5f, H - 28.0f * u, 36.0f * u, Color(1, 0.95f, 0.6f));
}

void NujoomGame::drawLook() {
	drawHeader("المظهر");
	bool land = W > H;
	int cc = land ? nj::N_SHIP_COLOR : 3, cr = (nj::N_SHIP_COLOR + cc - 1) / cc;
	int fc = land ? nj::N_FIELD : 2, fr = (nj::N_FIELD + fc - 1) / fc;
	float titleH = 56 * u;
	float availH = H - 110 * u - 2 * titleH - 70 * u;
	float rowH = std::min(270.0f * u, availH / (float)(cr + fr));
	float y = 110 * u;
	// ---- لون الطائرة ----
	text("لون الطائرة", W * 0.5f, y + 40 * u, 36 * u, Color(1, 0.85f, 0.4f));
	y += titleH;
	float cw = (W - 40 * u) / (float)cc;
	float stK = 1.0f;
	Ref<Texture2D> st = playerShipTex(&stK);   // معاينة الألوان على طائرتك الحالية
	for (int i = 0; i < nj::N_SHIP_COLOR; i++) {
		int cx = i % cc, cy = i / cc;
		Rect2 r(20 * u + cw * (float)cx + 6 * u, y + rowH * (float)cy + 6 * u, cw - 12 * u, rowH - 12 * u);
		btns.push_back({B_LOOK_COLOR + i, r});
		const nj::SkinDef &sk = nj::SHIP_COLORS[i];
		bool own = prof.colorOwned[i], sel = prof.shipColor == i;
		bool afford = prof.yen >= sk.price;
		panel(r, Color(0, 0, 0, 0.55f), sel ? Color(0.3f, 1, 0.4f) : (own || afford ? Color(1, 1, 1, 0.5f) : Color(1, 1, 1, 0.2f)));
		if (st.is_valid()) {
			float is = std::min(r.size.x * 0.6f, r.size.y * 0.5f) * stK;
			Vector2 ctr(r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.38f);
			draw_set_transform(ctr, -nj::PI * 0.5f, Vector2(1, 1));
			draw_texture_rect(st, Rect2(Vector2(-is * 0.5f, -is * 0.5f), Vector2(is, is)), false, Cc(sk.argb));
			draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));
		}
		float fs = std::min(28.0f * u, rowH * 0.11f);
		text(sk.nameAr, r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.72f, fs, Color(1, 0.95f, 0.7f));
		std::string lab = sel ? "✔ مفعّل" : (own ? "اضغط للتفعيل" : commas(sk.price) + " د.ع");
		text(lab, r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.92f, fs * 0.95f, sel ? Color(0.4f, 1, 0.5f) : (own ? Color(0.8f, 0.9f, 1) : (afford ? Color(0.4f, 1, 0.5f) : Color(1, 0.5f, 0.5f))));
	}
	y += rowH * (float)cr + 10 * u;
	// ---- الفيلد ----
	text("شكل الفيلد", W * 0.5f, y + 40 * u, 36 * u, Color(1, 0.85f, 0.4f));
	y += titleH;
	float fw = (W - 40 * u) / (float)fc;
	for (int i = 0; i < nj::N_FIELD; i++) {
		int cx = i % fc, cy = i / fc;
		Rect2 r(20 * u + fw * (float)cx + 6 * u, y + rowH * (float)cy + 6 * u, fw - 12 * u, rowH - 12 * u);
		btns.push_back({B_LOOK_FIELD + i, r});
		const nj::FieldDef &fd = nj::FIELD_THEMES[i];
		bool own = prof.fieldOwned[i], sel = prof.fieldTheme == i;
		bool afford = prof.yen >= fd.price;
		draw_rect(r, Cc(fd.bg), true);
		draw_circle(Vector2(r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.4f), r.size.y * 0.3f, Cc(fd.glow, 0.25f));
		for (int k = 0; k < 14; k++) {
			float sx = r.position.x + r.size.x * std::fmod(0.137f + 0.311f * (float)k + 0.07f * (float)i, 1.0f);
			float sy = r.position.y + r.size.y * std::fmod(0.213f + 0.173f * (float)k, 0.62f);
			draw_circle(Vector2(sx, sy), (k % 3 + 1) * u, Cc(fd.star, 0.8f));
		}
		draw_rect(Rect2(r.position.x, r.position.y + r.size.y * 0.62f, r.size.x, r.size.y * 0.38f), Color(0, 0, 0, 0.55f), true);
		draw_rect(r, sel ? Color(0.3f, 1, 0.4f) : Color(1, 1, 1, own || afford ? 0.5f : 0.2f), false, 3 * u);
		float fs = std::min(28.0f * u, rowH * 0.11f);
		text(fd.nameAr, r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.8f, fs, Color(1, 0.95f, 0.7f));
		std::string lab = sel ? "✔ مفعّل" : (own ? "اضغط للتفعيل" : commas(fd.price) + " د.ع");
		text(lab, r.position.x + r.size.x * 0.5f, r.position.y + r.size.y * 0.94f, fs * 0.95f, sel ? Color(0.4f, 1, 0.5f) : (own ? Color(0.8f, 0.9f, 1) : (afford ? Color(0.4f, 1, 0.5f) : Color(1, 0.5f, 0.5f))));
	}
	if (storeMsgT > 0) text(storeMsg, W * 0.5f, H - 28 * u, 36 * u, Color(1, 0.95f, 0.6f));
}

void NujoomGame::drawCasino() {
	drawHeader("السوق السوداء");
	static const char *syms[6] = {"bolt", "diamond", "gear", "rocket", "star", "yen"};
	float cy = H * 0.3f, rs = std::min(W * 0.26f, 240.0f * u);
	for (int i = 0; i < 3; i++) {
		Rect2 r(W * 0.5f + ((float)i - 1.5f) * (rs + 20 * u) + 10 * u, cy, rs, rs);
		panel(r, Color(0, 0, 0, 0.7f), Color(1, 0.85f, 0.3f));
		icon(std::string("res://assets/icons/slot/icon_slot_") + syms[reels[i]] + ".png", r.grow(-14 * u));
	}
	text(casinoMsg.empty() ? "يدخل عملة 100 د.ع" : casinoMsg, W * 0.5f, cy + rs + 70 * u, 38 * u, Color(1, 0.95f, 0.6f));
	button(B_SPIN, Rect2(W * 0.5f - 260 * u, cy + rs + 110 * u, 520 * u, 100 * u), spinning ? "..." : "العب (100 د.ع)", Color(0.6f, 0.2f, 0.5f), 40);
	float y = cy + rs + 280 * u;
	const char *tbl[6] = {"3 صواريخ : 10,000 د.ع", "3 ألماس : 750 د.ع", "3 نجوم : 300 د.ع", "3 عملات : 100 د.ع", "3 صواعق : 50 د.ع", "3 تروس : 20 د.ع"};
	for (int i = 0; i < 6; i++) {
		text(tbl[i], W * 0.5f, y, 26 * u, Color(0.8f, 0.85f, 1));
		y += 36 * u;
	}
}

void NujoomGame::drawAch() {
	drawHeader("الإنجازات");
	float top = 130 * u, rh = std::min(110.0f * u, (H - top - 20 * u) / (float)nj::N_ACH);
	for (int i = 0; i < nj::N_ACH; i++) {
		Rect2 r(30 * u, top + rh * (float)i + 4 * u, W - 60 * u, rh - 8 * u);
		bool got = prof.ach[i];
		panel(r, Color(0, 0, 0, 0.5f), got ? Color(0.4f, 1, 0.5f) : Color(1, 1, 1, 0.25f));
		text(nj::ACHS[i].titleAr, W - 50 * u, r.position.y + r.size.y * 0.45f, 34 * u, got ? Color(1, 0.9f, 0.4f) : Color(0.7f, 0.7f, 0.7f), 2);
		text(nj::ACHS[i].descAr, W - 50 * u, r.position.y + r.size.y * 0.82f, 24 * u, Color(0.8f, 0.85f, 0.95f), 2);
		text(got ? "تم" : "مقفل", 50 * u, r.position.y + r.size.y * 0.62f, 30 * u, got ? Color(0.4f, 1, 0.5f) : Color(0.6f, 0.6f, 0.6f), 0);
	}
}

void NujoomGame::drawOver() {
	text(lastDied ? "انتهت الرحلة" : "انسحاب", W * 0.5f, H * 0.2f, 72 * u, lastDied ? Color(1, 0.4f, 0.4f) : Color(0.6f, 0.9f, 1));
	float y = H * 0.32f, st = 70 * u;
	text("الوقت: " + mmss(lastTime), W * 0.5f, y, 40 * u, Color(1, 1, 1));
	y += st;
	text("الأعداء المقتولون: " + std::to_string(lastKills), W * 0.5f, y, 40 * u, Color(1, 1, 1));
	y += st;
	text("أفضل سلسلة: " + std::to_string(lastStreak), W * 0.5f, y, 40 * u, Color(1, 1, 1));
	y += st;
	text("الزعماء: " + std::to_string(lastBoss), W * 0.5f, y, 40 * u, Color(1, 1, 1));
	y += st * 1.3f;
	text("المكسب: +" + commas(lastYen) + " د.ع", W * 0.5f, y, 52 * u, Color(1, 0.9f, 0.4f));
	y += st;
	text("الرصيد: " + nj::formatYen(prof.yen), W * 0.5f, y, 36 * u, Color(0.9f, 0.9f, 0.9f));
	if (lastDuel) {
		bool pvp = lastMode == nj::GM_PVP;
		float dy = (H > W ? H * 0.6f : H * 0.68f);
		text(pvp ? "- نتقاتل بيناتنا -" : "- سوّه ضد الأعداء -", W * 0.5f, dy, 36 * u, Color(0.6f, 0.9f, 1));
		int oi = 1 - lastMe;
		text("أنت: " + std::to_string(lastSum[lastMe].kills) + " قتيل  |  " + (lastSum[lastMe].dead ? (lastSum[lastMe].quit ? "انسحبت" : "سقطت") : "ناجي"), W * 0.5f, dy + 56 * u, 30 * u, Color(1, 1, 1));
		text(std::string(pvp ? "الخصم: " : "الصديق: ") + std::to_string(lastSum[oi].kills) + " قتيل  |  " + (lastSum[oi].dead ? (lastSum[oi].quit ? "انسحب" : "سقط") : "ناجي"), W * 0.5f, dy + 106 * u, 30 * u, Color(1, 1, 1));
		if (pvp) {
			if (lastWinner == lastMe) text("فزت!", W * 0.5f, dy + 170 * u, 56 * u, Color(0.4f, 1, 0.5f));
			else if (lastWinner < 0) text("تعادل", W * 0.5f, dy + 170 * u, 56 * u, Color(1, 0.9f, 0.4f));
			else text("خسرت", W * 0.5f, dy + 170 * u, 56 * u, Color(1, 0.45f, 0.4f));
		} else {
			text("صمدتم " + mmss(lastTime) + " سوّه", W * 0.5f, dy + 170 * u, 40 * u, Color(0.4f, 1, 0.5f));
		}
		if (peerLeft) text("الصديق غادر المباراة", W * 0.5f, dy + 225 * u, 28 * u, Color(1, 0.7f, 0.5f));
	}
	button(B_OVER_OK, Rect2(W * 0.5f - 260 * u, H * 0.78f, 520 * u, 110 * u), "العودة للقاعدة", Color(0.15f, 0.55f, 0.3f), 42);
}

// ------------------------------------------------------------------ lobby
void NujoomGame::drawLobby() {
	drawHeader("اللعب مع صديق");
	float cx = W * 0.5f, bw = 620 * u;
	if (netState == NS_IDLE) {
		text("العبوا سوّه على نفس الشاشة: ضد الأعداء أو بيناتكم", cx, H * 0.2f, 30 * u, Color(0.8f, 0.9f, 1));
		button(B_NET_CREATE, Rect2(cx - bw * 0.5f, H * 0.3f, bw, 120 * u), "إنشاء غرفة", Color(0.15f, 0.65f, 0.3f), 44);
		button(B_NET_JOIN, Rect2(cx - bw * 0.5f, H * 0.3f + 150 * u, bw, 120 * u), "الانضمام لغرفة", Color(0.25f, 0.35f, 0.7f), 44);
		if (!netMsg.empty()) text(netMsg, cx, H * 0.3f + 340 * u, 28 * u, Color(1, 0.6f, 0.5f));
	} else if (netState == NS_JOIN_INPUT) {
		text("اكتب رمز الغرفة", cx, H * 0.17f, 44 * u, Color(1, 1, 1));
		float bs = 100 * u, g = 14 * u;
		float x0 = cx - ((float)NET_CODE_LEN * bs + (float)(NET_CODE_LEN - 1) * g) * 0.5f;
		for (size_t i = 0; i < NET_CODE_LEN; i++) {
			Rect2 r(x0 + (float)i * (bs + g), H * 0.23f, bs, bs * 1.2f);
			panel(r, Color(0, 0, 0, 0.5f), Color(1, 0.85f, 0.3f));
			if (i < netInput.size()) text(std::string(1, netInput[i]), r.position.x + bs * 0.5f, r.position.y + bs * 0.88f, 64 * u, Color(1, 0.9f, 0.4f));
		}
		float ks = 150 * u, kg = 18 * u;
		float kx = cx - (3 * ks + 2 * kg) * 0.5f;
		float ky = H * 0.23f + bs * 1.2f + 60 * u;
		for (int i = 0; i < 9; i++) {
			Rect2 r(kx + (float)(i % 3) * (ks + kg), ky + (float)(i / 3) * (ks * 0.75f + kg), ks, ks * 0.75f);
			button(B_NET_DIGIT + i + 1, r, std::to_string(i + 1), Color(0.25f, 0.3f, 0.5f), 44);
		}
		float ry = ky + 3 * (ks * 0.75f + kg);
		button(B_NET_DEL, Rect2(kx, ry, ks, ks * 0.75f), "حذف", Color(0.6f, 0.25f, 0.25f), 32);
		button(B_NET_DIGIT, Rect2(kx + ks + kg, ry, ks, ks * 0.75f), "0", Color(0.25f, 0.3f, 0.5f), 44);
		button(B_NET_GO, Rect2(kx + 2 * (ks + kg), ry, ks, ks * 0.75f), "دخول", Color(0.15f, 0.6f, 0.3f), 32);
		if (!netMsg.empty()) text(netMsg, cx, ry + ks * 0.75f + 60 * u, 28 * u, Color(1, 0.6f, 0.5f));
	} else if (netState == NS_CONNECTING) {
		text(netMsg, cx, H * 0.4f, 40 * u, Color(0.8f, 0.9f, 1, 0.6f + 0.4f * std::sin(clock * 5)));
	} else {
		text("رمز الغرفة", cx, H * 0.22f, 36 * u, Color(0.8f, 0.9f, 1));
		text(netCode, cx, H * 0.22f + 130 * u, 130 * u, Color(1, 0.85f, 0.3f));
		text("اللاعبون: " + std::to_string(netPlayers) + "/2", cx, H * 0.22f + 210 * u, 36 * u, Color(1, 1, 1));
		bool pvp = netMode == nj::GM_PVP;
		if (netYou == 0) {
			float my = H * 0.22f + 270 * u;
			Color on(0.15f, 0.65f, 0.3f), off(0.25f, 0.3f, 0.45f);
			button(B_NET_COOP, Rect2(cx - bw * 0.5f, my, bw, 100 * u), "نتحارب سوّه ضد الأعداء", pvp ? off : on, 36);
			button(B_NET_PVP, Rect2(cx - bw * 0.5f, my + 116 * u, bw, 100 * u), "نتقاتل بيناتنا", pvp ? Color(0.75f, 0.25f, 0.25f) : off, 36);
			float sy = my + 250 * u;
			if (netPlayers >= 2 && peerHello) button(B_NET_START, Rect2(cx - bw * 0.5f, sy, bw, 130 * u), "ابدأ", Color(0.15f, 0.65f, 0.3f), 48);
			else if (netPlayers >= 2) text("جاري تجهيز صديقك...", cx, sy + 60 * u, 34 * u, Color(0.8f, 0.9f, 1, 0.6f + 0.4f * std::sin(clock * 4)));
			else text("بانتظار صديقك... أعطه الرمز", cx, sy + 60 * u, 34 * u, Color(0.8f, 0.9f, 1, 0.6f + 0.4f * std::sin(clock * 4)));
		} else {
			float my = H * 0.22f + 290 * u;
			text(pvp ? "الطور: نتقاتل بيناتنا" : "الطور: سوّه ضد الأعداء", cx, my, 40 * u, pvp ? Color(1, 0.55f, 0.5f) : Color(0.5f, 1, 0.6f));
			text("بانتظار المضيف ليبدأ...", cx, my + 90 * u, 34 * u, Color(0.8f, 0.9f, 1, 0.6f + 0.4f * std::sin(clock * 4)));
		}
	}
}

// ------------------------------------------------------------------ world
void NujoomGame::drawWorld() {
	using namespace nj;
	Run &r = *run;
	float ws = duel ? std::min(W / nj::MP_VIEW_W, H / nj::MP_VIEW_H) : u * 0.85f;   // both phones show the same area in a shared match
	const int myi = me();
	nj::V2 camv = r.camCenter;
	Vector2 cam(camv.x, camv.y);
	drawBackground(cam, ws);
	Vector2 mid(W * 0.5f, H * 0.5f);
	auto SP = [&](nj::V2 p) { return Vector2((p.x - cam.x) * ws + mid.x, (p.y - cam.y) * ws + mid.y); };
	auto onScreen = [&](Vector2 p, float rad) { return p.x > -rad && p.x < W + rad && p.y > -rad && p.y < H + rad; };

	// hazard zones & cores (below everything)
	for (auto &z : r.zones) {
		Vector2 c = SP(z.p);
		if (!onScreen(c, z.r * ws + 40)) continue;
		if (z.kind == ZK_GAS) draw_circle(c, z.r * ws, Cc(0xFF44FF44, 0.18f * (z.life / z.maxLife)));
		else if (z.kind == ZK_CORE) glow(c, z.r * ws * (1.0f + 0.2f * std::sin(clock * 20)), Cc(z.col, 0.6f));
	}
	for (int pi = 0; pi < r.np; pi++)
		if (!r.pl[pi].dead && r.pl[pi].cryoVis > 0) draw_arc(SP(r.pl[pi].ship.p), r.pl[pi].cryoVis * ws, 0, TAU, 48, Color(0.5f, 0.85f, 1, 0.35f), 2 * u);

	// mines
	for (auto &m : r.mines) {
		Vector2 c = SP(m.p);
		draw_circle(c, 13 * ws, Color(0.3f, 0.3f, 0.35f));
		bool blink = std::fmod(m.t * 3.0f, 1.0f) < 0.5f;
		draw_circle(c, 6 * ws, m.t > m.arm ? (blink ? Color(1, 0.2f, 0.2f) : Color(0.4f, 0.05f, 0.05f)) : Color(0.5f, 0.5f, 0.2f));
		if (m.jackpot) draw_arc(c, 18 * ws, 0, TAU, 20, Color(1, 0.9f, 0.2f), 2);
	}

	// asteroids
	for (auto &a : r.asteroids) {
		Vector2 c = SP(a.p);
		if (!onScreen(c, a.r * ws + 10)) continue;
		static const uint32_t cols[6] = {0xFF8B7B6B, 0xFF9BD6F0, 0xFF8E98A3, 0xFFE0762A, 0xFFA06BD6, 0xFF6BD65A};
		Color base = Cc(cols[a.type]);
		if (a.flash > 0) base = Color(1, 1, 1);
		std::vector<Vector2> pts;
		uint32_t s = a.seed;
		int n = 11;
		for (int i = 0; i < n; i++) {
			s = s * 1664525u + 1013904223u;
			float j = 0.78f + 0.3f * (float)((s >> 8) & 255) / 255.0f;
			float ang = a.rot + (float)i * TAU / (float)n;
			pts.push_back(c + Vector2(std::cos(ang), std::sin(ang)) * (a.r * j * ws));
		}
		polyFill(pts, base * Color(0.55f, 0.55f, 0.55f, 1), base, 2.0f * u);
		if (a.type == 3) draw_circle(c, a.r * 0.3f * ws, Color(1, 0.8f, 0.2f, 0.5f + 0.4f * std::sin(clock * 8)));
		if (a.hp < a.maxhp && a.size > 0) bar(Rect2(c.x - a.r * ws * 0.6f, c.y - a.r * ws - 10 * u, a.r * ws * 1.2f, 5 * u), a.hp / a.maxhp, Color(0.9f, 0.4f, 0.3f), Color(0, 0, 0, 0.5f));
	}

	// pickups
	for (auto &k : r.pickups) {
		Vector2 c = SP(k.p);
		if (!onScreen(c, 40)) continue;
		float blink = k.life < 4 ? (std::fmod(k.life * 6.0f, 1.0f) < 0.5f ? 0.3f : 1.0f) : 1.0f;
		if (k.kind == PK_COIN) {
			draw_circle(c, 10 * ws, Color(1, 0.8f, 0.1f, blink));
			draw_circle(c, 6 * ws, Color(1, 0.95f, 0.5f, blink));
		} else if (k.kind == PK_UPGRADE) {
			float pulse = 1.0f + 0.15f * std::sin(clock * 6);
			glow(c, 26 * ws * pulse, Color(0.4f, 0.8f, 1, blink));
			std::vector<Vector2> d = {c + Vector2(0, -16 * ws), c + Vector2(13 * ws, 0), c + Vector2(0, 16 * ws), c + Vector2(-13 * ws, 0)};
			polyFill(d, Color(1, 1, 1, 0.95f * blink), Color(0.3f, 0.7f, 1, blink), 2);
		} else if (k.kind == PK_HEAL) {
			draw_circle(c, 14 * ws, Color(0.1f, 0.5f, 0.2f, blink));
			draw_rect(Rect2(c.x - 3 * ws, c.y - 9 * ws, 6 * ws, 18 * ws), Color(0.5f, 1, 0.6f, blink), true);
			draw_rect(Rect2(c.x - 9 * ws, c.y - 3 * ws, 18 * ws, 6 * ws), Color(0.5f, 1, 0.6f, blink), true);
		} else {
			draw_circle(c, 14 * ws, Color(0.2f, 0.4f, 0.9f, blink));
			draw_arc(c, 9 * ws, 0, TAU, 14, Color(0.7f, 0.9f, 1, blink), 2);
		}
	}

	// enemies
	for (auto &e : r.enemies) {
		Vector2 c = SP(e.p);
		const EnemyDef &d = ENEMIES[e.type];
		if (!onScreen(c, e.r * ws + 20)) continue;
		float ca = std::cos(e.ang), sa = std::sin(e.ang);
		auto rot = [&](float x, float y) { return c + Vector2(x * ca - y * sa, x * sa + y * ca) * (e.r * ws); };
		Color col = e.flash > 0 ? Color(1, 1, 1) : Cc(d.col);
		col.a = e.alpha;
		std::vector<Vector2> pts = {rot(1.0f, 0), rot(-0.8f, 0.95f), rot(-0.35f, 0), rot(-0.8f, -0.95f)};
		polyFill(pts, col * Color(0.5f, 0.5f, 0.5f, e.alpha), col, 2.5f * u);
		if (d.tier >= 3) draw_circle(c, e.r * 0.35f * ws, Color(col.r, col.g, col.b, 0.8f * e.alpha));
		if (e.slowT > 0) draw_arc(c, (e.r + 8) * ws, 0, TAU, 16, Color(0.6f, 0.9f, 1, 0.7f), 2);
		if (e.hp < e.maxhp) bar(Rect2(c.x - e.r * ws, c.y - e.r * ws - 12 * u, e.r * ws * 2, 5 * u), e.hp / e.maxhp, Color(0.9f, 0.3f, 0.3f), Color(0, 0, 0, 0.5f));
	}

	// boss
	if (r.boss.active) {
		const Boss &b = r.boss;
		Vector2 c = SP(b.p);
		Color col = b.flash > 0 ? Color(1, 1, 1) : Color(0.85f, 0.2f, 0.35f);
		std::vector<Vector2> pts;
		for (int i = 0; i < 10; i++) {
			float a = clock * 0.6f + (float)i * TAU / 10.0f;
			float rr = (i % 2 == 0 ? 1.0f : 0.72f) * b.r * ws;
			pts.push_back(c + Vector2(std::cos(a), std::sin(a)) * rr);
		}
		polyFill(pts, col * Color(0.45f, 0.45f, 0.45f, 1), col, 4 * u);
		glow(c, b.r * 0.5f * ws, Color(1, 0.5f, 0.2f, 0.9f));
		if (b.telegraph > 0) {
			nj::V2 to = r.camCenter;
			float bestD = 1e30f;
			for (int pi = 0; pi < r.np; pi++)
				if (!r.pl[pi].dead && (r.pl[pi].ship.p - b.p).len2() < bestD) { bestD = (r.pl[pi].ship.p - b.p).len2(); to = r.pl[pi].ship.p; }
			draw_line(c, SP(to), Color(1, 0.2f, 0.2f, 0.4f + 0.4f * std::sin(clock * 30)), 6 * u);
		}
	}

	// enemy bullets
	for (auto &b : r.ebullets) {
		Vector2 c = SP(b.p);
		if (!onScreen(c, 30)) continue;
		glow(c, b.r * 2.2f * ws, Cc(b.col));
		if (b.kind != 0) draw_arc(c, b.r * 1.6f * ws, 0, TAU, 14, Cc(b.col, 0.7f), 2);
	}

	// orbitals
	std::vector<Orbital> orbs;
	for (int pi = 0; pi < r.np; pi++) r.orbitals(pi, orbs);
	for (auto &o : orbs) {
		Vector2 c = SP(o.p);
		if (o.wid == W_SAW) {
			std::vector<Vector2> pts;
			for (int i = 0; i < 16; i++) {
				float a = clock * 12.0f + (float)i * TAU / 16.0f;
				float rr = (i % 2 == 0 ? 1.0f : 0.72f) * o.r * ws;
				pts.push_back(c + Vector2(std::cos(a), std::sin(a)) * rr);
			}
			polyFill(pts, Color(1, 0.7f, 0.2f, 0.85f), Color(1, 1, 0.8f), 2);
		} else if (o.wid == W_FROST) {
			glow(c, o.r * 2.0f * ws, Color(0.5f, 0.85f, 1, 0.9f));
		} else {
			glow(c, o.r * 2.0f * ws, Color(0.5f, 0.6f, 1, 0.9f));
		}
	}
	for (auto &z : r.zones) {
		if (z.kind != ZK_BLADE) continue;
		Vector2 c = SP(z.p);
		std::vector<Vector2> pts;
		for (int i = 0; i < 12; i++) {
			float a = z.ang + (float)i * TAU / 12.0f;
			float rr = (i % 2 == 0 ? 1.0f : 0.7f) * z.r * ws;
			pts.push_back(c + Vector2(std::cos(a), std::sin(a)) * rr);
		}
		polyFill(pts, Color(1, 0.55f, 0.2f, 0.9f), Color(1, 1, 0.7f), 2);
	}

	// beam
	for (int pi = 0; pi < r.np; pi++) {
		const Player &bp = r.pl[pi];
		if (!bp.beamOn || bp.dead) continue;
		Vector2 a = SP(bp.beamA), b = SP(bp.beamB);
		draw_line(a, b, Color(0.7f, 0.3f, 1, 0.35f), bp.beamW * ws * 1.6f);
		draw_line(a, b, Color(0.9f, 0.6f, 1, 0.8f), bp.beamW * ws);
		draw_line(a, b, Color(1, 1, 1, 0.95f), bp.beamW * ws * 0.35f);
	}

	// player shots
	for (auto &s : r.shots) {
		Vector2 c = SP(s.p);
		if (!onScreen(c, 60)) continue;
		Color col = Cc(s.col);
		if (s.kind == 4) draw_line(c, c - Vector2(s.v.x, s.v.y).normalized() * 18 * ws, col, 2.5f * u);
		else if (s.kind == 5) {
			Vector2 tail = c - Vector2(s.v.x, s.v.y).normalized() * 90 * ws;
			draw_line(tail, c, Color(col.r, col.g, col.b, 0.4f), s.r * 2.6f * ws);
			draw_line(tail, c, Color(1, 1, 1, 0.9f), s.r * 0.9f * ws);
		} else if (s.kind == 1 || s.kind == 6) {
			draw_line(c, c - Vector2(s.v.x, s.v.y).normalized() * 26 * ws, Color(1, 0.7f, 0.3f, 0.6f), 4 * u);
			glow(c, s.r * 2.0f * ws, col);
		} else if (s.kind == 2 || s.kind == 3 || s.kind == 7) {
			draw_circle(c, s.r * ws, col);
			draw_circle(c, s.r * 0.5f * ws, Color(1, 1, 1, 0.9f));
		} else {
			glow(c, s.r * 2.4f * ws, col);
		}
	}

	// companions
	for (int pi = 0; pi < r.np; pi++) {
		const Player &cp = r.pl[pi];
		if (cp.dead) continue;
		if (cp.pas[P_TB26] > 0) {
			Vector2 c = SP(r.wingmanPos(pi));
			std::vector<Vector2> pts = {c + Vector2(0, -18 * ws), c + Vector2(13 * ws, 12 * ws), c + Vector2(0, 5 * ws), c + Vector2(-13 * ws, 12 * ws)};
			polyFill(pts, Color(0.2f, 0.6f, 0.3f), Color(0.6f, 1, 0.7f), 2);
		}
		for (int i = 0; i < cp.pas[P_DRONE]; i++) {
			Vector2 c = SP(r.droneFollowPos(pi, i));
			draw_circle(c, 9 * ws, Color(1, 0.85f, 0.4f));
			draw_circle(c, 4 * ws, Color(1, 1, 1));
		}
	}

	// player ships
	for (int pi = 0; pi < r.np; pi++) {
		const Player &sp = r.pl[pi];
		if (sp.dead) continue;
		Vector2 c = SP(sp.ship.p);
		float ca = std::cos(sp.ship.ang), sa = std::sin(sp.ship.ang);
		float sc = sp.ship.r * ws;
		auto rot = [&](float x, float y) { return c + Vector2(x * ca - y * sa, x * sa + y * ca) * sc; };
		bool stealth = sp.plane >= 0 && nj::PLANES[sp.plane].ability == nj::AB_STEALTH && sp.abT > 0;   // F-22: تخفّي (شفافة)
		bool dash = sp.plane >= 0 && nj::PLANES[sp.plane].ability == nj::AB_DASH && sp.abT > 0;         // Typhoon: لهب أطول
		bool blinkOff = sp.ship.invuln > 0 && !stealth && std::fmod(clock * 16.0f, 1.0f) < 0.5f;
		Color pc = Cc(PILOTS[sp.pilot].col);
		int shipImg = (pi == myi) ? prof.shipImage() : nj::shipImageOf(sp.store);   // الطائرة بالقطع اللي اشتريتها
		float shipK = 1.0f;
		Ref<Texture2D> shipTex;
		if (sp.plane >= 0) {   // طائرة من قسم الطائرات
			shipTex = planeTex(sp.plane);
			shipK = 1.25f;
		}
		if (!shipTex.is_valid()) shipTex = shipTexFor(shipImg, &shipK);
		const float SHIP_VIS = 5.4f;   // طول الطائرة المرسومة = 5.4 × نصف قطر الطائرة (الحجم القديم كان 2.2) — غيّر الرقم للتكبير/التصغير
		if (shipTex.is_valid()) {
			float len = sc * SHIP_VIS * shipK;
			if (sp.ship.moveFrac > 0.1f) {   // لهب المحركات (3 محركات بعد شراء المحرك الثالث)
				float fl = (1.0f + 0.3f * std::sin(clock * 40)) * (dash ? 2.2f : 1.0f);
				int ne = sp.plane >= 0 ? nj::PLANES[sp.plane].engines : (shipImg >= 4 ? 3 : 2);
				for (int e = 0; e < ne; e++) {
					float ey = ne == 1 ? 0.0f : (ne == 3 ? 0.52f * (float)(e - 1) : (e == 0 ? -0.45f : 0.45f));
					std::vector<Vector2> fp = {rot(-2.45f, ey + 0.2f), rot(-2.45f - 1.1f * fl, ey), rot(-2.45f, ey - 0.2f)};
					polyFill(fp, Color(1, 0.6f, 0.2f, 0.85f), Color(0, 0, 0, 0), 1);
				}
			}
			Vector2 ts = shipTex->get_size();
			float th = len * ts.y / std::max(1.0f, ts.x);
			Color mod = blinkOff ? Color(1, 1, 1, 0.3f) : (pi == myi ? Cc(nj::SHIP_COLORS[prof.shipColor].argb) : Color(1, 1, 1, 1));
			if (stealth) mod.a = 0.35f;
			draw_set_transform(c, sp.ship.ang, Vector2(1, 1));
			draw_texture_rect(shipTex, Rect2(Vector2(-len * 0.5f, -th * 0.5f), Vector2(len, th)), false, mod);
			draw_set_transform(Vector2(0, 0), 0, Vector2(1, 1));
		} else {   // احتياطي: الشكل القديم إذا الصورة غير موجودة
			if (sp.ship.moveFrac > 0.1f) {
				std::vector<Vector2> fl = {rot(-0.7f, 0.35f), rot(-1.5f - 0.4f * std::sin(clock * 40), 0), rot(-0.7f, -0.35f)};
				polyFill(fl, Color(1, 0.6f, 0.2f, 0.85f), Color(0, 0, 0, 0), 1);
			}
			std::vector<Vector2> body = {rot(1.3f, 0), rot(-0.9f, 0.95f), rot(-0.45f, 0), rot(-0.9f, -0.95f)};
			polyFill(body, blinkOff ? Color(1, 1, 1, 0.3f) : pc * Color(0.65f, 0.65f, 0.65f, 1), blinkOff ? Color(1, 1, 1, 0.3f) : Color(1, 1, 1), 2.5f * u);
			draw_circle(c, sc * 0.22f, Color(0.8f, 0.95f, 1, 0.9f));
		}
		if (sp.ship.sh > 0) draw_arc(c, sc * (shipTex.is_valid() ? 3.0f : 1.6f), 0, TAU, 40, Color(0.4f, 0.7f, 1, 0.25f + 0.5f * (sp.ship.sh / std::max(1.0f, sp.ship.maxSh))), 3 * u);
		if (r.np > 1) {   // who is who: white ring + arrow for me, green (friend) or red (rival) for the other
			bool mine = pi == myi;
			Color tag = mine ? Color(1, 1, 1, 0.9f) : (r.mode == GM_PVP ? Color(1, 0.3f, 0.3f, 0.95f) : Color(0.4f, 1, 0.5f, 0.95f));
			draw_arc(c, sc * 3.4f, 0, TAU, 40, Color(tag.r, tag.g, tag.b, 0.5f), 2 * u);
			std::vector<Vector2> ar = {c + Vector2(0, -sc * 3.8f), c + Vector2(-9 * u, -sc * 4.4f), c + Vector2(9 * u, -sc * 4.4f)};
			polyFill(ar, tag, Color(0, 0, 0, 0), 1);
		}
	}

	// fx
	for (auto &f : r.fx) {
		float k = f.t / f.life;
		float al = 1.0f - k;
		if (f.kind == FX_RING) draw_arc(SP(f.a), f.size * ws * (0.2f + 0.8f * k), 0, TAU, 40, Cc(f.col, al), 4 * u * al + 1);
		else if (f.kind == FX_FLASH) draw_circle(SP(f.a), f.size * ws * (1.0f + k), Cc(f.col, al * 0.7f));
		else if (f.kind == FX_SPARK) draw_circle(SP(f.a), f.size * ws, Cc(f.col, al));
		else if (f.kind == FX_LINE) {
			Vector2 a = SP(f.a), b = SP(f.b);
			PackedVector2Array pa;
			pa.push_back(a);
			for (int i = 1; i < 6; i++) {
				Vector2 p = a.lerp(b, (float)i / 6.0f);
				pa.push_back(p + Vector2((float)((i * 37 + (int)(f.t * 500)) % 30) - 15.0f, 0) * ws);
			}
			pa.push_back(b);
			draw_polyline(pa, Cc(f.col, al), f.size * ws);
			draw_polyline(pa, Color(1, 1, 1, al), f.size * 0.4f * ws);
		} else if (f.kind == FX_TEXT) text(f.txt, SP(f.a).x, SP(f.a).y, f.size * u, Cc(f.col, std::min(1.0f, al * 2.0f)), 1, true);
	}
	if (r.pl[myi].hitFlash > 0) draw_rect(Rect2(0, 0, W, H), Color(1, 0, 0, 0.25f * (r.pl[myi].hitFlash / 0.25f)), true);

	// joystick
	if (joyId >= 0) {
		draw_arc(joyCenter, 70 * u, 0, TAU, 40, Color(1, 1, 1, 0.4f), 3 * u);
		draw_circle(joyPos, 30 * u, Color(1, 1, 1, 0.35f));
	}
}

void NujoomGame::drawHud() {
	using namespace nj;
	Run &r = *run;
	const Player &mp = r.pl[me()];
	float m = 16 * u;
	float bw = std::min(W * 0.45f, 420.0f * u);
	bar(Rect2(m, m, bw, 26 * u), mp.ship.hp / std::max(1.0f, mp.ship.maxHp), Color(0.9f, 0.25f, 0.3f), Color(0, 0, 0, 0.55f));
	text(std::to_string((int)std::ceil(std::max(0.0f, mp.ship.hp))) + "/" + std::to_string((int)mp.ship.maxHp), m + 8 * u, m + 21 * u, 20 * u, Color(1, 1, 1), 0, false);
	if (mp.ship.maxSh > 0) bar(Rect2(m, m + 32 * u, bw, 18 * u), mp.ship.sh / std::max(1.0f, mp.ship.maxSh), Color(0.3f, 0.6f, 1), Color(0, 0, 0, 0.55f));
	text(mmss(r.t), W * 0.5f, m + 34 * u, 38 * u, Color(1, 1, 1));
	text(formatYen(mp.yenEarned), W - m, m + 30 * u, 30 * u, Color(1, 0.9f, 0.4f), 2);
	text("القتلى " + std::to_string(mp.kills), W - m, m + 62 * u, 24 * u, Color(0.8f, 0.9f, 1), 2);
	button(B_PAUSE, Rect2(W - 100 * u, 96 * u, 84 * u, 70 * u), "||", Color(0.25f, 0.3f, 0.45f), 34);
	if (mp.plane >= 0) {   // زر ميزة الطائرة (يمتلي كل ما يقرب الجاهزية)
		const PlaneDef &pd = PLANES[mp.plane];
		bool heal = pd.ability == AB_HEAL;
		bool active = !heal && mp.abT > 0;
		bool ready = heal ? (mp.abKills >= 10 && mp.ship.hp < mp.ship.maxHp) : (mp.abCd <= 0 && mp.abT <= 0);
		float frac = heal ? std::min(1.0f, (float)mp.abKills / 10.0f) : (active ? mp.abT / std::max(0.1f, pd.dur) : (mp.abCd > 0 ? 1.0f - mp.abCd / std::max(0.1f, pd.cd) : 1.0f));
		Rect2 br(W - 200 * u, H - 380 * u, 170 * u, 170 * u);
		btns.push_back({B_ABILITY, br});
		Color pc = Cc(pd.col);
		draw_rect(br, Color(0, 0, 0, 0.55f), true);
		draw_rect(br.grow(-3.0f * u), Color(0.08f, 0.1f, 0.18f, 0.9f), true);
		float inH = br.size.y - 6.0f * u;
		draw_rect(Rect2(br.position.x + 3.0f * u, br.position.y + 3.0f * u + inH * (1.0f - frac), br.size.x - 6.0f * u, inH * frac), Color(pc.r, pc.g, pc.b, ready ? 0.85f : 0.4f), true);
		draw_rect(br, Color(1, 1, 1, ready ? 0.5f + 0.4f * std::sin(clock * 8.0f) : 0.3f), false, 3.0f * u);
		text("الميزة", br.position.x + br.size.x * 0.5f, br.position.y + br.size.y * 0.42f, 30 * u, Color(1, 1, 1));
		std::string st = heal ? std::to_string(std::min(10, mp.abKills)) + "/10" : (active ? "فعّالة" : (mp.abCd > 0 ? std::to_string((int)std::ceil(mp.abCd)) : "جاهزة"));
		text(st, br.position.x + br.size.x * 0.5f, br.position.y + br.size.y * 0.76f, 30 * u, Color(1, 1, 0.8f));
	}
	if (r.boss.active) {
		bar(Rect2(W * 0.5f - 260 * u, m + 62 * u, 520 * u, 22 * u), r.boss.hp / r.boss.maxhp, Color(0.9f, 0.2f, 0.4f), Color(0, 0, 0, 0.6f));
		text("الزعيم", W * 0.5f, m + 112 * u, 24 * u, Color(1, 0.6f, 0.7f));
	}
	if (r.bossAnnounce > 0) text("! تحذير: زعيم !", W * 0.5f, H * 0.3f, 64 * u, Color(1, 0.3f, 0.3f, std::min(1.0f, r.bossAnnounce)));
	if (r.np > 1) {
		const Player &op = r.pl[1 - me()];
		bool pvp = r.mode == GM_PVP;
		float fy = m + 60 * u;
		Color tc = pvp ? Color(1, 0.55f, 0.5f) : Color(0.6f, 1, 0.7f);
		std::string lbl = pvp ? "الخصم" : "الصديق";
		if (op.dead) lbl += op.quit ? ": انسحب" : ": سقط";
		else if (peerLeft) lbl += ": غادر";
		text(lbl, m, fy + 18 * u, 22 * u, tc, 0, false);
		if (!op.dead) {
			float fr = op.ship.maxHp > 0 ? op.ship.hp / op.ship.maxHp : 0;
			bar(Rect2(m, fy + 26 * u, bw * 0.7f, 14 * u), fr, pvp ? Color(0.95f, 0.35f, 0.3f) : Color(0.3f, 0.9f, 0.5f), Color(0, 0, 0, 0.55f));
			text(std::to_string(op.kills) + " قتيل", m, fy + 62 * u, 20 * u, Color(0.8f, 0.95f, 1), 0, false);
		}
		if (mp.dead) text("سقطت - تتفرج على صديقك", W * 0.5f, H * 0.25f, 36 * u, Color(1, 0.8f, 0.5f));
	}
	// weapon / passive slots
	float is = 70 * u, x = m, y = H - m - is;
	for (auto &w : mp.weapons) {
		icon(weaponIcon(w.id), Rect2(x, y, is, is));
		for (int k = 0; k < w.lvl; k++) draw_circle(Vector2(x + 10 * u + (float)k * 12 * u, y + is + 2 * u), 4 * u, Color(1, 0.85f, 0.2f));
		x += is + 10 * u;
	}
	x = m;
	y -= is * 0.7f + 16 * u;
	float ps = is * 0.6f;
	for (int p = 0; p < P_COUNT; p++)
		if (mp.pas[p] > 0) {
			icon(passiveIcon(p), Rect2(x, y, ps, ps));
			if (mp.pas[p] > 1) text("x" + std::to_string(mp.pas[p]), x + ps - 4 * u, y + ps, 18 * u, Color(1, 1, 0.5f), 2);
			x += ps + 8 * u;
		}
}

void NujoomGame::drawChoose() {
	nj::Run &r = *run;
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.7f), true);
	text("اختر ترقية", W * 0.5f, H * 0.12f, 60 * u, Color(1, 0.9f, 0.4f));
	const int mi = me();
	int n = (int)r.pl[mi].options.size();
	float cw = std::min(W - 40 * u, 760.0f * u);
	float ch = std::min(190.0f * u, (H * 0.8f) / (float)std::max(1, n) - 14 * u);
	float y = H * 0.18f;
	for (int i = 0; i < n; i++) {
		const nj::Option &o = r.pl[mi].options[i];
		Rect2 rc(W * 0.5f - cw * 0.5f, y, cw, ch);
		btns.push_back({B_CHOOSE + i, rc});
		bool evo = o.kind == nj::OK_EVOLVE;
		panel(rc, Color(0.05f, 0.08f, 0.2f, 0.92f), evo ? Color(1, 0.8f, 0.2f) : Color(0.5f, 0.7f, 1, 0.8f));
		bool isP = false;
		int ic = r.optionIcon(mi, o, isP);
		float is = ch - 30 * u;
		if (ic >= 0) icon(isP ? passiveIcon(ic) : weaponIcon(ic), Rect2(rc.position.x + 16 * u, rc.position.y + 15 * u, is, is));
		const char *tag = o.kind == nj::OK_NEW_WEAPON ? "سلاح جديد" : o.kind == nj::OK_LEVEL ? "ترقية" : o.kind == nj::OK_NEW_PASSIVE ? "قدرة جديدة" : o.kind == nj::OK_STACK ? "تعزيز" : o.kind == nj::OK_EVOLVE ? "تطوير!" : "إصلاح";
		float tx = rc.position.x + is + 36 * u;
		text(tag, tx, rc.position.y + 38 * u, 24 * u, evo ? Color(1, 0.85f, 0.3f) : Color(0.5f, 0.9f, 0.6f), 0);
		text(r.optionTitle(mi, o), tx, rc.position.y + 38 * u + 40 * u, 34 * u, Color(1, 1, 1), 0);
		text(r.optionDesc(mi, o), tx, rc.position.y + 38 * u + 76 * u, 22 * u, Color(0.8f, 0.85f, 0.95f), 0);
		y += ch + 14 * u;
	}
}

void NujoomGame::drawPause() {
	draw_rect(Rect2(0, 0, W, H), Color(0, 0, 0, 0.65f), true);
	text("متوقف مؤقتاً", W * 0.5f, H * 0.3f, 64 * u, Color(1, 1, 1));
	button(B_RESUME, Rect2(W * 0.5f - 260 * u, H * 0.4f, 520 * u, 110 * u), "استئناف", Color(0.15f, 0.6f, 0.3f), 42);
	button(B_RETREAT, Rect2(W * 0.5f - 260 * u, H * 0.4f + 140 * u, 520 * u, 110 * u), "انسحاب", Color(0.7f, 0.25f, 0.25f), 42);
}
