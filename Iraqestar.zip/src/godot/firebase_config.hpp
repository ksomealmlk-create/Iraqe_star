#pragma once
// إعدادات Firebase (مشروع iraqe-star). مفتاح الـ API هنا عام وليس سرّاً، الحماية الحقيقية من قواعد Firestore.
// لتعطيل كل ميزات Firebase: غيّر FB_ENABLED إلى 0.
#define FB_ENABLED 1
#define FB_PROJECT_ID "iraqe-star"
#define FB_API_KEY "AIzaSyA1-sgUsfQ2pYZ9ZTGcq7FQxd5jvSek6h4"
// رقم نسخة اللعبة الحالية. لازم يساوي version/code في export_presets.cfg.
// إذا latestVersion في Firestore أكبر منه يطلع للاعب إشعار تحديث.
#define FB_APP_VERSION 1
