#include "run.hpp"

#include <cstring>

namespace nj {

static const float ASTEROID_R[3] = {15, 30, 50};
static const float ASTEROID_HP[3] = {8, 22, 50};
static const float ASTEROID_CONTACT[3] = {6, 12, 20};

void Run::initPlayer(int i, Profile *prof, int pilotIdx, const int *store, V2 pos) {
	Player &p = pl[i];
	p.pilot = (pilotIdx < 0 || pilotIdx >= N_PILOT) ? 0 : pilotIdx;
	p.prof = prof;
	for (int k = 0; k < N_STORE; k++) p.store[k] = store ? store[k] : prof->storeLevel[k];
	p.ship.p = pos;
	p.ship.maxHp = 50 + p.storeValue(0);
	p.ship.hp = p.ship.maxHp;
	p.ship.maxSh = 50 + p.storeValue(1);
	p.ship.sh = p.ship.maxSh;
	p.pas[PILOTS[p.pilot].passive] = 1;
	if (p.pas[P_GLASS] > 0) { p.ship.maxSh = 0; p.ship.sh = 0; }
	cur = &p;
	addWeapon(W_PULSE);
}

Run::Run(Profile *prof, int pilotIdx, uint64_t seed, GameMode m, int pilot1, const int *store1) : P(prof), mode(m), rng(seed) {
	np = (m == GM_SOLO) ? 1 : 2;
	if (!P) P = &scratch_[0];
	initPlayer(0, P, pilotIdx, nullptr, np == 2 ? V2(-110, 0) : V2(0, 0));
	if (np == 2) {
		initPlayer(1, &scratch_[1], pilot1, store1, V2(110, 0));
		viewW = MP_VIEW_W;
		viewH = 2800.0f;   // a bit taller than the logical view: covers tall phones when spawning
	}
	cur = &pl[0];
	asteroidTimer = 0.4f;
	nextBoss = (mode == GM_PVP) ? 1e9f : 180.0f;   // duel: no boss
	camCenter = centerTarget();
}

int Run::passivesOwned() const {
	int n = 0;
	for (int i = 0; i < P_COUNT; i++) n += cur->pas[i] > 0 ? 1 : 0;
	return n;
}

float Run::dmgMult() const {
	float m = 1.0f + cur->storeValue(3);
	if (cur->pas[P_GLASS] > 0) m *= 1.0f + 0.35f * cur->pas[P_GLASS];
	if (cur->pas[P_MOMENTUM] > 0) m *= 1.0f + 0.08f * cur->pas[P_MOMENTUM] * cur->ship.moveFrac;
	return m;
}

float Run::asteroidSpeedScale() const { return std::min(7.0f, 1.0f + 0.15f * (t / 60.0f)); }

bool Run::anyChoosing() const {
	for (int i = 0; i < np; i++) if (pl[i].choosing) return true;
	return false;
}

int Run::aliveCount() const {
	int n = 0;
	for (int i = 0; i < np; i++) if (!pl[i].dead) n++;
	return n;
}

V2 Run::centerTarget() const {
	V2 sum;
	int n = 0;
	for (int i = 0; i < np; i++)
		if (!pl[i].dead) { sum += pl[i].ship.p; n++; }
	return n > 0 ? sum / (float)n : camCenter;
}

void Run::updateCamera(float dt, bool snap) {
	V2 tgt = centerTarget();
	if (snap || np == 1 || aliveCount() == np) camCenter = tgt;
	else camCenter += (tgt - camCenter) * std::min(1.0f, dt * 4.0f);
}

int Run::nearestPlayer(V2 p) const {
	int best = -1;
	float bd = 1e30f;
	for (int i = 0; i < np; i++) {
		if (pl[i].dead) continue;
		float d = (pl[i].ship.p - p).len2();
		if (d < bd) { bd = d; best = i; }
	}
	return best;
}

// ------------------------------------------------------------------ main update
void Run::update(float dt) {
	if (over) return;
	if (dt > 0.05f) dt = 0.05f;
	if (dt <= 0) return;
	if (np > 1) {
		// don't let a slow chooser freeze the other player forever
		for (int i = 0; i < np; i++)
			if (pl[i].choosing) {
				pl[i].chooseT += dt;
				if (pl[i].chooseT > 12.0f) choose(i, 0);
			}
	}
	if (anyChoosing()) return;
	t += dt;
	float m = t / 60.0f;
	diff = m > 8.0f ? 4.0f + 0.4f * (m - 8.0f) : 1.0f + 0.75f * m - 0.046875f * m * m;
	if (bossAnnounce > 0) bossAnnounce -= dt;
	for (int i = 0; i < np; i++) if (pl[i].hitFlash > 0) pl[i].hitFlash -= dt;

	updateShips(dt);
	if (over) return;

	asteroidTimer -= dt;
	if (asteroidTimer <= 0) {
		if (asteroids.size() < (size_t)(34 + 6 * diff)) spawnAsteroid();
		asteroidTimer = std::max(0.3f, 2.0f / diff) * rng.range(0.7f, 1.3f);
	}
	enemyTimer -= dt;
	if (enemyTimer <= 0 && t > 5.0f) {
		if (!boss.active && enemies.size() < (size_t)(3 + 2 * diff)) spawnEnemy();
		enemyTimer = std::max(2.0f, 9.0f / diff) * rng.range(0.8f, 1.2f);
	}
	if (!boss.active && t >= nextBoss) spawnBoss();

	updateAsteroids(dt);
	updateEnemies(dt);
	updateBoss(dt);
	buildTargets();
	updatePassives(dt);
	updateWeapons(dt);
	updateShots(dt);
	updateEBullets(dt);
	updateMines(dt);
	updateBooms(dt);
	updateZones(dt);
	updatePickups(dt);
	updateCompanions(dt);
	reap();
	updateFx(dt);
	cur = &pl[0];

	achTimer -= dt;
	if (achTimer <= 0) {
		achTimer = 1.0f;
		checkMeta();
	}
}

void Run::checkMeta() {
	for (int i = 0; i < np; i++) {
		Player &p = pl[i];
		Profile *pf = p.prof;
		pf->bestSurvival = std::max(pf->bestSurvival, (int)t);
		pf->maxKillsRun = std::max(pf->maxKillsRun, p.kills);
		pf->bestStreak = std::max(pf->bestStreak, p.bestStreak);
		pf->bestFlight = std::max(pf->bestFlight, (int)p.flightT);
		if (i != 0) continue;   // achievement toasts are only for the host's own profile
		for (int a : pf->checkAchievements()) toast(std::string("إنجاز جديد: ") + ACHS[a].titleAr);
		for (int a : pf->refreshPilots()) {
			toast(std::string("انضم طيار جديد: ") + PILOTS[a].callsign);
			sfxEvent(S_UPGRADE);
		}
	}
}

void Run::finish(bool wasDeath) {
	if (over) return;
	over = true;
	died = wasDeath;
	for (int i = 0; i < np; i++) {
		Player &p = pl[i];
		p.prof->yen += p.yenEarned;
		p.prof->totalYenEarned += p.yenEarned;
		if (np == 1 ? wasDeath : (p.dead && !p.quit)) p.prof->totalDeaths++;
	}
	checkMeta();
}

void Run::checkEnd() {
	if (over) return;
	if (np == 1) {
		if (pl[0].dead) finish(true);
		return;
	}
	if (mode == GM_PVP) {
		bool a0 = !pl[0].dead, a1 = !pl[1].dead;
		if (a0 && a1) return;
		winner = a0 ? 0 : (a1 ? 1 : -1);
		finish(true);
	} else if (pl[0].dead && pl[1].dead) {
		finish(true);
	}
}

void Run::retreat(int pi) {
	if (over) return;
	if (np == 1) { finish(false); return; }
	if (pi < 0 || pi >= np || pl[pi].dead) return;
	Player &p = pl[pi];
	p.dead = true;
	p.quit = true;
	p.choosing = false;
	p.options.clear();
	addFx(FX_RING, p.ship.p, V2(), 0.6f, 160, 0xFFAAAAAA);
	checkEnd();
}

// ------------------------------------------------------------------ ships
void Run::updateShips(float dt) {
	for (int i = 0; i < np; i++) {
		if (pl[i].dead) continue;
		cur = &pl[i];
		float spd = 300.0f * (1.0f + cur->storeValue(2));
		V2 in = cur->moveIn;
		float mag = std::min(1.0f, in.len());
		V2 want = mag > 0.01f ? in.norm() * (spd * mag) : V2(0, 0);
		V2 dv = want - cur->ship.v;
		float acc = (mag > 0.01f ? 800.0f : 400.0f) * dt * 2.2f;
		float dl = dv.len();
		if (dl > acc) dv = dv / dl * acc;
		cur->ship.v += dv;
		cur->ship.p += cur->ship.v * dt;
		float spdNow = cur->ship.v.len();
		cur->ship.moveFrac = lerpf(cur->ship.moveFrac, clampf(spdNow / spd, 0, 1), std::min(1.0f, dt * 6));
		if (spdNow > 30) {
			float a = cur->ship.v.angle();
			float d = std::fmod(a - cur->ship.ang + 3 * PI, TAU) - PI;
			cur->ship.ang += d * std::min(1.0f, dt * 10);
		}
		if (cur->ship.invuln > 0) cur->ship.invuln -= dt;
		if (cur->ship.shDelay > 0) cur->ship.shDelay -= dt;
		else if (cur->ship.sh < cur->ship.maxSh) cur->ship.sh = std::min(cur->ship.maxSh, cur->ship.sh + 2.5f * dt);
		if (cur->revengeT > 0) cur->revengeT -= dt;
		if (cur->ship.moveFrac > 0.15f) { cur->stillT = 0; cur->flightT += dt; }
		else { cur->stillT += dt; if (cur->stillT > 1.0f) cur->flightT = 0; }
	}
	cur = &pl[0];

	// shared screen: the two ships can't drift further apart than the visible area
	if (np == 2 && !pl[0].dead && !pl[1].dead) {
		Ship &a = pl[0].ship, &b = pl[1].ship;
		float dx = b.p.x - a.p.x, dy = b.p.y - a.p.y;
		if (std::fabs(dx) > MP_TETHER_X) {
			float ex = (std::fabs(dx) - MP_TETHER_X) * 0.5f * (dx > 0 ? 1.0f : -1.0f);
			a.p.x += ex;
			b.p.x -= ex;
			float mv = (a.v.x + b.v.x) * 0.5f;
			a.v.x = mv;
			b.v.x = mv;
		}
		if (std::fabs(dy) > MP_TETHER_Y) {
			float ey = (std::fabs(dy) - MP_TETHER_Y) * 0.5f * (dy > 0 ? 1.0f : -1.0f);
			a.p.y += ey;
			b.p.y -= ey;
			float mv = (a.v.y + b.v.y) * 0.5f;
			a.v.y = mv;
			b.v.y = mv;
		}
	}
	updateCamera(dt, false);
}

void Run::damagePlayer(int i, float d, float invuln) {
	if (i < 0 || i >= np) return;
	Player *save = cur;
	cur = &pl[i];
	damageShip(d, invuln);
	cur = save;
}

void Run::damageShip(float d, float invuln) {
	if (over || cur->dead || cur->ship.invuln > 0 || d <= 0) return;
	cur->ship.invuln = invuln;
	cur->prof->totalDamageTaken += (int)std::ceil(d);
	cur->streak = 0;
	cur->flightT = 0;
	cur->hitFlash = 0.25f;
	if (cur->pas[P_REVENGE] > 0) cur->revengeT = 2.5f + 0.7f * cur->pas[P_REVENGE];
	Ship &sh = cur->ship;
	if (sh.sh > 0) {
		sh.sh -= d;
		if (sh.sh <= 0) {
			sh.hp += sh.sh; // overflow
			sh.sh = 0;
			sfxEvent(S_SHIELD_BREAK);
		} else sfxEvent(S_SHIELD_HIT);
		sh.shDelay = 2.0f;
	} else {
		sh.hp -= d;
		sh.shDelay = 2.0f;
		sfxEvent(S_PLAYER_HIT);
	}
	addFx(FX_RING, sh.p, V2(), 0.3f, 60, 0xFFFF4444);
	for (int i = 0; i < 5; i++) {
		float a = rng.range(0, TAU);
		addFx(FX_SPARK, sh.p, V2(), 0.4f, 3, 0xFFFF8866, V2::fromAngle(a) * rng.range(80, 220));
	}
	if (sh.hp <= 0) die();
}

void Run::die() {
	Player &p = *cur;
	if (p.pas[P_PHOENIX] > 0 && !p.revived) {
		p.revived = true;
		p.ship.hp = p.ship.maxHp * std::min(1.0f, 0.5f + 0.1f * p.pas[P_PHOENIX]);
		p.ship.sh = p.ship.maxSh;
		p.ship.invuln = 2.5f;
		sfxEvent(S_REVIVE);
		explode(p.ship.p, 700, 220, -1, 0xFFFFAA33, false);
		addFx(FX_RING, p.ship.p, V2(), 0.8f, 700, 0xFFFFCC44);
		addFx(FX_TEXT, p.ship.p + V2(0, -70), V2(), 1.6f, 36, 0xFFFFDD55, V2(0, -30), "PHOENIX!");
		for (auto &b : ebullets) b.life = 0;
		return;
	}
	sfxEvent(S_PLAYER_DEATH);
	for (int i = 0; i < 40; i++) {
		float a = rng.range(0, TAU);
		addFx(FX_SPARK, p.ship.p, V2(), rng.range(0.5f, 1.2f), rng.range(2, 6), 0xFF66FF88, V2::fromAngle(a) * rng.range(60, 420));
	}
	addFx(FX_RING, p.ship.p, V2(), 0.9f, 220, 0xFFFFFFFF);
	p.dead = true;
	p.ship.hp = 0;
	p.choosing = false;
	p.options.clear();
	checkEnd();
}

// ------------------------------------------------------------------ spawning
static Asteroid makeAsteroid(Rng &rng, int size, int type, float m) {
	Asteroid a;
	a.size = size;
	a.type = type;
	a.r = ASTEROID_R[size];
	float mult = 1.0f + 0.05f * m;
	if (type == 2) mult *= 3.0f;
	else if (type == 1) mult *= 1.3f;
	else if (type == 3) mult *= 0.8f;
	a.maxhp = a.hp = ASTEROID_HP[size] * mult;
	a.seed = rng.next();
	a.rot = rng.range(0, TAU);
	a.rv = rng.range(-1.5f, 1.5f);
	return a;
}

void Run::spawnAsteroid() {
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 110.0f;
	float ang = rng.range(0, TAU);
	V2 ctr = centerTarget();
	V2 pos = ctr + V2::fromAngle(ang) * R;
	V2 target = ctr + V2(rng.range(-0.5f, 0.5f) * viewW, rng.range(-0.5f, 0.5f) * viewH);
	float f = rng.f();
	int size = f < 0.28f ? 0 : (f < 0.68f ? 1 : 2);
	int type = 0;
	if (rng.chance(0.28f)) {
		int avail[5], n = 0;
		if (t >= 60) avail[n++] = 1;
		if (t >= 120) avail[n++] = 2;
		if (t >= 180) avail[n++] = 3;
		if (t >= 240) avail[n++] = 4;
		if (t >= 300) avail[n++] = 5;
		if (n > 0) type = avail[rng.i(n)];
	}
	Asteroid a = makeAsteroid(rng, size, type, t / 60.0f);
	a.p = pos;
	a.v = (target - pos).norm() * 80.0f * asteroidSpeedScale() * rng.range(0.7f, 1.3f);
	a.uid = nextUid++;
	asteroids.push_back(a);
}

void Run::splitAsteroid(const Asteroid &a) {
	if (a.size == 0) return;
	int n = a.type == 1 ? 3 : 2;
	if (a.size == 2 && rng.chance(0.4f)) n++;
	for (int i = 0; i < n; i++) {
		Asteroid c = makeAsteroid(rng, a.size - 1, a.type == 3 ? 0 : a.type, t / 60.0f);
		float ang = rng.range(0, TAU);
		c.p = a.p + V2::fromAngle(ang) * (a.r * 0.4f);
		c.v = a.v * 0.6f + V2::fromAngle(ang) * rng.range(40, 110);
		c.uid = nextUid++;
		asteroids.push_back(c);
	}
}

void Run::spawnEnemy() {
	int avail[N_ENEMY], w[N_ENEMY], n = 0, total = 0;
	for (int i = 0; i < N_ENEMY; i++)
		if (ENEMIES[i].unlock <= t) { avail[n] = i; w[n] = n; n++; }
	if (n == 0) return;
	for (int i = 0; i < n; i++) { w[i] = n - i; total += w[i]; }
	int roll = rng.i(total), pick = 0;
	for (int i = 0; i < n; i++) { roll -= w[i]; if (roll < 0) { pick = i; break; } }
	int type = avail[pick];
	const EnemyDef &d = ENEMIES[type];
	Enemy e;
	e.type = type;
	float hpScale = 1.0f + 0.12f * (diff - 1.0f);
	e.maxhp = e.hp = d.hp * hpScale;
	e.r = d.radius;
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 80.0f;
	e.p = centerTarget() + V2::fromAngle(rng.range(0, TAU)) * R;
	e.fire = rng.range(0.6f, d.fire);
	e.dir = rng.chance(0.5f) ? 1 : -1;
	e.aux = rng.range(1.5f, 3.5f);
	e.uid = nextUid++;
	enemies.push_back(e);
}

void Run::spawnBoss() {
	boss = Boss();
	boss.active = true;
	boss.index = bossKills;
	boss.maxhp = boss.hp = 1400.0f + 1100.0f * boss.index;
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 150.0f;
	boss.p = centerTarget() + V2::fromAngle(rng.range(0, TAU)) * R;
	boss.uid = nextUid++;
	boss.fireA = 2.0f;
	boss.fireB = 3.5f;
	boss.dashT = 6.0f;
	bossAnnounce = 3.0f;
	sfxEvent(S_BOSS);
	toast("تحذير: زعيم قادم!");
}

// ------------------------------------------------------------------ entity updates
void Run::updateAsteroids(float dt) {
	float despawn = (0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 110.0f) * 2.3f;
	float m = t / 60.0f;
	for (auto &a : asteroids) {
		float sp = 1.0f;
		if (a.slowT > 0) { a.slowT -= dt; sp = 1.0f - a.slowAmt; }
		if (a.type == 4) {
			int ti = nearestPlayer(a.p);
			if (ti >= 0) {
				V2 to = (pl[ti].ship.p - a.p).norm();
				a.v += to * 70.0f * dt;
				float l = a.v.len(), mx = 90.0f * asteroidSpeedScale() + 70.0f;
				if (l > mx) a.v = a.v / l * mx;
			}
		}
		a.p += a.v * (dt * sp);
		a.rot += a.rv * dt;
		if (a.flash > 0) a.flash -= dt;
		if (a.type == 5) {
			a.trailT -= dt;
			if (a.trailT <= 0) {
				a.trailT = 0.4f;
				Zone z;
				z.p = a.p; z.r = 26; z.life = z.maxLife = 3.0f; z.dps = 7; z.kind = ZK_GAS; z.hostile = true; z.col = 0xFF44FF44;
				if (zones.size() < 120) zones.push_back(z);
			}
		}
		for (int i = 0; i < np; i++) {
			if (pl[i].dead || a.hp <= 0) continue;
			Ship &sh = pl[i].ship;
			if (dist(a.p, sh.p) < a.r + sh.r * 0.85f) {
				V2 n = (a.p - sh.p).norm();
				if (n.len2() < 0.5f) n = V2(1, 0);
				damagePlayer(i, ASTEROID_CONTACT[a.size] * (1.0f + 0.05f * m), 0.8f);
				a.hp -= 22;
				a.flash = 0.15f;
				a.v = n * std::max(a.v.len(), 140.0f);
				sh.v -= n * 160.0f;
				a.p = sh.p + n * (a.r + sh.r);
			}
		}
	}
	asteroids.erase(std::remove_if(asteroids.begin(), asteroids.end(), [&](const Asteroid &a) {
		int ti = nearestPlayer(a.p);
		return ti >= 0 && dist(a.p, pl[ti].ship.p) > despawn;
	}), asteroids.end());
}

void Run::updateEnemies(float dt) {
	float despawn = (0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 80.0f) * 2.6f;
	float eScale = 1.0f + 0.10f * (diff - 1.0f);
	for (auto &e : enemies) {
		int ti = nearestPlayer(e.p);
		if (ti < 0) break;
		cur = &pl[ti];   // the ship this enemy is hunting
		const EnemyDef &d = ENEMIES[e.type];
		float sp = d.speed * (1.0f + 0.03f * (diff - 1.0f));
		if (e.slowT > 0) { e.slowT -= dt; sp *= 1.0f - e.slowAmt; }
		e.t += dt;
		if (e.flash > 0) e.flash -= dt;
		if (e.alpha < 1) e.alpha = std::min(1.0f, e.alpha + dt * 2.5f);
		V2 to = cur->ship.p - e.p;
		float dd = to.len();
		V2 dir = to.norm();
		V2 perp(-dir.y, dir.x);
		V2 dv;
		if (d.pattern == 10) { // rusher: charge, hit, retreat
			if (e.aux > 0) { e.aux -= dt; dv = dir * (-sp * 0.7f); }
			else {
				dv = dir * (sp * 1.5f);
				if (dd < e.r + cur->ship.r + 6) {
					damageShip(d.dmg * eScale, 0.8f);
					e.aux = 1.6f;
					cur->ship.v += dir * 120.0f;
				}
			}
		} else {
			e.aux -= dt;
			if (e.aux <= 0) {
				e.dir = -e.dir;
				e.aux = rng.range(1.5f, 3.5f);
				if (d.pattern == 0) e.v += perp * (float)e.dir * 420.0f; // juke dash
				if (d.pattern == 11) { // phantom blink
					e.p = cur->ship.p + V2::fromAngle(rng.range(0, TAU)) * d.range;
					e.alpha = 0.0f;
					addFx(FX_FLASH, e.p, V2(), 0.3f, 40, 0xFFFFFFFF);
				}
			}
			float radial = dd > d.range * 1.15f ? 1.0f : (dd < d.range * 0.75f ? -1.0f : 0.0f);
			dv = (dir * radial + perp * (0.8f * (float)e.dir)).norm() * sp;
		}
		e.v = e.v + (dv - e.v) * std::min(1.0f, dt * 4.0f);
		e.p += e.v * dt;
		e.ang = dir.angle();
		if (d.pattern != 10) {
			e.fire -= dt;
			if (e.fire <= 0 && dd < 900 && e.alpha > 0.8f) {
				enemyFire(e);
				e.fire = d.fire * rng.range(0.85f, 1.15f) / (1.0f + 0.04f * (diff - 1.0f));
			}
		}
		// body contact with any ship (the hunted one included)
		for (int i = 0; i < np; i++) {
			if (pl[i].dead || e.hp <= 0) continue;
			if (d.pattern == 10 && i == ti) continue; // rusher contact handled above
			Ship &sh = pl[i].ship;
			if (dist(e.p, sh.p) < e.r + sh.r * 0.85f) {
				V2 dir2 = (sh.p - e.p).norm();
				damagePlayer(i, d.dmg * 0.7f * eScale, 0.8f);
				sh.v -= dir2 * 150.0f;
				e.v = dir2 * -200.0f;
			}
		}
	}
	cur = &pl[0];
	enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [&](const Enemy &e) {
		int ti = nearestPlayer(e.p);
		return ti >= 0 && dist(e.p, pl[ti].ship.p) > despawn;
	}), enemies.end());
}

void Run::ebullet(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int kind, float expR) {
	if (ebullets.size() > 700) return;
	EBullet b;
	b.p = p; b.v = v; b.dmg = dmg; b.r = r; b.life = life; b.col = col; b.kind = kind; b.expR = expR;
	ebullets.push_back(b);
}

void Run::enemyFire(Enemy &e) {
	const EnemyDef &d = ENEMIES[e.type];
	float eScale = 1.0f + 0.10f * (diff - 1.0f);
	float dmg = d.dmg * eScale;
	V2 to = cur->ship.p - e.p;
	V2 dir = to.norm();
	float base = dir.angle();
	auto fan = [&](int n, float spread, float speed, float life, float r, uint32_t col) {
		for (int i = 0; i < n; i++) {
			float a = base + (n > 1 ? (i - (n - 1) * 0.5f) * spread / (n - 1) : 0.0f);
			ebullet(e.p + V2::fromAngle(a) * e.r, V2::fromAngle(a) * speed, dmg, r, life, col);
		}
	};
	switch (d.pattern) {
		case 0: fan(1, 0, 420, 3, 6, 0xFF66AAFF); break;
		case 1: { // leading shot
			float sp = 460;
			V2 aim = (cur->ship.p + cur->ship.v * (to.len() / sp) - e.p).norm();
			ebullet(e.p + aim * e.r, aim * sp, dmg, 6, 3, 0xFF66FF88);
			break;
		}
		case 2: fan(5, 0.7f, 380, 1.0f, 5, 0xFFFFAA44); break;
		case 3: {
			V2 perp(-dir.y, dir.x);
			ebullet(e.p + perp * 10.0f, dir * 400, dmg, 6, 3, 0xFF55EEFF);
			ebullet(e.p - perp * 10.0f, dir * 400, dmg, 6, 3, 0xFF55EEFF);
			break;
		}
		case 4: fan(1, 0, 540, 2.5f, 5, 0xFFFF8877); break;
		case 5: fan(2, 0.5f, 380, 3, 6, 0xFFFFE055); break;
		case 6: ebullet(e.p + dir * e.r, dir * 340, dmg, 9, 3, 0xFFCCFF44, 1, 85); break;
		case 7:
			for (int i = 0; i < 8; i++) {
				float a = (float)i * TAU / 8.0f + e.t;
				ebullet(e.p, V2::fromAngle(a) * 300, dmg, 5, 3, 0xFFCC77FF);
			}
			break;
		case 8: ebullet(e.p + dir * e.r, dir * 230, dmg * 1.4f, 15, 4, 0xFFFF5544, 2, 100); break;
		case 9: fan(3, 0.5f, 380, 3, 7, 0xFF8899FF); break;
		case 11: fan(2, 0.18f, 620, 2, 5, 0xFFFFFFFF); break;
		default: break;
	}
}

void Run::updateBoss(float dt) {
	if (!boss.active) return;
	Boss &b = boss;
	int ti = nearestPlayer(b.p);
	if (ti < 0) return;
	cur = &pl[ti];
	b.t += dt;
	if (b.flash > 0) b.flash -= dt;
	b.phase = b.hp < b.maxhp * 0.33f ? 2 : (b.hp < b.maxhp * 0.66f ? 1 : 0);
	V2 to = cur->ship.p - b.p;
	float dd = to.len();
	V2 dir = to.norm();
	V2 perp(-dir.y, dir.x);
	float bs = 1.0f + 0.15f * b.index;
	if (b.dashing > 0) {
		b.dashing -= dt;
		b.p += b.dashDir * 950.0f * dt;
	} else if (b.telegraph > 0) {
		b.telegraph -= dt;
		b.dashDir = dir;
		if (b.telegraph <= 0) b.dashing = 0.65f;
	} else {
		float radial = clampf((dd - 520.0f) / 200.0f, -1, 1);
		V2 dv = dir * (radial * 130.0f) + perp * (95.0f * (std::fmod(b.t, 8.0f) < 4.0f ? 1.0f : -1.0f));
		b.v = b.v + (dv - b.v) * std::min(1.0f, dt * 2.0f);
		b.p += b.v * dt;
		b.dashT -= dt;
		if (b.phase >= 1 && b.dashT <= 0 && dd < 1000) { b.telegraph = 0.8f; b.dashT = 7.0f; }
	}
	bossFire(dt);
	for (int i = 0; i < np; i++) {
		if (pl[i].dead || b.hp <= 0) continue;
		Ship &sh = pl[i].ship;
		if (dist(b.p, sh.p) < b.r + sh.r * 0.85f) {
			V2 dir2 = (sh.p - b.p).norm();
			damagePlayer(i, 25.0f * bs, 1.0f);
			sh.v -= dir2 * 260.0f;
		}
	}
	cur = &pl[0];
}

void Run::bossFire(float dt) {
	Boss &b = boss;
	if (b.telegraph > 0 || b.dashing > 0) return;
	float bs = 1.0f + 0.15f * b.index;
	V2 dir = (cur->ship.p - b.p).norm();
	float base = dir.angle();
	b.fireA -= dt;
	if (b.fireA <= 0) {
		b.fireA = 1.5f - 0.2f * b.phase;
		int n = 3 + 2 * (b.phase >= 2 ? 1 : 0);
		for (int i = 0; i < n; i++) {
			float a = base + (i - (n - 1) * 0.5f) * 0.22f;
			ebullet(b.p + V2::fromAngle(a) * b.r, V2::fromAngle(a) * 430, 9 * bs, 7, 3.5f, 0xFFFF6655);
		}
	}
	b.fireB -= dt;
	if (b.fireB <= 0) {
		b.fireB = 3.0f - 0.3f * b.phase;
		int n = 14 + 4 * b.phase;
		float off = rng.range(0, TAU);
		for (int i = 0; i < n; i++) {
			float a = off + (float)i * TAU / (float)n;
			ebullet(b.p, V2::fromAngle(a) * 250, 8 * bs, 7, 4.5f, 0xFFFFAA33);
		}
	}
	if (b.phase >= 1) {
		b.fireC -= dt;
		if (b.fireC <= 0) {
			b.fireC = 0.14f;
			b.spiral += 0.37f;
			for (int k = 0; k < (b.phase >= 2 ? 2 : 1); k++) {
				float a = b.spiral + (float)k * PI;
				ebullet(b.p, V2::fromAngle(a) * 300, 6 * bs, 6, 4.0f, 0xFFCC66FF);
			}
		}
	}
}

void Run::updateEBullets(float dt) {
	for (auto &b : ebullets) {
		b.p += b.v * dt;
		b.life -= dt;
		bool hit = false;
		if (b.life > 0) {
			for (int i = 0; i < np && !hit; i++) {
				if (pl[i].dead) continue;
				if (dist(b.p, pl[i].ship.p) < b.r + pl[i].ship.r * 0.7f) {
					if (b.kind != 0) explode(b.p, b.expR, b.dmg, -2, b.col, true);
					else damagePlayer(i, b.dmg, 0.25f);
					b.life = 0;
					hit = true;
				}
			}
		}
		if (!hit && b.life <= 0 && b.kind != 0) explode(b.p, b.expR, b.dmg, -2, b.col, true);
	}
	ebullets.erase(std::remove_if(ebullets.begin(), ebullets.end(), [](const EBullet &b) { return b.life <= 0; }), ebullets.end());
}

// ------------------------------------------------------------------ targets & damage
void Run::buildTargets() {
	tg.clear();
	for (size_t i = 0; i < asteroids.size(); i++)
		if (asteroids[i].hp > 0) tg.push_back({0, (int)i, asteroids[i].p, asteroids[i].r, asteroids[i].uid});
	for (size_t i = 0; i < enemies.size(); i++)
		if (enemies[i].hp > 0) tg.push_back({1, (int)i, enemies[i].p, enemies[i].r, enemies[i].uid});
	if (boss.active && boss.hp > 0) tg.push_back({2, 0, boss.p, boss.r, boss.uid});
	for (int i = 0; i < 2; i++) {
		int f = 1 - i;
		foeOk_[i] = mode == GM_PVP && np == 2 && !pl[i].dead && !pl[f].dead;
		if (foeOk_[i]) foeT_[i] = {3, f, pl[f].ship.p, pl[f].ship.r, -100 - f};
	}
}

const Tgt *Run::nearest(V2 from, float maxR, int skipUid) const {
	const Tgt *best = nullptr;
	float bd = maxR * maxR;
	for (const auto &x : tg) {
		if (x.uid == skipUid) continue;
		// prefer enemies/boss slightly over asteroids
		float d2 = (x.p - from).len2() * (x.kind == 0 ? 1.0f : 0.6f);
		if (d2 < bd) { bd = d2; best = &x; }
	}
	int ci = curIdx();
	if (ci >= 0 && ci < 2 && foeOk_[ci] && foeT_[ci].uid != skipUid) {   // pvp: the other pilot is the preferred target
		float d2 = (foeT_[ci].p - from).len2() * 0.4f;
		if (d2 < bd) { bd = d2; best = &foeT_[ci]; }
	}
	return best;
}

std::vector<const Tgt *> Run::nearestN(V2 from, float maxR, int n) const {
	std::vector<std::pair<float, const Tgt *>> v;
	for (const auto &x : tg) {
		float d2 = (x.p - from).len2() * (x.kind == 0 ? 1.0f : 0.6f);
		if (d2 < maxR * maxR) v.push_back({d2, &x});
	}
	int ci = curIdx();
	if (ci >= 0 && ci < 2 && foeOk_[ci]) {
		float d2 = (foeT_[ci].p - from).len2() * 0.4f;
		if (d2 < maxR * maxR) v.push_back({d2, &foeT_[ci]});
	}
	std::sort(v.begin(), v.end(), [](const std::pair<float, const Tgt *> &a, const std::pair<float, const Tgt *> &b) { return a.first < b.first; });
	std::vector<const Tgt *> out;
	for (int i = 0; i < (int)v.size() && i < n; i++) out.push_back(v[i].second);
	return out;
}

float Run::rollDamage(float base, bool &crit) {
	float crit_chance = 0.03f + cur->storeValue(4);
	crit = rng.chance(crit_chance);
	float d = base * dmgMult();
	if (crit) d *= 2.0f;
	return d;
}

void Run::damageText(V2 p, float dmg, bool crit) {
	if (fx.size() > 260) return;
	if (!crit && dmg < 6.0f) return;
	if (!crit && rng.chance(0.5f)) return;
	addFx(FX_TEXT, p + V2(rng.range(-12, 12), -18), V2(), 0.6f, crit ? 26.0f : 18.0f, crit ? 0xFFFFE04A : 0xFFFFFFFF, V2(0, -60), std::to_string((int)std::round(dmg)));
}

void Run::hitAsteroid(Asteroid &a, float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	a.hp -= d;
	a.flash = 0.1f;
	damageText(a.p, d, crit);
}
void Run::hitEnemy(Enemy &e, float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	e.hp -= d;
	e.flash = 0.1f;
	e.by = curIdx();
	damageText(e.p, d, crit);
}
void Run::hitBoss(float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	boss.hp -= d;
	boss.flash = 0.08f;
	boss.by = curIdx();
	damageText(boss.p, d, crit);
}
void Run::hitTarget(const Tgt &x, float dmg, int) {
	if (x.kind == 0) { if (x.idx < (int)asteroids.size()) hitAsteroid(asteroids[x.idx], dmg); }
	else if (x.kind == 1) { if (x.idx < (int)enemies.size()) hitEnemy(enemies[x.idx], dmg); }
	else if (boss.active) hitBoss(dmg);
}

void Run::pvpHit(int target, float dmg, float invuln) {
	if (mode != GM_PVP || target < 0 || target >= np || pl[target].dead) return;
	damagePlayer(target, dmg * dmgMult() * PVP_SCALE, invuln);
}

void Run::explode(V2 p, float r, float dmg, int wid, uint32_t col, bool hurtShip) {
	addFx(FX_RING, p, V2(), 0.35f, r, col);
	addFx(FX_FLASH, p, V2(), 0.2f, r * 0.45f, col);
	if (fx.size() < 300)
		for (int i = 0; i < 6; i++) addFx(FX_SPARK, p, V2(), 0.45f, 3, col, V2::fromAngle(rng.range(0, TAU)) * rng.range(60, 240));
	sfxEvent(S_EXPLOSION);
	if (dmg <= 0) return;
	if (hurtShip)
		for (int i = 0; i < np; i++)
			if (!pl[i].dead && dist(p, pl[i].ship.p) < r + pl[i].ship.r * 0.5f) damagePlayer(i, dmg, 0.4f);
	if (wid == -2) return; // enemy explosion: ships only
	for (auto &a : asteroids)
		if (a.hp > 0 && dist(a.p, p) < r + a.r) hitAsteroid(a, dmg);
	for (auto &e : enemies)
		if (e.hp > 0 && dist(e.p, p) < r + e.r) hitEnemy(e, dmg);
	if (boss.active && boss.hp > 0 && dist(boss.p, p) < r + boss.r) hitBoss(dmg);
	if (mode == GM_PVP && np == 2 && wid >= 0) { // a weapon blast also hurts the other pilot
		int v = 1 - curIdx();
		if (!pl[v].dead && dist(p, pl[v].ship.p) < r + pl[v].ship.r * 0.5f) pvpHit(v, dmg, 0.3f);
	}
}

void Run::addFx(int kind, V2 a, V2 b, float life, float size, uint32_t col, V2 v, const std::string &txt) {
	if (fx.size() > 420) return;
	Fx f;
	f.kind = kind; f.a = a; f.b = b; f.life = life; f.size = size; f.col = col; f.v = v; f.txt = txt;
	fx.push_back(f);
	if (np > 1 && !remote && fxOut.size() < 90) fxOut.push_back(f);
}

void Run::updateFx(float dt) {
	for (auto &f : fx) {
		f.t += dt;
		if (f.kind == FX_SPARK || f.kind == FX_TEXT) f.a += f.v * dt;
		if (f.kind == FX_SPARK) f.v *= 0.97f;
	}
	fx.erase(std::remove_if(fx.begin(), fx.end(), [](const Fx &f) { return f.t >= f.life; }), fx.end());
}

// ------------------------------------------------------------------ shots
Shot &Run::newShot(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int wid, int kind) {
	shots.emplace_back();
	Shot &s = shots.back();
	s.p = p; s.v = v; s.dmg = dmg; s.r = r; s.life = life; s.col = col; s.wid = wid; s.kind = kind; s.owner = curIdx();
	return s;
}

void Run::updateShots(float dt) {
	for (auto &s : shots) {
		cur = &pl[s.owner < np ? s.owner : 0];   // damage multipliers, crits etc. belong to the shooter
		s.life -= dt;
		if (s.homing > 0) {
			const Tgt *tt = nullptr;
			if (s.tgt >= 0)
				for (const auto &x : tg) if (x.uid == s.tgt) { tt = &x; break; }
			if (!tt) {
				tt = nearest(s.p, 900);
				s.tgt = tt ? tt->uid : -1;
			}
			if (tt) {
				float sp = s.v.len();
				float cura = s.v.angle();
				float want = (tt->p - s.p).angle();
				float d = std::fmod(want - cura + 3 * PI, TAU) - PI;
				float step = s.homing * dt;
				cura += clampf(d, -step, step);
				s.v = V2::fromAngle(cura) * sp;
			}
		}
		s.p += s.v * dt;
		bool dead = false;
		int foe = (mode == GM_PVP && np == 2) ? 1 - s.owner : -1;   // the other pilot, only in pvp
		if (foe >= 0 && pl[foe].dead) foe = -1;
		if (s.kind == 3) { // flak proximity fuse
			for (const auto &x : tg)
				if (dist(x.p, s.p) < x.r + 55) { dead = true; break; }
			if (!dead && foe >= 0 && dist(pl[foe].ship.p, s.p) < pl[foe].ship.r + 55) dead = true;
		}
		if (!dead && s.life > 0 && foe >= 0) {
			int key = -100 - foe;
			bool seen = false;
			for (int k = 0; k < s.nhit && k < 8; k++) if (s.hit[k] == key) seen = true;
			if (!seen && dist(pl[foe].ship.p, s.p) < pl[foe].ship.r + s.r) {
				if (s.expR > 0) dead = true;   // explodes on the ship; explode() applies the pvp damage
				else {
					if (s.dmg > 0) pvpHit(foe, s.dmg, 0.12f);
					if (s.heal > 0) cur->ship.hp = std::min(cur->ship.maxHp, cur->ship.hp + s.heal);
					if (s.nhit < 8) s.hit[s.nhit++] = key;
					s.pierce--;
					if (s.pierce < 0) dead = true;
				}
			}
		}
		if (!dead && s.life > 0) {
			for (const auto &x : tg) {
				if (dist(x.p, s.p) >= x.r + s.r) continue;
				bool seen = false;
				for (int k = 0; k < s.nhit && k < 8; k++) if (s.hit[k] == x.uid) seen = true;
				if (seen) continue;
				// is the target still alive?
				if (x.kind == 0 && asteroids[x.idx].hp <= 0) continue;
				if (x.kind == 1 && enemies[x.idx].hp <= 0) continue;
				if (x.kind == 2 && boss.hp <= 0) continue;
				if (s.expR > 0) { dead = true; break; }
				hitTarget(x, s.dmg, s.wid);
				if (s.heal > 0 && !cur->dead) cur->ship.hp = std::min(cur->ship.maxHp, cur->ship.hp + s.heal);
				if (s.split) {
					s.split = false;
					for (int k = 0; k < 2; k++) {
						const Tgt *nt = nearest(x.p, 800, x.uid);
						float a = (nt ? (nt->p - x.p).angle() : rng.range(0, TAU)) + (k == 0 ? -0.5f : 0.5f);
						Shot ns = s;
						ns.p = x.p;
						ns.v = V2::fromAngle(a) * 520.0f;
						ns.dmg = s.dmg * 0.6f;
						ns.split = false;
						ns.life = 1.8f;
						ns.tgt = nt ? nt->uid : -1;
						ns.nhit = 1;
						ns.hit[0] = x.uid;
						pendingShots_.push_back(ns);
					}
					dead = true;
					break;
				}
				if (s.nhit < 8) s.hit[s.nhit++] = x.uid;
				s.pierce--;
				if (s.pierce < 0) { dead = true; break; }
			}
		}
		if (!dead && s.life <= 0) dead = true;
		if (dead) {
			if (s.expR > 0 || s.bomblets > 0) {
				if (s.expR > 0) explode(s.p, s.expR, s.expDmg, s.wid, s.col, false);
				for (int i = 0; i < s.bomblets; i++) {
					float a = (float)i * TAU / (float)s.bomblets + rng.range(0, 0.5f);
					Shot b;
					b.p = s.p; b.v = V2::fromAngle(a) * rng.range(240, 340); b.dmg = 0; b.r = 4; b.life = rng.range(0.28f, 0.42f);
					b.expR = 48; b.expDmg = s.expDmg * 0.55f; b.kind = 7; b.wid = s.wid; b.col = s.col; b.pierce = 99;
					b.owner = s.owner;
					// appended after the loop to avoid invalidation
					pendingShots_.push_back(b);
				}
			}
			s.life = -1000;
		}
	}
	cur = &pl[0];
	shots.erase(std::remove_if(shots.begin(), shots.end(), [](const Shot &s) { return s.life <= -999; }), shots.end());
	for (auto &b : pendingShots_) shots.push_back(b);
	pendingShots_.clear();
}

} // namespace nj
