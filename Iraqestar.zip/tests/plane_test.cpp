// اختبار قسم الطائرات: الشراء والحفظ، المدافع، وكل ميزة من الميزات العشر.
#include "../src/sim/run.hpp"
#include <cstdio>
#include <memory>
using namespace nj;

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); return 1; } } while (0)

static void step(Run &r, float secs) {
	for (float t = 0; t < secs; t += 1.0f / 60) { r.update(1.0f / 60); if (r.pl[0].choosing) r.choose(0); }
}
static int countShots(const Run &r, int wid) { int n = 0; for (const auto &s : r.shots) if (s.wid == wid) n++; return n; }

int main() {
	// ---- شراء + اختيار + حفظ
	Profile p;
	p.yen = 1000;
	CHECK(!p.buyPlane(7));                   // F-16 = 6000 ما يكفي
	p.yen = 7000;
	CHECK(p.buyPlane(7) && p.yen == 1000);
	CHECK(!p.buyPlane(7));                   // ما تنشترى مرتين
	p.selectPlane(3); CHECK(p.planeSel == -1);   // غير مشتراة
	p.selectPlane(7); CHECK(p.planeSel == 7);
	Profile q; q.deserialize(p.serialize());
	CHECK(q.planeOwned[7] && q.planeSel == 7 && !q.planeOwned[0]);
	p.resetParts(); CHECK(!p.planeOwned[7] && p.planeSel == -1);
	// اسم اللاعب يُحفظ ويُسترجع (عربي + إنجليزي)
	p.playerName = "علي Ali"; { Profile n; n.deserialize(p.serialize()); CHECK(n.playerName == "علي Ali"); }

	// ---- كل طائرة: تطلق مدافعها للأمام + الصحة والسرعة حسب الجدول
	for (int i = 0; i < N_PLANE; i++) {
		Profile pr; pr.yen = 1e9; pr.buyPlane(i); pr.selectPlane(i);
		Run r(&pr, 0, 5);
		r.setView(1080, 2000); r.asteroids.clear();
		CHECK(r.pl[0].plane == i);
		CHECK(std::fabs(r.pl[0].ship.maxHp - 50.0f * PLANES[i].hpMult) < 1e-3f);
		int maxShots = 0;
		for (int f = 0; f < 90; f++) {
			r.update(1.0f / 60); if (r.pl[0].choosing) r.choose(0);
			maxShots = std::max(maxShots, countShots(r, -1));
		}
		printf("%-22s guns=%d shots alive(max)=%d\n", PLANES[i].name, PLANES[i].guns, maxShots);
		CHECK(maxShots >= PLANES[i].guns);
		CHECK(r.pl[0].abCd <= 0 || PLANES[i].ability == AB_HEAL);
	}

	auto make = [&](int plane, Profile &pr) {
		pr.yen = 1e9; pr.buyPlane(plane); pr.selectPlane(plane);
		return std::unique_ptr<Run>(new Run(&pr, 0, 11));
	};

	// F-22: تخفّي 4 ثواني = ما تنصاب
	{ Profile pr; auto r = make(0, pr); r->setView(1080, 2000);
	  CHECK(r->useAbility(0)); CHECK(!r->useAbility(0));
	  step(*r, 1.0f); CHECK(r->pl[0].ship.invuln > 0);
	  step(*r, 4.5f); CHECK(r->pl[0].abT <= 0); CHECK(r->pl[0].abCd > 0); }
	// F-35: 3 صواريخ موجهة   J-20: 5   F-14: 6
	{ int ids[3] = {1, 6, 9}, want[3] = {3, 5, 6};
	  for (int k = 0; k < 3; k++) { Profile pr; auto r = make(ids[k], pr); r->setView(1080, 2000); r->asteroids.clear();
	    CHECK(r->useAbility(0));
	    int m = 0; for (const auto &s : r->shots) if (s.homing > 0) m++;
	    printf("%s missiles=%d\n", PLANES[ids[k]].name, m); CHECK(m == want[k]); CHECK(!r->useAbility(0)); } }
	// Su-57: 8 قذائف
	{ Profile pr; auto r = make(2, pr); r->setView(1080, 2000); r->asteroids.clear();
	  int before = (int)r->shots.size(); CHECK(r->useAbility(0));
	  int n = 0; for (const auto &s : r->shots) if (s.wid == W_SCATTER) n++; CHECK(n == 8); (void)before; }
	// F-15: قنبلتين بانفجار واسع
	{ Profile pr; auto r = make(3, pr); r->setView(1080, 2000); r->asteroids.clear();
	  CHECK(r->useAbility(0)); int n = 0; for (const auto &s : r->shots) if (s.expR >= 150) n++; CHECK(n == 2); }
	// Rafale: تصويب على أقرب عدو لمدة 5 ثواني
	{ Profile pr; auto r = make(4, pr); r->setView(1080, 2000); r->asteroids.clear(); r->enemies.clear();
	  Enemy e; e.type = 0; e.hp = e.maxhp = 9999; e.r = 20; e.p = V2(400, 0); e.uid = 777; e.by = 0; r->enemies.push_back(e);
	  CHECK(r->useAbility(0)); CHECK(r->pl[0].abT > 4.9f);
	  r->pl[0].ship.ang = -PI / 2;           // الطائرة تطلع لفوق والعدو على اليمين
	  bool aimed = false;
	  for (int f = 0; f < 40 && !aimed; f++) { r->update(1.0f / 60); for (const auto &s : r->shots) if (s.wid == -1 && s.v.x > 500) aimed = true; }
	  CHECK(aimed); }
	// Typhoon: اندفاع +70%
	{ Profile pr; auto r = make(5, pr); r->setView(1080, 2000); r->asteroids.clear();
	  r->setMove(V2(1, 0)); step(*r, 1.5f); float v0 = r->pl[0].ship.v.len();
	  CHECK(r->useAbility(0)); step(*r, 1.0f); float v1 = r->pl[0].ship.v.len();
	  printf("Typhoon speed %.0f -> %.0f\n", v0, v1); CHECK(v1 > v0 * 1.5f); }
	// F-16: شرط 10 قتلى ثم يشفي جزء من الصحة
	{ Profile pr; auto r = make(7, pr); r->setView(1080, 2000); r->asteroids.clear();
	  r->pl[0].ship.hp = 10; CHECK(!r->useAbility(0));
	  r->pl[0].abKills = 10; CHECK(r->useAbility(0));
	  CHECK(r->pl[0].ship.hp > 25); CHECK(r->pl[0].abKills == 0); CHECK(!r->useAbility(0)); }
	// MiG-29: رشقة x3
	{ Profile pr; auto r = make(8, pr); r->setView(1080, 2000); r->asteroids.clear();
	  Run &rr = *r; int a = 0; for (int f = 0; f < 60; f++) { rr.update(1.0f / 60); if (rr.pl[0].choosing) rr.choose(0); }
	  a = (int)rr.pl[0].planeGunCd; (void)a;
	  CHECK(rr.useAbility(0)); CHECK(rr.pl[0].abT > 2.9f); }
	// طائرة بدون شراء: لا ميزة
	{ Profile pr; Run r(&pr, 0, 3); CHECK(!r.useAbility(0)); }
	printf("PLANES OK\n");
	return 0;
}
