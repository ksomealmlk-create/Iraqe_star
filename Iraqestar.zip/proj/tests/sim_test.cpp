#include "../src/sim/run.hpp"
#include <cstdio>
using namespace nj;
int main(int argc,char**argv){
  int pilots=N_PILOT; double totalT=0;
  for(int seed=1;seed<=6;seed++){
    Profile prof; prof.pilot=seed%pilots; for(int i=0;i<N_STORE;i++) prof.storeLevel[i]=(seed>3)?2:0;
    Run r(&prof,prof.pilot,seed);
    r.setView(1080,2000);
    float dt=1.0f/60; int frames=0; float maxT=900;
    while(!r.over && r.t<maxT){
      // bot: flee from nearest threat, drift
      V2 mv; float best=1e9; V2 away;
      for(auto&a:r.asteroids){float d=dist(a.p,r.ship.p); if(d<best){best=d;away=(r.ship.p-a.p);}}
      for(auto&e:r.enemies){float d=dist(e.p,r.ship.p)*0.7f; if(d<best){best=d;away=(r.ship.p-e.p);}}
      for(auto&b:r.ebullets){float d=dist(b.p,r.ship.p)*0.8f; if(d<best){best=d;away=(r.ship.p-b.p);}}
      if(best<260) mv=away.norm(); else mv=V2::fromAngle(r.t*0.3f)*0.4f;
      for(auto&p:r.pickups){ if(dist(p.p,r.ship.p)<500 && best>200){ mv=(p.p-r.ship.p).norm(); break; } }
      r.setMove(mv);
      r.update(dt);
      if(r.choosing){ r.choose(0); }
      r.sfx.clear(); r.toasts.clear(); frames++;
      if(!(r.ship.p.x==r.ship.p.x)){printf("NaN!\n");return 1;}
    }
    printf("seed %d pilot %s: t=%.0fs kills=%d yen=%d weapons=%zu bossKills=%d died=%d ast=%zu en=%zu shots=%zu fx=%zu\n",seed,PILOTS[prof.pilot].callsign,r.t,r.kills,r.yenEarned,r.weapons.size(),r.bossKills,(int)r.died,r.asteroids.size(),r.enemies.size(),r.shots.size(),r.fx.size());
    if(!r.over) r.retreat();
    totalT+=r.t;
    std::string s=prof.serialize(); Profile p2; p2.deserialize(s); if(p2.yen!=prof.yen){printf("serialize mismatch\n");return 1;}
  }
  printf("avg %.0fs\n",totalT/6);
}
