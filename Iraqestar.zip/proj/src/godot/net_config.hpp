#pragma once
// رابط سيرفر Cloudflare (Worker). غيّره بعد نشر السيرفر ثم ارفع التعديل للبناء من جديد.
// مثال: "wss://nujoom-room.myname.workers.dev"  (بدون / في النهاية)
#define NJ_SERVER_URL "wss://nujoom-room.YOUR-SUBDOMAIN.workers.dev"
