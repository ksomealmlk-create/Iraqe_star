#include "run.hpp"

namespace nj {

// ------------------------------------------------------------------ orbitals
static void genOrbitals(const Run &r, const WeaponInst &w, std::vector<Orbital> &out) {
	int extra = r.pas[P_DUP];
	if (w.id == W_SAW) {
		int n = 1 + extra;
		float br = 26.0f + 8.0f * w.lvl;
		for (int i = 0; i < n; i++) {
			float a = w.ang + (float)i * TAU / (float)n;
			out.push_back({r.ship.p + V2::fromAngle(a) * 125.0f, br, w.id, a});
		}
	} else if (w.id == W_ORBIT) {
		int n = 2 + (w.lvl - 1) + extra;
		for (int i = 0; i < n; i++) {
			float a = w.ang + (float)i * TAU / (float)n;
			out.push_back({r.ship.p + V2::fromAngle(a) * 175.0f, 17.0f, w.id, a});
		}
	} else if (w.id == W_FROST) {
		int n1 = 4 + extra, n2 = 6 + extra;
		for (int i = 0; i < n1; i++) {
			float a = w.ang + (float)i * TAU / (float)n1;
			out.push_back({r.ship.p + V2::fromAngle(a) * 150.0f, 17.0f, w.id, a});
		}
		for (int i = 0; i < n2; i++) {
			float a = -w.ang * 0.73f + (float)i * TAU / (float)n2;
			out.push_back({r.ship.p + V2::fromAngle(a) * 235.0f, 17.0f, w.id, a});
		}
	}
}

void Run::orbitals(std::vector<Orbital> &out) const {
	for (const auto &w : weapons) genOrbitals(*this, w, out);
}

V2 Run::droneFollowPos(int i) const {
	int n = std::max(1, pas[P_DRONE]);
	return ship.p + V2::fromAngle(t * 2.6f + (float)i * TAU / (float)n) * 85.0f;
}
V2 Run::wingmanPos() const { return ship.p + V2(-85, 55); }

void Run::updateOrbitalDamage(WeaponInst &w, float dt) {
	float speed = w.id == W_SAW ? 3.4f : (w.id == W_ORBIT ? 2.2f : 2.6f);
	w.ang += speed * dt;
	w.tick -= dt;
	if (w.tick > 0) return;
	float T = w.id == W_SAW ? 0.12f : (w.id == W_ORBIT ? 0.25f : 0.2f);
	w.tick += T;
	float dmg = w.id == W_SAW ? 6.0f * (1.0f + 0.15f * (w.lvl - 1)) : (w.id == W_ORBIT ? 11.0f * (1.0f + 0.12f * (w.lvl - 1)) : 12.0f);
	std::vector<Orbital> orbs;
	genOrbitals(*this, w, orbs);
	for (const auto &o : orbs)
		for (const auto &x : tg) {
			if (dist(o.p, x.p) >= o.r + x.r) continue;
			hitTarget(x, dmg, w.id);
			if (w.id == W_FROST) {
				if (x.kind == 1 && x.idx < (int)enemies.size()) { enemies[x.idx].slowT = 1.2f; enemies[x.idx].slowAmt = 0.5f; }
				if (x.kind == 0 && x.idx < (int)asteroids.size()) { asteroids[x.idx].slowT = 1.2f; asteroids[x.idx].slowAmt = 0.5f; }
			}
		}
}

static float distToSegment(V2 p, V2 a, V2 b) {
	V2 ab = b - a;
	float l2 = ab.len2();
	float u = l2 > 0 ? clampf((p - a).dot(ab) / l2, 0, 1) : 0;
	return dist(p, a + ab * u);
}

// ------------------------------------------------------------------ weapons
void Run::updateWeapons(float dt) {
	beamOn = false;
	float haste = revengeT > 0 ? 1.5f : 1.0f;
	for (auto &w : weapons) {
		switch (w.id) {
			case W_SAW:
			case W_ORBIT:
			case W_FROST:
				updateOrbitalDamage(w, dt);
				break;
			case W_OBLIVION: {
				const Tgt *x = nearest(ship.p, 1400);
				if (x) w.aux = (x->p - ship.p).angle();
				if (x || w.cd > 0) {
					if (x) w.cd = 0.3f; else w.cd -= dt;
					V2 d = V2::fromAngle(w.aux);
					beamOn = true;
					beamA = ship.p;
					beamB = ship.p + d * 1500.0f;
					beamW = 28.0f + 6.0f * pas[P_DUP];
					w.tick -= dt;
					if (w.tick <= 0) {
						w.tick += 0.1f;
						for (const auto &t2 : tg)
							if (distToSegment(t2.p, beamA, beamB) < t2.r + beamW * 0.5f) hitTarget(t2, 11.0f, w.id);
					}
					w.ang -= dt;
					if (w.ang <= 0) { w.ang = 0.9f; sfxEvent(S_WEAPON_BASE + w.id); }
				}
				break;
			}
			case W_WARPSAW: {
				int want = 2 + pas[P_DUP], have = 0;
				for (const auto &z : zones) if (z.kind == ZK_BLADE && z.wid == W_WARPSAW) have++;
				if (have < want) {
					Zone z;
					z.p = ship.p; z.r = 30; z.life = z.maxLife = 1e9f; z.dps = 13; z.tick = 0.1f; z.kind = ZK_BLADE; z.wid = W_WARPSAW;
					z.col = 0xFFFFAA33; z.homing = 1;
					zones.push_back(z);
				}
				break;
			}
			default:
				w.cd -= dt * haste;
				if (w.cd <= 0) fireWeapon(w);
		}
	}
}

void Run::fireWeapon(WeaponInst &w) {
	int L = w.lvl, extra = pas[P_DUP];
	float cdm = 1.0f;
	const Tgt *tt = nearest(ship.p, 950);
	V2 d = tt ? (tt->p - ship.p).norm() : V2();
	V2 perp(-d.y, d.x);
	auto aimAng = [&]() { return d.angle(); };
	auto sfx = [&]() { sfxEvent(S_WEAPON_BASE + w.id); };
	switch (w.id) {
		case W_PULSE: {
			if (!tt) return;
			int n = L + extra;
			for (int i = 0; i < n; i++) {
				float off = ((float)i - (float)(n - 1) * 0.5f) * 14.0f;
				newShot(ship.p + perp * off, d * 900.0f, 9.0f, 6, 1.1f, 0xFF66F0FF, w.id, 0);
			}
			w.cd = 0.5f * cdm; sfx();
			break;
		}
		case W_SCATTER:
		case W_LEECH: {
			if (!tt) return;
			bool leech = w.id == W_LEECH;
			int n = leech ? 11 + extra * 2 : 5 + 2 * (L - 1) + extra * 2;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + rng.range(-0.3f, 0.3f);
				Shot &s = newShot(ship.p, V2::fromAngle(a) * rng.range(700.0f, 820.0f), leech ? 6.0f : 5.5f, 4, 0.42f, leech ? 0xFF88FF88 : 0xFFFFCC66, w.id, 0);
				if (leech) s.heal = 0.25f;
			}
			w.cd = (leech ? 0.95f : 1.0f) * cdm; sfx();
			break;
		}
		case W_HOMING:
		case W_ACE: {
			if (!tt) return;
			bool ace = w.id == W_ACE;
			int n = ace ? 4 + extra : L + extra;
			auto list = nearestN(ship.p, 950, n);
			for (int i = 0; i < n; i++) {
				float a = aimAng() + ((float)i - (float)(n - 1) * 0.5f) * 0.35f;
				Shot &s = newShot(ship.p, V2::fromAngle(a) * 520.0f, ace ? 20.0f : 16.0f, 7, 3.0f, 0xFFFF8844, w.id, 1);
				s.homing = 5.0f;
				s.expR = 55; s.expDmg = ace ? 16.0f : 14.0f;
				s.tgt = list.empty() ? -1 : list[i % list.size()]->uid;
				s.split = false; // ace split handled via direct-hit only when no explosion
			}
			w.cd = (ace ? 1.4f : 1.6f) * cdm; sfx();
			break;
		}
		case W_RAIL: {
			if (!tt) return;
			static const float rr[5] = {8, 12, 18, 26, 38};
			Shot &s = newShot(ship.p, d * 2200.0f, 60.0f * (1.0f + 0.15f * (L - 1)), rr[std::min(4, L - 1)], 0.9f, 0xFF99EEFF, w.id, 5);
			s.pierce = 10 + extra;
			w.cd = 2.2f * cdm; sfx();
			break;
		}
		case W_MINES:
		case W_JACKPOT: {
			bool jp = w.id == W_JACKPOT;
			int n = jp ? 3 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			for (int i = 0; i < n; i++) {
				Mine m;
				m.p = ship.p + V2(rng.range(-25, 25), rng.range(-25, 25));
				m.dmg = jp ? 70.0f : 42.0f;
				m.expR = jp ? 150.0f : 105.0f + (L >= 2 ? 25.0f : 0) + (L >= 4 ? 25.0f : 0);
				m.wid = w.id;
				m.jackpot = jp && rng.chance(0.12f);
				mines.push_back(m);
			}
			w.cd = 2.6f * cdm; sfx();
			break;
		}
		case W_SOLAR: {
			std::vector<const Tgt *> cand;
			for (const auto &x : tg) if (dist(x.p, ship.p) < 800) cand.push_back(&x);
			if (cand.empty()) return;
			int n = 1 + L / 2 + extra;
			for (int i = 0; i < n && !cand.empty(); i++) {
				int k = rng.i((int)cand.size());
				V2 p = cand[k]->p;
				addFx(FX_LINE, p + V2(rng.range(-60, 60), -900), p, 0.25f, 7, 0xFFFFFF99);
				explode(p, 55, 28.0f, w.id, 0xFFFFEE66);
				cand.erase(cand.begin() + k);
			}
			w.cd = 1.4f * cdm; sfx();
			break;
		}
		case W_NOVA: {
			float R = 200.0f + 30.0f * L;
			explode(ship.p, R, (22.0f + 4.0f * L) * (1.0f + 0.15f * extra), w.id, 0xFF88CCFF);
			w.cd = 2.8f * cdm; sfx();
			break;
		}
		case W_LINGER: {
			float R = 300.0f;
			explode(ship.p, R, 38.0f, w.id, 0xFFAA88FF);
			Zone z;
			z.p = ship.p; z.r = 40; z.life = z.maxLife = 1.3f; z.kind = ZK_CORE; z.col = 0xFFCC99FF; z.wid = w.id;
			zones.push_back(z);
			Boom b;
			b.p = ship.p; b.t = 1.3f; b.r = R * 0.85f; b.dmg = 30.0f; b.wid = w.id; b.col = 0xFFCC99FF;
			booms.push_back(b);
			w.cd = 3.0f * cdm; sfx();
			break;
		}
		case W_NEEDLE:
		case W_SIPHON: {
			if (!tt) return;
			bool sip = w.id == W_SIPHON;
			int n = sip ? 3 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + rng.range(-0.07f, 0.07f) + (n > 1 ? ((float)i - (float)(n - 1) * 0.5f) * 0.06f : 0);
				Shot &s = newShot(ship.p, V2::fromAngle(a) * 1400.0f, (sip ? 5.0f : 3.6f) * (1.0f + 0.15f * (L - 1)), 3.5f, 0.9f, sip ? 0xFF88FF88 : 0xFFDDDDFF, w.id, 4);
				s.pierce = sip ? 4 : 2 + L / 2;
				if (sip) s.heal = 0.3f;
			}
			w.cd = (sip ? 0.15f : 0.17f) * cdm; sfx();
			break;
		}
		case W_CLUSTER: {
			if (!tt) return;
			float dd = dist(tt->p, ship.p);
			Shot &s = newShot(ship.p, d * 560.0f, 0, 8, std::max(0.15f, dd / 560.0f), 0xFFFF9944, w.id, 2);
			s.expR = 75; s.expDmg = 22.0f + 3.0f * L; s.bomblets = 3 + L + extra;
			w.cd = 2.3f * cdm; sfx();
			break;
		}
		case W_HUNTER: {
			if (!tt) return;
			int n = 1 + extra;
			auto list = nearestN(ship.p, 950, n);
			for (int i = 0; i < n; i++) {
				float a = aimAng() + ((float)i - (float)(n - 1) * 0.5f) * 0.3f;
				Shot &s = newShot(ship.p, V2::fromAngle(a) * 520.0f, 0, 9, 3.0f, 0xFFFF6633, w.id, 6);
				s.homing = 4.5f; s.expR = 95; s.expDmg = 30; s.bomblets = 3;
				s.tgt = list.empty() ? -1 : list[i % list.size()]->uid;
			}
			w.cd = 1.15f * cdm; sfx();
			break;
		}
		case W_FLAK:
		case W_BARRAGE: {
			if (!tt) return;
			bool bar = w.id == W_BARRAGE;
			int n = bar ? 5 + extra : 1 + (L >= 3 ? 1 : 0) + (L >= 5 ? 1 : 0) + extra;
			float spread = bar ? 0.6f : 0.25f;
			for (int i = 0; i < n; i++) {
				float a = aimAng() + (n > 1 ? ((float)i - (float)(n - 1) * 0.5f) * spread / (float)(n - 1) : 0.0f);
				Shot &s = newShot(ship.p, V2::fromAngle(a) * 760.0f, 0, 7, 1.1f, 0xFFFFDD66, w.id, 3);
				s.expR = bar ? 90.0f : 85.0f; s.expDmg = (bar ? 28.0f : 20.0f) + 3.0f * L;
			}
			w.cd = 1.05f * cdm; sfx();
			break;
		}
		case W_STORM: {
			int arms = 3 + extra;
			for (int i = 0; i < arms; i++) {
				float a = w.aux + (float)i * TAU / (float)arms;
				newShot(ship.p, V2::fromAngle(a) * 650.0f, 6.5f, 5, 1.4f, 0xFFAA88FF, w.id, 0);
			}
			w.aux += 0.5f;
			w.cd = 0.11f;
			if (rng.chance(0.15f)) sfxEvent(S_WEAPON_BASE + w.id);
			break;
		}
		case W_PHOENIXFLARE: {
			if (!tt) return;
			auto list = nearestN(ship.p, 900, 3 + extra);
			for (const Tgt *x : list) {
				static const float radii[3] = {60, 100, 140};
				for (int k = 0; k < 3; k++) {
					Boom b;
					b.p = x->p; b.t = 0.15f * (float)k; b.r = radii[k]; b.dmg = 28.0f; b.wid = w.id; b.col = 0xFFFF7733;
					booms.push_back(b);
				}
			}
			w.cd = 2.0f * cdm; sfx();
			break;
		}
		default: w.cd = 1.0f; break;
	}
}

void Run::updateMines(float dt) {
	for (auto &m : mines) {
		m.t += dt;
		m.life -= dt;
		bool boom = m.life <= 0;
		if (!boom && m.t > m.arm)
			for (const auto &x : tg)
				if (dist(x.p, m.p) < x.r + 45) { boom = true; break; }
		if (boom) {
			float dmg = m.dmg;
			if (m.jackpot) {
				dmg *= 3;
				spawnCoins(m.p, 400);
				addFx(FX_TEXT, m.p + V2(0, -40), V2(), 1.4f, 34, 0xFFFFE04A, V2(0, -50), "JACKPOT!");
			}
			explode(m.p, m.jackpot ? m.expR * 1.4f : m.expR, dmg, m.wid, m.jackpot ? 0xFFFFE04A : 0xFFFF8855);
			m.life = -1000;
		}
	}
	mines.erase(std::remove_if(mines.begin(), mines.end(), [](const Mine &m) { return m.life <= -999; }), mines.end());
}

void Run::updateBooms(float dt) {
	for (auto &b : booms) {
		b.t -= dt;
		if (b.t <= 0) {
			explode(b.p, b.r, b.dmg, b.wid, b.col);
			b.t = -1000;
		}
	}
	booms.erase(std::remove_if(booms.begin(), booms.end(), [](const Boom &b) { return b.t <= -999; }), booms.end());
}

void Run::updateZones(float dt) {
	for (auto &z : zones) {
		z.life -= dt;
		if (z.kind == ZK_BLADE) {
			V2 want;
			const Tgt *x = nearest(z.p, 1000);
			if (x) want = (x->p - z.p).norm() * 420.0f;
			else want = (ship.p + V2::fromAngle(t * 2.0f) * 120.0f - z.p) * 3.0f;
			z.v = z.v + (want - z.v) * std::min(1.0f, dt * 4.0f);
			z.p += z.v * dt;
			z.ang += dt * 14.0f;
			z.tickT -= dt;
			if (z.tickT <= 0) {
				z.tickT += z.tick;
				for (const auto &y : tg)
					if (dist(y.p, z.p) < z.r + y.r) hitTarget(y, z.dps, z.wid);
			}
		} else if (z.kind == ZK_GAS && z.hostile) {
			z.tickT -= dt;
			if (z.tickT <= 0) {
				z.tickT += 0.5f;
				if (dist(z.p, ship.p) < z.r + ship.r * 0.6f) damageShip(z.dps * 0.5f, 0.3f);
			}
		}
	}
	zones.erase(std::remove_if(zones.begin(), zones.end(), [](const Zone &z) { return z.life <= 0; }), zones.end());
}

// ------------------------------------------------------------------ passives & companions
void Run::updatePassives(float dt) {
	if (pas[P_NANO] > 0 && ship.hp < ship.maxHp) ship.hp = std::min(ship.maxHp, ship.hp + 0.6f * pas[P_NANO] * dt);
	if (upgradeDropT > 0) upgradeDropT -= dt;
	if (pas[P_CRYO] > 0) {
		float r = 170.0f + 25.0f * pas[P_CRYO];
		float amt = 0.3f + 0.06f * pas[P_CRYO];
		for (auto &a : asteroids) if (dist(a.p, ship.p) < r + a.r) { a.slowT = 0.3f; a.slowAmt = amt; }
		for (auto &e : enemies) if (dist(e.p, ship.p) < r + e.r) { e.slowT = 0.3f; e.slowAmt = amt; }
		cryoVis = r;
	} else cryoVis = 0;
	if (pas[P_VAMP] > 0) {
		int n = 0;
		for (auto &a : asteroids)
			if (a.hp > 0 && dist(a.p, ship.p) < 230 + a.r) {
				a.hp -= 5.0f * pas[P_VAMP] * dt;
				if (++n <= 3) ship.hp = std::min(ship.maxHp, ship.hp + 0.6f * pas[P_VAMP] * dt);
			}
	}
}

void Run::updateCompanions(float dt) {
	if (pas[P_TB26] > 0) {
		wingCd -= dt;
		if (wingCd <= 0) {
			V2 wp = wingmanPos();
			const Tgt *x = nearest(wp, 700);
			if (x) {
				V2 d = (x->p - wp).norm();
				newShot(wp, d * 820.0f, 7.0f * (1.0f + 0.35f * (pas[P_TB26] - 1)), 5, 0.9f, 0xFF88FFAA, -1, 0);
				wingCd = 0.45f;
			} else wingCd = 0.1f;
		}
	}
	if (pas[P_DRONE] > 0) {
		droneCd -= dt;
		if (droneCd <= 0) {
			bool fired = false;
			for (int i = 0; i < pas[P_DRONE]; i++) {
				V2 dp = droneFollowPos(i);
				const Tgt *x = nearest(dp, 600);
				if (x) {
					newShot(dp, (x->p - dp).norm() * 800.0f, 6.0f, 4, 0.8f, 0xFFFFDD88, -1, 0);
					fired = true;
				}
			}
			droneCd = fired ? 0.7f : 0.15f;
		}
	}
}

// ------------------------------------------------------------------ pickups & loot
void Run::spawnPickup(V2 p, int kind, float val) {
	if (pickups.size() > 260) return;
	Pickup k;
	k.p = p; k.kind = kind; k.val = val;
	k.v = V2::fromAngle(rng.range(0, TAU)) * rng.range(30, 120);
	k.life = kind == PK_UPGRADE ? 30.0f : 20.0f;
	pickups.push_back(k);
}

void Run::spawnCoins(V2 p, int pts) {
	int n = pts <= 10 ? 1 : (pts <= 40 ? 2 : (pts <= 150 ? 3 : 5));
	for (int i = 0; i < n; i++) spawnPickup(p, PK_COIN, (float)pts / (float)n);
}

void Run::dropFromAsteroid(const Asteroid &a) {
	static const int pts[3] = {3, 8, 18};
	if (rng.chance(0.55f)) spawnCoins(a.p, pts[a.size] * (a.type == 2 ? 2 : 1));
	bool haveOrb = false;
	for (const auto &k : pickups) if (k.kind == PK_UPGRADE) haveOrb = true;
	if (haveOrb || choosing) return;
	float sizeF = a.size == 2 ? 1.5f : (a.size == 1 ? 1.0f : 0.5f);
	float chance = (upgradesTaken < 4 ? 0.18f : 0.07f) * sizeF * (1.0f + P->storeValue(7)) * (1.0f + 0.25f * pas[P_LUCKY]);
	bool force = upgradesTaken == 0 && t > 15.0f;
	if (force || (upgradeDropT <= 0 && rng.chance(chance))) {
		spawnPickup(a.p, PK_UPGRADE, 0);
		upgradeDropT = upgradesTaken < 4 ? 10.0f : 18.0f;
	}
}

void Run::updatePickups(float dt) {
	float range = 90.0f * (1.0f + P->storeValue(5)) * (1.0f + 0.4f * pas[P_MAGNET]);
	bool collectedUpgrade = false;
	for (auto &k : pickups) {
		k.life -= dt;
		k.t += dt;
		float d = dist(k.p, ship.p);
		float pull = k.kind == PK_UPGRADE ? range * 1.6f + 160.0f : range;
		if (d < pull) {
			V2 dir = (ship.p - k.p).norm();
			k.p += dir * (380.0f + 500.0f * (1.0f - d / pull)) * dt;
		} else {
			k.p += k.v * dt;
			k.v *= 0.96f;
		}
		if (d < ship.r + 24.0f) {
			if (k.kind == PK_COIN) {
				int gain = std::max(1, (int)std::round(k.val * 0.5f * (1.0f + P->storeValue(6))));
				yenEarned += gain;
				sfxEvent(S_YEN);
				k.life = -1;
			} else if (k.kind == PK_HEAL) {
				ship.hp = std::min(ship.maxHp, ship.hp + k.val);
				sfxEvent(S_POWERUP);
				addFx(FX_TEXT, ship.p + V2(0, -40), V2(), 0.8f, 20, 0xFF66FF88, V2(0, -50), "+HP");
				k.life = -1;
			} else if (k.kind == PK_SHIELD) {
				ship.sh = std::min(ship.maxSh, ship.sh + k.val);
				sfxEvent(S_POWERUP);
				k.life = -1;
			} else if (k.kind == PK_UPGRADE && !collectedUpgrade && !choosing) {
				collectedUpgrade = true;
				sfxEvent(S_POWERUP);
				k.life = -1;
				upgradesTaken++;
				makeOptions();
				choosing = true;
			}
		}
	}
	pickups.erase(std::remove_if(pickups.begin(), pickups.end(), [](const Pickup &k) { return k.life <= 0; }), pickups.end());
}

// ------------------------------------------------------------------ reaping dead things
void Run::reap() {
	// asteroids
	size_t n = asteroids.size();
	for (size_t i = 0; i < n; i++) {
		if (asteroids[i].hp > 0) continue;
		Asteroid a = asteroids[i];
		sfxEvent(S_ASTEROID);
		for (int k = 0; k < 5; k++)
			addFx(FX_SPARK, a.p, V2(), 0.5f, 2.5f, 0xFFBBBBBB, V2::fromAngle(rng.range(0, TAU)) * rng.range(40, 160));
		if (a.type == 3) explode(a.p, 150, 28.0f, -1, 0xFFFF8833, true);
		if (a.type == 1) {
			for (auto &e : enemies) if (dist(e.p, a.p) < 280) { e.slowT = 2.5f; e.slowAmt = 0.6f; }
			for (auto &o : asteroids) if (dist(o.p, a.p) < 280) { o.slowT = 2.5f; o.slowAmt = 0.6f; }
			addFx(FX_RING, a.p, V2(), 0.5f, 280, 0xFF99DDFF);
		}
		splitAsteroid(a);
		dropFromAsteroid(a);
	}
	asteroids.erase(std::remove_if(asteroids.begin(), asteroids.end(), [](const Asteroid &a) { return a.hp <= 0; }), asteroids.end());

	// enemies
	for (size_t i = 0; i < enemies.size(); i++) {
		if (enemies[i].hp > 0) continue;
		Enemy e = enemies[i];
		const EnemyDef &d = ENEMIES[e.type];
		kills++;
		streak++;
		bestStreak = std::max(bestStreak, streak);
		P->totalKills++;
		sfxEvent(S_ENEMY_DEATH);
		explode(e.p, 70, 0, -1, d.col);
		static const int tierPts[5] = {0, 40, 90, 180, 350};
		spawnCoins(e.p, tierPts[d.tier]);
		if (rng.chance(0.08f)) spawnPickup(e.p, PK_HEAL, 20);
		else if (rng.chance(0.05f)) spawnPickup(e.p, PK_SHIELD, 20);
	}
	enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [](const Enemy &e) { return e.hp <= 0; }), enemies.end());

	// boss
	if (boss.active && boss.hp <= 0) {
		boss.active = false;
		bossKills++;
		kills++;
		streak++;
		bestStreak = std::max(bestStreak, streak);
		P->totalKills++;
		sfxEvent(S_ENEMY_DEATH);
		explode(boss.p, 260, 0, -1, 0xFFFFCC44);
		for (int k = 0; k < 30; k++)
			addFx(FX_SPARK, boss.p, V2(), 0.9f, 4, 0xFFFFDD66, V2::fromAngle(rng.range(0, TAU)) * rng.range(80, 460));
		spawnCoins(boss.p, 3000);
		spawnPickup(boss.p, PK_UPGRADE, 0);
		ship.hp = std::min(ship.maxHp, ship.hp + ship.maxHp * 0.5f);
		nextBoss = t + 150.0f;
		for (auto &b : ebullets) b.life = 0;
		toast("تم القضاء على الزعيم!");
	}
}

// ------------------------------------------------------------------ upgrades
void Run::addWeapon(int id) {
	WeaponInst w;
	w.id = id;
	w.lvl = isEvolution(id) ? 5 : 1;
	weapons.push_back(w);
	P->weaponSeen[id] = true;
}

void Run::makeOptions() {
	options.clear();
	for (int i = 0; i < (int)weapons.size(); i++) {
		const auto &w = weapons[i];
		if (!isEvolution(w.id) && w.lvl >= 5 && pas[WEAPONS[w.id].evoPassive] > 0) options.push_back({OK_EVOLVE, i});
	}
	std::vector<Option> pool;
	for (int i = 0; i < (int)weapons.size(); i++)
		if (!isEvolution(weapons[i].id) && weapons[i].lvl < 5) pool.push_back({OK_LEVEL, i});
	if ((int)weapons.size() < weaponMaxSlots()) {
		for (int id = 0; id < W_BASE_COUNT; id++) {
			bool owned = false;
			for (const auto &w : weapons) if (w.id == id || w.id == evolutionOf(id)) owned = true;
			if (!owned) pool.push_back({OK_NEW_WEAPON, id});
		}
	}
	int owned = passivesOwned();
	for (int p = 0; p < P_COUNT; p++) {
		if (pas[p] > 0 && pas[p] < 5) pool.push_back({OK_STACK, p});
		else if (pas[p] == 0 && owned < passiveMaxSlots()) pool.push_back({OK_NEW_PASSIVE, p});
	}
	for (int i = (int)pool.size() - 1; i > 0; i--) std::swap(pool[i], pool[rng.i(i + 1)]);
	int want = 3 + (pas[P_LUCKY] >= 3 ? 1 : 0);
	for (size_t i = 0; i < pool.size() && (int)options.size() < want; i++) options.push_back(pool[i]);
	if (options.empty()) options.push_back({OK_HEAL, 0});
}

void Run::applyOption(const Option &o) {
	switch (o.kind) {
		case OK_NEW_WEAPON: addWeapon(o.a); break;
		case OK_LEVEL: if (o.a >= 0 && o.a < (int)weapons.size()) weapons[o.a].lvl = std::min(5, weapons[o.a].lvl + 1); break;
		case OK_NEW_PASSIVE:
		case OK_STACK:
			pas[o.a] = std::min(5, pas[o.a] + 1);
			if (o.a == P_GLASS) { ship.maxSh = 0; ship.sh = 0; }
			break;
		case OK_EVOLVE: {
			WeaponInst &w = weapons[o.a];
			w.id = evolutionOf(w.id);
			w.lvl = 5;
			w.cd = 0; w.tick = 0; w.aux = 0;
			P->weaponSeen[w.id] = true;
			sfxEvent(S_EVOLVE);
			addFx(FX_RING, ship.p, V2(), 0.8f, 380, 0xFFFFDD55);
			toast(std::string("تطوير: ") + WEAPONS[w.id].name);
			break;
		}
		case OK_HEAL: ship.hp = std::min(ship.maxHp, ship.hp + ship.maxHp * 0.5f); break;
	}
}

void Run::choose(int i) {
	if (!choosing || i < 0 || i >= (int)options.size()) return;
	applyOption(options[i]);
	if (options[i].kind != OK_EVOLVE) sfxEvent(S_UPGRADE);
	options.clear();
	choosing = false;
}

std::string Run::optionTitle(const Option &o) const {
	switch (o.kind) {
		case OK_NEW_WEAPON: return WEAPONS[o.a].name;
		case OK_LEVEL: return std::string(WEAPONS[weapons[o.a].id].name) + "  Lv" + std::to_string(weapons[o.a].lvl + 1);
		case OK_NEW_PASSIVE: return PASSIVES[o.a].name;
		case OK_STACK: return std::string(PASSIVES[o.a].name) + "  x" + std::to_string(pas[o.a] + 1);
		case OK_EVOLVE: return WEAPONS[evolutionOf(weapons[o.a].id)].name;
		default: return "Repair Kit";
	}
}
std::string Run::optionDesc(const Option &o) const {
	switch (o.kind) {
		case OK_NEW_WEAPON: return WEAPONS[o.a].desc;
		case OK_LEVEL: return "Stronger and more projectiles";
		case OK_NEW_PASSIVE: case OK_STACK: return PASSIVES[o.a].desc;
		case OK_EVOLVE: return WEAPONS[evolutionOf(weapons[o.a].id)].desc;
		default: return "Restore 50% health";
	}
}
int Run::optionIcon(const Option &o, bool &isPassive) const {
	isPassive = false;
	switch (o.kind) {
		case OK_NEW_WEAPON: return o.a;
		case OK_LEVEL: return weapons[o.a].id;
		case OK_NEW_PASSIVE: case OK_STACK: isPassive = true; return o.a;
		case OK_EVOLVE: return evolutionOf(weapons[o.a].id);
		default: return -1;
	}
}

} // namespace nj
