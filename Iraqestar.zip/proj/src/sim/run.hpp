#pragma once
#include "core.hpp"
#include "profile.hpp"

namespace nj {

struct Asteroid {
	V2 p, v;
	float rot = 0, rv = 0, r = 0, hp = 0, maxhp = 0, flash = 0, slowT = 0, slowAmt = 0, trailT = 0;
	int size = 0;  // 0 small 1 medium 2 large
	int type = 0;  // 0 rock 1 ice 2 metal 3 volatile 4 magnetic 5 toxic trail
	uint32_t seed = 0;
	int uid = 0;
};

struct Enemy {
	V2 p, v;
	int type = 0;
	float hp = 0, maxhp = 0, r = 0, fire = 0, ang = 0, t = 0, aux = 0, flash = 0, slowT = 0, slowAmt = 0, alpha = 1;
	int dir = 1;
	int uid = 0;
};

struct Boss {
	bool active = false;
	V2 p, v, dashDir;
	float hp = 0, maxhp = 0, r = 95, t = 0, fireA = 0, fireB = 0, fireC = 0, dashT = 0, dashing = 0, flash = 0, spiral = 0, telegraph = 0;
	int uid = 0, index = 0, phase = 0;
};

struct EBullet {
	V2 p, v;
	float dmg = 0, r = 6, life = 3, expR = 0;
	uint32_t col = 0xFFFF6644;
	int kind = 0; // 0 normal 1 explosive 2 big bomb
};

struct Shot {
	V2 p, v;
	float dmg = 0, r = 5, life = 1, homing = 0, expR = 0, expDmg = 0, heal = 0, trailT = 0, aux = 0;
	int pierce = 0, wid = 0, tgt = -1, bomblets = 0, kind = 0, nhit = 0;
	bool split = false;
	uint32_t col = 0xFFFFFF00;
	int hit[8] = {-1, -1, -1, -1, -1, -1, -1, -1};
};

enum PickupKind { PK_COIN, PK_UPGRADE, PK_HEAL, PK_SHIELD };
struct Pickup {
	V2 p, v;
	int kind = 0;
	float val = 0, life = 22, t = 0;
};

struct Mine {
	V2 p;
	float arm = 0.6f, life = 14, dmg = 0, expR = 0, t = 0;
	int wid = 0;
	bool jackpot = false;
};

struct Boom {
	V2 p;
	float t = 0, r = 0, dmg = 0;
	int wid = 0;
	uint32_t col = 0xFFFFAA44;
};

enum ZoneKind { ZK_BLADE, ZK_GAS, ZK_CORE };
struct Zone {
	V2 p, v;
	float r = 30, life = 1, maxLife = 1, dps = 0, tick = 0.1f, tickT = 0, homing = 0;
	int kind = 0, wid = 0;
	bool hostile = false;
	uint32_t col = 0xFFFFFFFF;
	float ang = 0;
};

enum FxKind { FX_RING, FX_LINE, FX_SPARK, FX_TEXT, FX_FLASH };
struct Fx {
	int kind = 0;
	V2 a, b, v;
	float t = 0, life = 0.5f, size = 10;
	uint32_t col = 0xFFFFFFFF;
	std::string txt;
};

struct WeaponInst {
	int id = 0, lvl = 1;
	float cd = 0, ang = 0, tick = 0, aux = 0;
};

struct Ship {
	V2 p, v;
	float hp = 50, maxHp = 50, sh = 50, maxSh = 50, r = 22, invuln = 0, shDelay = 0, ang = -PI / 2, moveFrac = 0;
};

enum OptionKind { OK_NEW_WEAPON, OK_LEVEL, OK_NEW_PASSIVE, OK_STACK, OK_EVOLVE, OK_HEAL };
struct Option {
	int kind = 0;
	int a = 0; // weapon id / passive id / weapon slot index
};

struct Tgt {
	int kind; // 0 asteroid 1 enemy 2 boss
	int idx;
	V2 p;
	float r;
	int uid;
};

struct Orbital {
	V2 p;
	float r;
	int wid;
	float ang;
};

class Run {
public:
	Run(Profile *prof, int pilotIdx, uint64_t seed);

	void setView(float w, float h) { viewW = w; viewH = h; }
	void setMove(V2 dir) { moveIn = dir; }
	void update(float dt);
	void choose(int i);
	void retreat() { if (!over) finish(false); }

	// ---- state (read by renderer) ----
	Profile *P;
	int pilot;
	Rng rng;
	float viewW = 960, viewH = 2142;
	V2 moveIn;

	Ship ship;
	std::vector<Asteroid> asteroids;
	std::vector<Enemy> enemies;
	Boss boss;
	std::vector<EBullet> ebullets;
	std::vector<Shot> shots;
	std::vector<Pickup> pickups;
	std::vector<Mine> mines;
	std::vector<Boom> booms;
	std::vector<Zone> zones;
	std::vector<Fx> fx;
	std::vector<WeaponInst> weapons;
	int pas[P_COUNT] = {};

	// beam (Oblivion)
	bool beamOn = false;
	V2 beamA, beamB;
	float beamW = 28;

	bool choosing = false;
	std::vector<Option> options;
	bool over = false, died = false;

	float t = 0, diff = 1;
	int kills = 0, streak = 0, bestStreak = 0, yenEarned = 0, bossKills = 0, upgradesTaken = 0;
	bool revived = false;
	float flightT = 0, bossAnnounce = 0, hitFlash = 0;

	std::vector<int> sfx;
	std::vector<std::string> toasts;

	// helpers for renderer
	void orbitals(std::vector<Orbital> &out) const;
	V2 droneFollowPos(int i) const;
	V2 wingmanPos() const;
	int weaponMaxSlots() const { return 4 + (pas[P_SLOT] > 0 ? 1 : 0); }
	int passiveMaxSlots() const { return pas[P_SLOT] > 0 ? 3 : 4; }
	int passivesOwned() const;
	float dmgMult() const;
	std::string optionTitle(const Option &o) const;
	std::string optionDesc(const Option &o) const;
	int optionIcon(const Option &o, bool &isPassive) const;

private:
	int nextUid = 1;
	float asteroidTimer = 0.5f, enemyTimer = 7.0f, nextBoss = 180.0f, achTimer = 0, regenAcc = 0;
	float revengeT = 0, cryoVis = 0, vampAcc = 0, wingCd = 0, droneCd = 0, upgradeDropT = 0;
	float stillT = 0;
	std::vector<Tgt> tg;
	std::vector<Shot> pendingShots_;

	void recomputeSlots() {}
	void finish(bool died);
	void sfxEvent(int id) { if (sfx.size() < 48) sfx.push_back(id); }

	// spawning
	void spawnAsteroid();
	void spawnEnemy();
	void spawnBoss();
	void splitAsteroid(const Asteroid &a);

	// updates
	void updateShip(float dt);
	void updateAsteroids(float dt);
	void updateEnemies(float dt);
	void updateBoss(float dt);
	void buildTargets();
	void updateWeapons(float dt);
	void updateOrbitalDamage(WeaponInst &w, float dt);
	void updateShots(float dt);
	void updateEBullets(float dt);
	void updateMines(float dt);
	void updateBooms(float dt);
	void updateZones(float dt);
	void updatePickups(float dt);
	void updateCompanions(float dt);
	void updatePassives(float dt);
	void reap();
	void updateFx(float dt);

	// combat
	void fireWeapon(WeaponInst &w);
	void damageShip(float d, float invuln);
	void die();
	void explode(V2 p, float r, float dmg, int wid, uint32_t col, bool hurtShip = false);
	void hitTarget(const Tgt &t, float dmg, int wid);
	void hitAsteroid(Asteroid &a, float dmg);
	void hitEnemy(Enemy &e, float dmg);
	void hitBoss(float dmg);
	float rollDamage(float base, bool &crit);
	void enemyFire(Enemy &e);
	void bossFire(float dt);
	void ebullet(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int kind = 0, float expR = 0);
	Shot &newShot(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int wid, int kind);
	const Tgt *nearest(V2 from, float maxR, int skipUid = -1) const;
	std::vector<const Tgt *> nearestN(V2 from, float maxR, int n) const;
	void addFx(int kind, V2 a, V2 b, float life, float size, uint32_t col, V2 v = V2(), const std::string &txt = "");
	void damageText(V2 p, float dmg, bool crit);
	void spawnCoins(V2 p, int pts);
	void spawnPickup(V2 p, int kind, float val);
	void dropFromAsteroid(const Asteroid &a);

	// upgrades
	void makeOptions();
	void applyOption(const Option &o);
	void addWeapon(int id);
	void toast(const std::string &s) { toasts.push_back(s); }
	void checkMeta();
	float asteroidSpeedScale() const;
};

} // namespace nj
