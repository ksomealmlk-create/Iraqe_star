#include "run.hpp"

#include <cstring>

namespace nj {

static const float ASTEROID_R[3] = {15, 30, 50};
static const float ASTEROID_HP[3] = {8, 22, 50};
static const float ASTEROID_CONTACT[3] = {6, 12, 20};

Run::Run(Profile *prof, int pilotIdx, uint64_t seed) : P(prof), pilot(pilotIdx), rng(seed) {
	if (pilot < 0 || pilot >= N_PILOT) pilot = 0;
	ship.p = V2(0, 0);
	ship.maxHp = 50 + P->storeValue(0);
	ship.hp = ship.maxHp;
	ship.maxSh = 50 + P->storeValue(1);
	ship.sh = ship.maxSh;
	pas[PILOTS[pilot].passive] = 1;
	if (pas[P_GLASS] > 0) { ship.maxSh = 0; ship.sh = 0; }
	addWeapon(W_PULSE);
	asteroidTimer = 0.4f;
	nextBoss = 180.0f;
}

int Run::passivesOwned() const {
	int n = 0;
	for (int i = 0; i < P_COUNT; i++) n += pas[i] > 0 ? 1 : 0;
	return n;
}

float Run::dmgMult() const {
	float m = 1.0f + P->storeValue(3);
	if (pas[P_GLASS] > 0) m *= 1.0f + 0.35f * pas[P_GLASS];
	if (pas[P_MOMENTUM] > 0) m *= 1.0f + 0.08f * pas[P_MOMENTUM] * ship.moveFrac;
	return m;
}

float Run::asteroidSpeedScale() const { return std::min(7.0f, 1.0f + 0.15f * (t / 60.0f)); }

// ------------------------------------------------------------------ main update
void Run::update(float dt) {
	if (over || choosing) return;
	if (dt > 0.05f) dt = 0.05f;
	if (dt <= 0) return;
	t += dt;
	float m = t / 60.0f;
	diff = m > 8.0f ? 4.0f + 0.4f * (m - 8.0f) : 1.0f + 0.75f * m - 0.046875f * m * m;
	if (bossAnnounce > 0) bossAnnounce -= dt;
	if (hitFlash > 0) hitFlash -= dt;

	updateShip(dt);

	asteroidTimer -= dt;
	if (asteroidTimer <= 0) {
		if (asteroids.size() < (size_t)(34 + 6 * diff)) spawnAsteroid();
		asteroidTimer = std::max(0.3f, 2.0f / diff) * rng.range(0.7f, 1.3f);
	}
	enemyTimer -= dt;
	if (enemyTimer <= 0 && t > 5.0f) {
		if (!boss.active && enemies.size() < (size_t)(3 + 2 * diff)) spawnEnemy();
		enemyTimer = std::max(2.0f, 9.0f / diff) * rng.range(0.8f, 1.2f);
	}
	if (!boss.active && t >= nextBoss) spawnBoss();

	updateAsteroids(dt);
	updateEnemies(dt);
	updateBoss(dt);
	buildTargets();
	updatePassives(dt);
	updateWeapons(dt);
	updateShots(dt);
	updateEBullets(dt);
	updateMines(dt);
	updateBooms(dt);
	updateZones(dt);
	updatePickups(dt);
	updateCompanions(dt);
	reap();
	updateFx(dt);

	achTimer -= dt;
	if (achTimer <= 0) {
		achTimer = 1.0f;
		checkMeta();
	}
}

void Run::checkMeta() {
	P->bestSurvival = std::max(P->bestSurvival, (int)t);
	P->maxKillsRun = std::max(P->maxKillsRun, kills);
	P->bestStreak = std::max(P->bestStreak, bestStreak);
	P->bestFlight = std::max(P->bestFlight, (int)flightT);
	for (int i : P->checkAchievements()) toast(std::string("إنجاز جديد: ") + ACHS[i].titleAr);
	for (int i : P->refreshPilots()) {
		toast(std::string("انضم طيار جديد: ") + PILOTS[i].callsign);
		sfxEvent(S_UPGRADE);
	}
}

void Run::finish(bool wasDeath) {
	if (over) return;
	over = true;
	died = wasDeath;
	P->yen += yenEarned;
	P->totalYenEarned += yenEarned;
	if (wasDeath) P->totalDeaths++;
	checkMeta();
}

// ------------------------------------------------------------------ ship
void Run::updateShip(float dt) {
	float spd = 300.0f * (1.0f + P->storeValue(2));
	V2 in = moveIn;
	float mag = std::min(1.0f, in.len());
	V2 want = mag > 0.01f ? in.norm() * (spd * mag) : V2(0, 0);
	V2 dv = want - ship.v;
	float acc = (mag > 0.01f ? 800.0f : 400.0f) * dt * 2.2f;
	float dl = dv.len();
	if (dl > acc) dv = dv / dl * acc;
	ship.v += dv;
	ship.p += ship.v * dt;
	float spdNow = ship.v.len();
	ship.moveFrac = lerpf(ship.moveFrac, clampf(spdNow / spd, 0, 1), std::min(1.0f, dt * 6));
	if (spdNow > 30) {
		float a = ship.v.angle();
		float d = std::fmod(a - ship.ang + 3 * PI, TAU) - PI;
		ship.ang += d * std::min(1.0f, dt * 10);
	}
	if (ship.invuln > 0) ship.invuln -= dt;
	if (ship.shDelay > 0) ship.shDelay -= dt;
	else if (ship.sh < ship.maxSh) ship.sh = std::min(ship.maxSh, ship.sh + 2.5f * dt);
	if (revengeT > 0) revengeT -= dt;
	if (ship.moveFrac > 0.15f) { stillT = 0; flightT += dt; }
	else { stillT += dt; if (stillT > 1.0f) flightT = 0; }
}

void Run::damageShip(float d, float invuln) {
	if (over || ship.invuln > 0 || d <= 0) return;
	ship.invuln = invuln;
	P->totalDamageTaken += (int)std::ceil(d);
	streak = 0;
	flightT = 0;
	hitFlash = 0.25f;
	if (pas[P_REVENGE] > 0) revengeT = 2.5f + 0.7f * pas[P_REVENGE];
	if (ship.sh > 0) {
		ship.sh -= d;
		if (ship.sh <= 0) {
			ship.hp += ship.sh; // overflow
			ship.sh = 0;
			sfxEvent(S_SHIELD_BREAK);
		} else sfxEvent(S_SHIELD_HIT);
		ship.shDelay = 2.0f;
	} else {
		ship.hp -= d;
		ship.shDelay = 2.0f;
		sfxEvent(S_PLAYER_HIT);
	}
	addFx(FX_RING, ship.p, V2(), 0.3f, 60, 0xFFFF4444);
	for (int i = 0; i < 5; i++) {
		float a = rng.range(0, TAU);
		addFx(FX_SPARK, ship.p, V2(), 0.4f, 3, 0xFFFF8866, V2::fromAngle(a) * rng.range(80, 220));
	}
	if (ship.hp <= 0) die();
}

void Run::die() {
	if (pas[P_PHOENIX] > 0 && !revived) {
		revived = true;
		ship.hp = ship.maxHp * std::min(1.0f, 0.5f + 0.1f * pas[P_PHOENIX]);
		ship.sh = ship.maxSh;
		ship.invuln = 2.5f;
		sfxEvent(S_REVIVE);
		explode(ship.p, 700, 220, -1, 0xFFFFAA33, false);
		addFx(FX_RING, ship.p, V2(), 0.8f, 700, 0xFFFFCC44);
		addFx(FX_TEXT, ship.p + V2(0, -70), V2(), 1.6f, 36, 0xFFFFDD55, V2(0, -30), "PHOENIX!");
		for (auto &b : ebullets) b.life = 0;
		return;
	}
	sfxEvent(S_PLAYER_DEATH);
	for (int i = 0; i < 40; i++) {
		float a = rng.range(0, TAU);
		addFx(FX_SPARK, ship.p, V2(), rng.range(0.5f, 1.2f), rng.range(2, 6), 0xFF66FF88, V2::fromAngle(a) * rng.range(60, 420));
	}
	addFx(FX_RING, ship.p, V2(), 0.9f, 220, 0xFFFFFFFF);
	finish(true);
}

// ------------------------------------------------------------------ spawning
static Asteroid makeAsteroid(Rng &rng, int size, int type, float m) {
	Asteroid a;
	a.size = size;
	a.type = type;
	a.r = ASTEROID_R[size];
	float mult = 1.0f + 0.05f * m;
	if (type == 2) mult *= 3.0f;
	else if (type == 1) mult *= 1.3f;
	else if (type == 3) mult *= 0.8f;
	a.maxhp = a.hp = ASTEROID_HP[size] * mult;
	a.seed = rng.next();
	a.rot = rng.range(0, TAU);
	a.rv = rng.range(-1.5f, 1.5f);
	return a;
}

void Run::spawnAsteroid() {
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 110.0f;
	float ang = rng.range(0, TAU);
	V2 pos = ship.p + V2::fromAngle(ang) * R;
	V2 target = ship.p + V2(rng.range(-0.5f, 0.5f) * viewW, rng.range(-0.5f, 0.5f) * viewH);
	float f = rng.f();
	int size = f < 0.28f ? 0 : (f < 0.68f ? 1 : 2);
	int type = 0;
	if (rng.chance(0.28f)) {
		int avail[5], n = 0;
		if (t >= 60) avail[n++] = 1;
		if (t >= 120) avail[n++] = 2;
		if (t >= 180) avail[n++] = 3;
		if (t >= 240) avail[n++] = 4;
		if (t >= 300) avail[n++] = 5;
		if (n > 0) type = avail[rng.i(n)];
	}
	Asteroid a = makeAsteroid(rng, size, type, t / 60.0f);
	a.p = pos;
	a.v = (target - pos).norm() * 80.0f * asteroidSpeedScale() * rng.range(0.7f, 1.3f);
	a.uid = nextUid++;
	asteroids.push_back(a);
}

void Run::splitAsteroid(const Asteroid &a) {
	if (a.size == 0) return;
	int n = a.type == 1 ? 3 : 2;
	if (a.size == 2 && rng.chance(0.4f)) n++;
	for (int i = 0; i < n; i++) {
		Asteroid c = makeAsteroid(rng, a.size - 1, a.type == 3 ? 0 : a.type, t / 60.0f);
		float ang = rng.range(0, TAU);
		c.p = a.p + V2::fromAngle(ang) * (a.r * 0.4f);
		c.v = a.v * 0.6f + V2::fromAngle(ang) * rng.range(40, 110);
		c.uid = nextUid++;
		asteroids.push_back(c);
	}
}

void Run::spawnEnemy() {
	int avail[N_ENEMY], w[N_ENEMY], n = 0, total = 0;
	for (int i = 0; i < N_ENEMY; i++)
		if (ENEMIES[i].unlock <= t) { avail[n] = i; w[n] = n; n++; }
	if (n == 0) return;
	for (int i = 0; i < n; i++) { w[i] = n - i; total += w[i]; }
	int roll = rng.i(total), pick = 0;
	for (int i = 0; i < n; i++) { roll -= w[i]; if (roll < 0) { pick = i; break; } }
	int type = avail[pick];
	const EnemyDef &d = ENEMIES[type];
	Enemy e;
	e.type = type;
	float hpScale = 1.0f + 0.12f * (diff - 1.0f);
	e.maxhp = e.hp = d.hp * hpScale;
	e.r = d.radius;
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 80.0f;
	e.p = ship.p + V2::fromAngle(rng.range(0, TAU)) * R;
	e.fire = rng.range(0.6f, d.fire);
	e.dir = rng.chance(0.5f) ? 1 : -1;
	e.aux = rng.range(1.5f, 3.5f);
	e.uid = nextUid++;
	enemies.push_back(e);
}

void Run::spawnBoss() {
	boss = Boss();
	boss.active = true;
	boss.index = bossKills;
	boss.maxhp = boss.hp = 1400.0f + 1100.0f * boss.index;
	float R = 0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 150.0f;
	boss.p = ship.p + V2::fromAngle(rng.range(0, TAU)) * R;
	boss.uid = nextUid++;
	boss.fireA = 2.0f;
	boss.fireB = 3.5f;
	boss.dashT = 6.0f;
	bossAnnounce = 3.0f;
	sfxEvent(S_BOSS);
	toast("تحذير: زعيم قادم!");
}

// ------------------------------------------------------------------ entity updates
void Run::updateAsteroids(float dt) {
	float despawn = (0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 110.0f) * 2.3f;
	float m = t / 60.0f;
	for (auto &a : asteroids) {
		float sp = 1.0f;
		if (a.slowT > 0) { a.slowT -= dt; sp = 1.0f - a.slowAmt; }
		if (a.type == 4) {
			V2 to = (ship.p - a.p).norm();
			a.v += to * 70.0f * dt;
			float l = a.v.len(), mx = 90.0f * asteroidSpeedScale() + 70.0f;
			if (l > mx) a.v = a.v / l * mx;
		}
		a.p += a.v * (dt * sp);
		a.rot += a.rv * dt;
		if (a.flash > 0) a.flash -= dt;
		if (a.type == 5) {
			a.trailT -= dt;
			if (a.trailT <= 0) {
				a.trailT = 0.4f;
				Zone z;
				z.p = a.p; z.r = 26; z.life = z.maxLife = 3.0f; z.dps = 7; z.kind = ZK_GAS; z.hostile = true; z.col = 0xFF44FF44;
				if (zones.size() < 120) zones.push_back(z);
			}
		}
		if (a.hp > 0 && dist(a.p, ship.p) < a.r + ship.r * 0.85f) {
			V2 n = (a.p - ship.p).norm();
			if (n.len2() < 0.5f) n = V2(1, 0);
			damageShip(ASTEROID_CONTACT[a.size] * (1.0f + 0.05f * m), 0.8f);
			a.hp -= 22;
			a.flash = 0.15f;
			a.v = n * std::max(a.v.len(), 140.0f);
			ship.v -= n * 160.0f;
			a.p = ship.p + n * (a.r + ship.r);
		}
	}
	asteroids.erase(std::remove_if(asteroids.begin(), asteroids.end(), [&](const Asteroid &a) { return dist(a.p, ship.p) > despawn; }), asteroids.end());
}

void Run::updateEnemies(float dt) {
	float despawn = (0.5f * std::sqrt(viewW * viewW + viewH * viewH) + 80.0f) * 2.6f;
	float eScale = 1.0f + 0.10f * (diff - 1.0f);
	for (auto &e : enemies) {
		const EnemyDef &d = ENEMIES[e.type];
		float sp = d.speed * (1.0f + 0.03f * (diff - 1.0f));
		if (e.slowT > 0) { e.slowT -= dt; sp *= 1.0f - e.slowAmt; }
		e.t += dt;
		if (e.flash > 0) e.flash -= dt;
		if (e.alpha < 1) e.alpha = std::min(1.0f, e.alpha + dt * 2.5f);
		V2 to = ship.p - e.p;
		float dd = to.len();
		V2 dir = to.norm();
		V2 perp(-dir.y, dir.x);
		V2 dv;
		if (d.pattern == 10) { // rusher: charge, hit, retreat
			if (e.aux > 0) { e.aux -= dt; dv = dir * (-sp * 0.7f); }
			else {
				dv = dir * (sp * 1.5f);
				if (dd < e.r + ship.r + 6) {
					damageShip(d.dmg * eScale, 0.8f);
					e.aux = 1.6f;
					ship.v += dir * 120.0f;
				}
			}
		} else {
			e.aux -= dt;
			if (e.aux <= 0) {
				e.dir = -e.dir;
				e.aux = rng.range(1.5f, 3.5f);
				if (d.pattern == 0) e.v += perp * (float)e.dir * 420.0f; // juke dash
				if (d.pattern == 11) { // phantom blink
					e.p = ship.p + V2::fromAngle(rng.range(0, TAU)) * d.range;
					e.alpha = 0.0f;
					addFx(FX_FLASH, e.p, V2(), 0.3f, 40, 0xFFFFFFFF);
				}
			}
			float radial = dd > d.range * 1.15f ? 1.0f : (dd < d.range * 0.75f ? -1.0f : 0.0f);
			dv = (dir * radial + perp * (0.8f * (float)e.dir)).norm() * sp;
		}
		e.v = e.v + (dv - e.v) * std::min(1.0f, dt * 4.0f);
		e.p += e.v * dt;
		e.ang = dir.angle();
		if (d.pattern != 10) {
			e.fire -= dt;
			if (e.fire <= 0 && dd < 900 && e.alpha > 0.8f) {
				enemyFire(e);
				e.fire = d.fire * rng.range(0.85f, 1.15f) / (1.0f + 0.04f * (diff - 1.0f));
			}
		}
		if (e.hp > 0 && d.pattern != 10 && dd < e.r + ship.r * 0.85f) {
			damageShip(d.dmg * 0.7f * eScale, 0.8f);
			ship.v -= dir * 150.0f;
			e.v = dir * -200.0f;
		}
	}
	enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [&](const Enemy &e) { return dist(e.p, ship.p) > despawn; }), enemies.end());
}

void Run::ebullet(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int kind, float expR) {
	if (ebullets.size() > 700) return;
	EBullet b;
	b.p = p; b.v = v; b.dmg = dmg; b.r = r; b.life = life; b.col = col; b.kind = kind; b.expR = expR;
	ebullets.push_back(b);
}

void Run::enemyFire(Enemy &e) {
	const EnemyDef &d = ENEMIES[e.type];
	float eScale = 1.0f + 0.10f * (diff - 1.0f);
	float dmg = d.dmg * eScale;
	V2 to = ship.p - e.p;
	V2 dir = to.norm();
	float base = dir.angle();
	auto fan = [&](int n, float spread, float speed, float life, float r, uint32_t col) {
		for (int i = 0; i < n; i++) {
			float a = base + (n > 1 ? (i - (n - 1) * 0.5f) * spread / (n - 1) : 0.0f);
			ebullet(e.p + V2::fromAngle(a) * e.r, V2::fromAngle(a) * speed, dmg, r, life, col);
		}
	};
	switch (d.pattern) {
		case 0: fan(1, 0, 420, 3, 6, 0xFF66AAFF); break;
		case 1: { // leading shot
			float sp = 460;
			V2 aim = (ship.p + ship.v * (to.len() / sp) - e.p).norm();
			ebullet(e.p + aim * e.r, aim * sp, dmg, 6, 3, 0xFF66FF88);
			break;
		}
		case 2: fan(5, 0.7f, 380, 1.0f, 5, 0xFFFFAA44); break;
		case 3: {
			V2 perp(-dir.y, dir.x);
			ebullet(e.p + perp * 10.0f, dir * 400, dmg, 6, 3, 0xFF55EEFF);
			ebullet(e.p - perp * 10.0f, dir * 400, dmg, 6, 3, 0xFF55EEFF);
			break;
		}
		case 4: fan(1, 0, 540, 2.5f, 5, 0xFFFF8877); break;
		case 5: fan(2, 0.5f, 380, 3, 6, 0xFFFFE055); break;
		case 6: ebullet(e.p + dir * e.r, dir * 340, dmg, 9, 3, 0xFFCCFF44, 1, 85); break;
		case 7:
			for (int i = 0; i < 8; i++) {
				float a = (float)i * TAU / 8.0f + e.t;
				ebullet(e.p, V2::fromAngle(a) * 300, dmg, 5, 3, 0xFFCC77FF);
			}
			break;
		case 8: ebullet(e.p + dir * e.r, dir * 230, dmg * 1.4f, 15, 4, 0xFFFF5544, 2, 100); break;
		case 9: fan(3, 0.5f, 380, 3, 7, 0xFF8899FF); break;
		case 11: fan(2, 0.18f, 620, 2, 5, 0xFFFFFFFF); break;
		default: break;
	}
}

void Run::updateBoss(float dt) {
	if (!boss.active) return;
	Boss &b = boss;
	b.t += dt;
	if (b.flash > 0) b.flash -= dt;
	b.phase = b.hp < b.maxhp * 0.33f ? 2 : (b.hp < b.maxhp * 0.66f ? 1 : 0);
	V2 to = ship.p - b.p;
	float dd = to.len();
	V2 dir = to.norm();
	V2 perp(-dir.y, dir.x);
	float bs = 1.0f + 0.15f * b.index;
	if (b.dashing > 0) {
		b.dashing -= dt;
		b.p += b.dashDir * 950.0f * dt;
	} else if (b.telegraph > 0) {
		b.telegraph -= dt;
		b.dashDir = dir;
		if (b.telegraph <= 0) b.dashing = 0.65f;
	} else {
		float radial = clampf((dd - 520.0f) / 200.0f, -1, 1);
		V2 dv = dir * (radial * 130.0f) + perp * (95.0f * (std::fmod(b.t, 8.0f) < 4.0f ? 1.0f : -1.0f));
		b.v = b.v + (dv - b.v) * std::min(1.0f, dt * 2.0f);
		b.p += b.v * dt;
		b.dashT -= dt;
		if (b.phase >= 1 && b.dashT <= 0 && dd < 1000) { b.telegraph = 0.8f; b.dashT = 7.0f; }
	}
	bossFire(dt);
	if (b.hp > 0 && dist(b.p, ship.p) < b.r + ship.r * 0.85f) {
		damageShip(25.0f * bs, 1.0f);
		ship.v -= dir * 260.0f;
	}
}

void Run::bossFire(float dt) {
	Boss &b = boss;
	if (b.telegraph > 0 || b.dashing > 0) return;
	float bs = 1.0f + 0.15f * b.index;
	V2 dir = (ship.p - b.p).norm();
	float base = dir.angle();
	b.fireA -= dt;
	if (b.fireA <= 0) {
		b.fireA = 1.5f - 0.2f * b.phase;
		int n = 3 + 2 * (b.phase >= 2 ? 1 : 0);
		for (int i = 0; i < n; i++) {
			float a = base + (i - (n - 1) * 0.5f) * 0.22f;
			ebullet(b.p + V2::fromAngle(a) * b.r, V2::fromAngle(a) * 430, 9 * bs, 7, 3.5f, 0xFFFF6655);
		}
	}
	b.fireB -= dt;
	if (b.fireB <= 0) {
		b.fireB = 3.0f - 0.3f * b.phase;
		int n = 14 + 4 * b.phase;
		float off = rng.range(0, TAU);
		for (int i = 0; i < n; i++) {
			float a = off + (float)i * TAU / (float)n;
			ebullet(b.p, V2::fromAngle(a) * 250, 8 * bs, 7, 4.5f, 0xFFFFAA33);
		}
	}
	if (b.phase >= 1) {
		b.fireC -= dt;
		if (b.fireC <= 0) {
			b.fireC = 0.14f;
			b.spiral += 0.37f;
			for (int k = 0; k < (b.phase >= 2 ? 2 : 1); k++) {
				float a = b.spiral + (float)k * PI;
				ebullet(b.p, V2::fromAngle(a) * 300, 6 * bs, 6, 4.0f, 0xFFCC66FF);
			}
		}
	}
}

void Run::updateEBullets(float dt) {
	for (auto &b : ebullets) {
		b.p += b.v * dt;
		b.life -= dt;
		if (b.life > 0 && dist(b.p, ship.p) < b.r + ship.r * 0.7f) {
			if (b.kind != 0) {
				explode(b.p, b.expR, b.dmg, -2, b.col, true);
			} else {
				damageShip(b.dmg, 0.25f);
			}
			b.life = 0;
		} else if (b.life <= 0 && b.kind != 0) {
			explode(b.p, b.expR, b.dmg, -2, b.col, true);
		}
	}
	ebullets.erase(std::remove_if(ebullets.begin(), ebullets.end(), [](const EBullet &b) { return b.life <= 0; }), ebullets.end());
}

// ------------------------------------------------------------------ targets & damage
void Run::buildTargets() {
	tg.clear();
	for (size_t i = 0; i < asteroids.size(); i++)
		if (asteroids[i].hp > 0) tg.push_back({0, (int)i, asteroids[i].p, asteroids[i].r, asteroids[i].uid});
	for (size_t i = 0; i < enemies.size(); i++)
		if (enemies[i].hp > 0) tg.push_back({1, (int)i, enemies[i].p, enemies[i].r, enemies[i].uid});
	if (boss.active && boss.hp > 0) tg.push_back({2, 0, boss.p, boss.r, boss.uid});
}

const Tgt *Run::nearest(V2 from, float maxR, int skipUid) const {
	const Tgt *best = nullptr;
	float bd = maxR * maxR;
	for (const auto &x : tg) {
		if (x.uid == skipUid) continue;
		// prefer enemies/boss slightly over asteroids
		float d2 = (x.p - from).len2() * (x.kind == 0 ? 1.0f : 0.6f);
		if (d2 < bd) { bd = d2; best = &x; }
	}
	return best;
}

std::vector<const Tgt *> Run::nearestN(V2 from, float maxR, int n) const {
	std::vector<std::pair<float, const Tgt *>> v;
	for (const auto &x : tg) {
		float d2 = (x.p - from).len2() * (x.kind == 0 ? 1.0f : 0.6f);
		if (d2 < maxR * maxR) v.push_back({d2, &x});
	}
	std::sort(v.begin(), v.end(), [](const std::pair<float, const Tgt *> &a, const std::pair<float, const Tgt *> &b) { return a.first < b.first; });
	std::vector<const Tgt *> out;
	for (int i = 0; i < (int)v.size() && i < n; i++) out.push_back(v[i].second);
	return out;
}

float Run::rollDamage(float base, bool &crit) {
	float crit_chance = 0.03f + P->storeValue(4);
	crit = rng.chance(crit_chance);
	float d = base * dmgMult();
	if (crit) d *= 2.0f;
	return d;
}

void Run::damageText(V2 p, float dmg, bool crit) {
	if (fx.size() > 260) return;
	if (!crit && dmg < 6.0f) return;
	if (!crit && rng.chance(0.5f)) return;
	addFx(FX_TEXT, p + V2(rng.range(-12, 12), -18), V2(), 0.6f, crit ? 26.0f : 18.0f, crit ? 0xFFFFE04A : 0xFFFFFFFF, V2(0, -60), std::to_string((int)std::round(dmg)));
}

void Run::hitAsteroid(Asteroid &a, float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	a.hp -= d;
	a.flash = 0.1f;
	damageText(a.p, d, crit);
}
void Run::hitEnemy(Enemy &e, float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	e.hp -= d;
	e.flash = 0.1f;
	damageText(e.p, d, crit);
}
void Run::hitBoss(float dmg) {
	bool crit;
	float d = rollDamage(dmg, crit);
	boss.hp -= d;
	boss.flash = 0.08f;
	damageText(boss.p, d, crit);
}
void Run::hitTarget(const Tgt &x, float dmg, int) {
	if (x.kind == 0) { if (x.idx < (int)asteroids.size()) hitAsteroid(asteroids[x.idx], dmg); }
	else if (x.kind == 1) { if (x.idx < (int)enemies.size()) hitEnemy(enemies[x.idx], dmg); }
	else if (boss.active) hitBoss(dmg);
}

void Run::explode(V2 p, float r, float dmg, int wid, uint32_t col, bool hurtShip) {
	addFx(FX_RING, p, V2(), 0.35f, r, col);
	addFx(FX_FLASH, p, V2(), 0.2f, r * 0.45f, col);
	if (fx.size() < 300)
		for (int i = 0; i < 6; i++) addFx(FX_SPARK, p, V2(), 0.45f, 3, col, V2::fromAngle(rng.range(0, TAU)) * rng.range(60, 240));
	sfxEvent(S_EXPLOSION);
	if (dmg <= 0) return;
	if (hurtShip) {
		if (dist(p, ship.p) < r + ship.r * 0.5f) damageShip(dmg, 0.4f);
		if (wid != -2) { // volatile blast also hurts enemies/asteroids but not boss bullets
		}
	}
	if (wid == -2) return; // enemy explosion: ship only
	for (auto &a : asteroids)
		if (a.hp > 0 && dist(a.p, p) < r + a.r) hitAsteroid(a, dmg);
	for (auto &e : enemies)
		if (e.hp > 0 && dist(e.p, p) < r + e.r) hitEnemy(e, dmg);
	if (boss.active && boss.hp > 0 && dist(boss.p, p) < r + boss.r) hitBoss(dmg);
}

void Run::addFx(int kind, V2 a, V2 b, float life, float size, uint32_t col, V2 v, const std::string &txt) {
	if (fx.size() > 420) return;
	Fx f;
	f.kind = kind; f.a = a; f.b = b; f.life = life; f.size = size; f.col = col; f.v = v; f.txt = txt;
	fx.push_back(f);
}

void Run::updateFx(float dt) {
	for (auto &f : fx) {
		f.t += dt;
		if (f.kind == FX_SPARK || f.kind == FX_TEXT) f.a += f.v * dt;
		if (f.kind == FX_SPARK) f.v *= 0.97f;
	}
	fx.erase(std::remove_if(fx.begin(), fx.end(), [](const Fx &f) { return f.t >= f.life; }), fx.end());
}

// ------------------------------------------------------------------ shots
Shot &Run::newShot(V2 p, V2 v, float dmg, float r, float life, uint32_t col, int wid, int kind) {
	shots.emplace_back();
	Shot &s = shots.back();
	s.p = p; s.v = v; s.dmg = dmg; s.r = r; s.life = life; s.col = col; s.wid = wid; s.kind = kind;
	return s;
}

void Run::updateShots(float dt) {
	for (auto &s : shots) {
		s.life -= dt;
		if (s.homing > 0) {
			const Tgt *tt = nullptr;
			if (s.tgt >= 0)
				for (const auto &x : tg) if (x.uid == s.tgt) { tt = &x; break; }
			if (!tt) {
				tt = nearest(s.p, 900);
				s.tgt = tt ? tt->uid : -1;
			}
			if (tt) {
				float sp = s.v.len();
				float cur = s.v.angle();
				float want = (tt->p - s.p).angle();
				float d = std::fmod(want - cur + 3 * PI, TAU) - PI;
				float step = s.homing * dt;
				cur += clampf(d, -step, step);
				s.v = V2::fromAngle(cur) * sp;
			}
		}
		s.p += s.v * dt;
		bool dead = false;
		if (s.kind == 3) { // flak proximity fuse
			for (const auto &x : tg)
				if (dist(x.p, s.p) < x.r + 55) { dead = true; break; }
		}
		if (!dead && s.life > 0) {
			for (const auto &x : tg) {
				if (dist(x.p, s.p) >= x.r + s.r) continue;
				bool seen = false;
				for (int k = 0; k < s.nhit && k < 8; k++) if (s.hit[k] == x.uid) seen = true;
				if (seen) continue;
				// is the target still alive?
				if (x.kind == 0 && asteroids[x.idx].hp <= 0) continue;
				if (x.kind == 1 && enemies[x.idx].hp <= 0) continue;
				if (x.kind == 2 && boss.hp <= 0) continue;
				if (s.expR > 0) { dead = true; break; }
				hitTarget(x, s.dmg, s.wid);
				if (s.heal > 0) ship.hp = std::min(ship.maxHp, ship.hp + s.heal);
				if (s.split) {
					s.split = false;
					for (int k = 0; k < 2; k++) {
						const Tgt *nt = nearest(x.p, 800, x.uid);
						float a = (nt ? (nt->p - x.p).angle() : rng.range(0, TAU)) + (k == 0 ? -0.5f : 0.5f);
						Shot ns = s;
						ns.p = x.p;
						ns.v = V2::fromAngle(a) * 520.0f;
						ns.dmg = s.dmg * 0.6f;
						ns.split = false;
						ns.life = 1.8f;
						ns.tgt = nt ? nt->uid : -1;
						ns.nhit = 1;
						ns.hit[0] = x.uid;
						pendingShots_.push_back(ns);
					}
					dead = true;
					break;
				}
				if (s.nhit < 8) s.hit[s.nhit++] = x.uid;
				s.pierce--;
				if (s.pierce < 0) { dead = true; break; }
			}
		}
		if (!dead && s.life <= 0) dead = true;
		if (dead) {
			if (s.expR > 0 || s.bomblets > 0) {
				if (s.expR > 0) explode(s.p, s.expR, s.expDmg, s.wid, s.col, false);
				for (int i = 0; i < s.bomblets; i++) {
					float a = (float)i * TAU / (float)s.bomblets + rng.range(0, 0.5f);
					Shot b;
					b.p = s.p; b.v = V2::fromAngle(a) * rng.range(240, 340); b.dmg = 0; b.r = 4; b.life = rng.range(0.28f, 0.42f);
					b.expR = 48; b.expDmg = s.expDmg * 0.55f; b.kind = 7; b.wid = s.wid; b.col = s.col; b.pierce = 99;
					// appended after the loop to avoid invalidation
					pendingShots_.push_back(b);
				}
			}
			s.life = -1000;
		}
	}
	shots.erase(std::remove_if(shots.begin(), shots.end(), [](const Shot &s) { return s.life <= -999; }), shots.end());
	for (auto &b : pendingShots_) shots.push_back(b);
	pendingShots_.clear();
}

} // namespace nj
