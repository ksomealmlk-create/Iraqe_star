# نجوم العراق (Astro Loop) - Godot 4.3 + C++ (GDExtension)

طريقة البناء على GitHub:
1. ارفع كل محتويات المجلد إلى مستودع جديد (انتبه أن المجلد المخفي `.github/workflows/build.yml` يترفع).
2. من تبويب Actions شغّل "Build APK (Godot + C++)" (يشتغل تلقائياً عند أي push).
3. بعد ما يخلص (حوالي 15-25 دقيقة) نزّل الملف `nujoom-iraq-apk` من Artifacts واستخرج منه `nujoom.apk`.

الكود: `src/sim` (منطق اللعبة بـ C++ صرف)، `src/godot` (الرسم/اللمس/الصوت).
الرخصة: GPL-3.0 (مبنية على Astro Loop من PubDeer).

## اللعب مع صديق (أونلاين)
1. اعمل Secrets في GitHub: `CLOUDFLARE_API_TOKEN` و `CLOUDFLARE_ACCOUNT_ID`.
2. شغّل Actions > "Deploy Cloudflare Server" وانسخ الرابط الذي يظهر في Summary.
3. عدّل `src/godot/net_config.hpp` وضع الرابط بصيغة `wss://...` ثم ارفع التعديل ليُبنى الـ APK.
